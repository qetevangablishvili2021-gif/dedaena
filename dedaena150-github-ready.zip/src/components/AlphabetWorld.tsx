import React, { useEffect, useRef, useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  Flower2,
  PenTool,
  Puzzle,
  Sparkles,
  RotateCcw,
  CheckCircle2,
  BookMarked,
} from 'lucide-react';
import {
  GEORGIAN_ALPHABET,
  SENTENCE_BUILDERS,
  SYLLABLE_WORDS,
  WORD_PUZZLES,
} from '../data/alphabet';
import { StudentProgress } from '../types';
import { soundFX } from '../utils/sound';
import { OrnamentalDivider } from './OrnamentalDivider';

interface AlphabetWorldProps {
  progress: StudentProgress;
  onDiscoverLetter: (char: string) => void;
  onTraceLetter: (char: string) => void;
  onCompleteAiIa: () => void;
}

type AlphabetTab = 'ai-ia' | 'garden' | 'trace' | 'exercises' | 'memory' | 'treasury';
type ExerciseMode = 'syllables' | 'missing' | 'scramble' | 'first-last' | 'sentences' | 'match';

export function AlphabetWorld({
  progress,
  onDiscoverLetter,
  onTraceLetter,
  onCompleteAiIa,
}: AlphabetWorldProps) {
  const [tab, setTab] = useState<AlphabetTab>('ai-ia');
  const [selectedLetter, setSelectedLetter] = useState(GEORGIAN_ALPHABET[0]);

  return (
    <section className="max-w-7xl mx-auto px-4 sm:px-6 py-8 space-y-6">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-4">
        <div>
          <div className="text-xs font-medium text-[#5B21B6]">
            I. საგანმანათლებლო სამყარო · „დედაენის“ საწყისი
          </div>
          <h1 className="font-serif text-2xl sm:text-4xl font-bold text-[#231B15] mt-1">
            ასოების სამყარო — „აი ია“
          </h1>
          <p className="text-sm text-[#5C4E42] mt-1.5 max-w-2xl">
            გააცოცხლე იაკობ გოგებაშვილის პირველი გაკვეთილი, გამოიწერე 33-ვე ქართული ასო, ააშენე სიტყვები და გაახარე შენი ანბანის ბაღი.
          </p>
        </div>

        <div className="text-xs text-[#5C4E42] tabular-nums">
          გახსნილი ასოები: <strong className="text-[#14532D]">{progress.discoveredLetters.length} / 33</strong>
          <span className="mx-2" aria-hidden="true">·</span>
          გამოწერილი: <strong className="text-[#5B21B6]">{progress.tracedLetters.length} / 33</strong>
        </div>
      </div>

      {/* Mode Tabs */}
      <div className="flex flex-wrap gap-1.5 p-1.5 bg-[#EFE6D5] rounded-xl border border-[#DDD2BE]">
        {[
          { id: 'ai-ia', label: 'თამაში „აი ია“', icon: Flower2 },
          { id: 'garden', label: '33 ასოს ბაღი', icon: Sparkles },
          { id: 'trace', label: 'ასოების გამოწერა', icon: PenTool },
          { id: 'exercises', label: 'სიტყვების სახელოსნო', icon: Puzzle },
          { id: 'memory', label: 'მეხსიერების თამაში', icon: Puzzle },
          { id: 'treasury', label: 'სიტყვების საგანძური', icon: BookMarked },
        ].map((item) => {
          const Icon = item.icon;
          const active = tab === item.id;
          return (
            <button
              key={item.id}
              onClick={() => {
                soundFX.playClick();
                setTab(item.id as AlphabetTab);
              }}
              className={`inline-flex items-center gap-1.5 px-3.5 py-2 rounded-lg text-xs font-semibold transition-colors cursor-pointer whitespace-nowrap ${
                active
                  ? 'bg-[#FFFDF8] text-[#231B15] shadow-sm'
                  : 'text-[#5C4E42] hover:text-[#231B15]'
              }`}
            >
              <Icon className="w-3.5 h-3.5" />
              <span>{item.label}</span>
            </button>
          );
        })}
      </div>

      {tab === 'ai-ia' && (
        <AiIaMeadowGame
          completed={progress.aiIaCompleted}
          onComplete={() => {
            onDiscoverLetter('ა');
            onDiscoverLetter('ი');
            onCompleteAiIa();
          }}
        />
      )}

      {tab === 'garden' && (
        <div className="grid lg:grid-cols-12 gap-6 items-start">
          <div className="lg:col-span-8 vellum-card rounded-2xl p-5 sm:p-6">
            <h2 className="font-serif text-xl font-bold text-[#231B15] mb-1">
              ქართული ანბანის 33 ასოს ბაღი
            </h2>
            <p className="text-xs text-[#5C4E42] mb-4">
              დააჭირე ნებისმიერ ასოს — აღმოაჩინე მისი სახელწოდება და გააშენე შესაბამისი მცენარე შენს ბაღში.
            </p>
            <div className="grid grid-cols-6 sm:grid-cols-9 md:grid-cols-11 gap-2">
              {GEORGIAN_ALPHABET.map((letter) => {
                const discovered = progress.discoveredLetters.includes(letter.char);
                const isSelected = selectedLetter.char === letter.char;
                return (
                  <button
                    key={letter.char}
                    onClick={() => {
                      soundFX.playClick();
                      setSelectedLetter(letter);
                      onDiscoverLetter(letter.char);
                    }}
                    className={`relative h-14 rounded-xl border text-center flex flex-col items-center justify-center transition-all cursor-pointer ${
                      isSelected
                        ? 'bg-[#231B15] text-[#FDE68A] border-[#231B15] scale-105'
                        : discovered
                        ? 'bg-[#F0F7EE] text-[#14532D] border-[#86EFAC]'
                        : 'bg-[#FFFDF8] text-[#231B15] border-[#DDD2BE] hover:border-[#B8860B]'
                    }`}
                  >
                    <span className="font-serif text-xl font-bold leading-none">
                      {letter.char}
                    </span>
                    <span className="text-[10px] opacity-75 mt-1">{letter.name}</span>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Letter Botanical Card */}
          <div className="lg:col-span-4 vellum-card rounded-2xl p-6 space-y-4">
            <div className="flex items-center justify-between">
              <span className="text-xs font-medium text-[#6B5B4E]">
                ასო „{selectedLetter.name}“
              </span>
              <span className="text-xs font-semibold text-[#14532D]">
                {selectedLetter.botanicalSymbol}
              </span>
            </div>

            <div className="h-44 rounded-xl bg-[#FAF6EE] border border-[#E2D6C1] flex items-center justify-center gap-6 px-4">
              <span
                className="font-serif text-7xl font-bold"
                style={{ color: selectedLetter.color }}
              >
                {selectedLetter.char}
              </span>
              {/* Botanical Bloom SVG */}
              <svg width="86" height="96" viewBox="0 0 86 96" fill="none">
                <path d="M43 88 V44" stroke="#15803D" strokeWidth="3" strokeLinecap="round" />
                <path d="M43 72 C29 68, 25 58, 30 52 C37 52, 41 61, 43 72Z" fill="#22C55E" />
                <path d="M43 66 C57 62, 61 52, 56 46 C49 46, 45 55, 43 66Z" fill="#16A34A" />
                <circle cx="43" cy="28" r="10" fill={selectedLetter.color} opacity="0.85" />
                <circle cx="32" cy="35" r="9" fill={selectedLetter.color} opacity="0.78" />
                <circle cx="54" cy="35" r="9" fill={selectedLetter.color} opacity="0.78" />
                <circle cx="36" cy="45" r="8" fill={selectedLetter.color} opacity="0.9" />
                <circle cx="50" cy="45" r="8" fill={selectedLetter.color} opacity="0.9" />
                <circle cx="43" cy="36" r="5" fill="#FBBF24" />
              </svg>
            </div>

            <div>
              <div className="text-xs text-[#6B5B4E]">სანიმუშო სიტყვა:</div>
              <div className="font-serif text-2xl font-bold text-[#231B15] mt-0.5">
                {selectedLetter.sampleWord}
              </div>
              <p className="text-xs text-[#5C4E42] mt-2">{selectedLetter.hint}</p>
            </div>

            <div className="pt-3 border-t border-[#EAE1D0] flex items-center justify-between text-xs">
              <span className="text-[#6B5B4E]">მარცვლები:</span>
              <span className="font-semibold text-[#7F1D1D]">
                {selectedLetter.syllables.join(' · ')}
              </span>
            </div>

            <button
              onClick={() => setTab('trace')}
              className="w-full py-2.5 rounded-xl bg-[#7F1D1D] hover:bg-[#991B1B] text-white text-xs font-semibold transition-colors cursor-pointer"
            >
              გამოიწერე ასო „{selectedLetter.char}“ →
            </button>
          </div>
        </div>
      )}

      {tab === 'trace' && (
        <LetterTracingPad
          selectedLetter={selectedLetter}
          onSelectLetter={setSelectedLetter}
          tracedLetters={progress.tracedLetters}
          onMarkTraced={(ch) => {
            onTraceLetter(ch);
            onDiscoverLetter(ch);
          }}
        />
      )}

      {tab === 'exercises' && <WordWorkshop />}

      {tab === 'memory' && <AlphabetMemoryGame />}

      {tab === 'treasury' && (
        <div className="vellum-card rounded-2xl p-6 sm:p-8">
          <h2 className="font-serif text-2xl font-bold text-[#231B15]">
            ქართული სიტყვების საგანძური
          </h2>
          <p className="text-sm text-[#5C4E42] mt-1">
            გოგებაშვილის „დედაენისა“ და მოთხრობების უმშვენიერესი სიტყვები და მარცვლები.
          </p>
          <OrnamentalDivider />
          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
            {GEORGIAN_ALPHABET.map((item) => (
              <div
                key={item.char}
                className="p-4 rounded-xl bg-[#FAF6EE] border border-[#E2D6C1] flex items-center gap-4"
              >
                <div
                  className="w-12 h-12 rounded-xl flex items-center justify-center font-serif text-2xl font-bold text-white shrink-0"
                  style={{ backgroundColor: item.color }}
                >
                  {item.char}
                </div>
                <div className="min-w-0">
                  <div className="font-serif text-base font-bold text-[#231B15] truncate">
                    {item.sampleWord}
                  </div>
                  <div className="text-xs text-[#6B5B4E] truncate">{item.botanicalSymbol}</div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </section>
  );
}

// Special Animated Nature Game: „აი ია“
function AiIaMeadowGame({
  completed,
  onComplete,
}: {
  completed: boolean;
  onComplete: () => void;
}) {
  const [step, setStep] = useState<'build-ai' | 'build-ia' | 'bloomed'>(
    completed ? 'bloomed' : 'build-ai'
  );
  const [slots, setSlots] = useState<string[]>([]);
  const [feedback, setFeedback] = useState(
    'იპოვე მდელოზე დაფანტული ასოები და ჯერ ააწყვე სიტყვა „აი“!'
  );
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  const scatteredLetters = ['მ', 'ა', 'ს', 'ი', 'დ', 'ა'];

  const handlePickLetter = (ch: string) => {
    soundFX.playClick();
    if (step === 'bloomed') return;
    const next = [...slots, ch];
    if (next.length > 2) return;
    setSlots(next);

    if (next.length === 2) {
      const word = next.join('');
      if (step === 'build-ai') {
        if (word === 'აი') {
          soundFX.playSuccess();
          setFeedback('ყოჩაღ! „აი“ მზადაა — ახლა ააწყვე ყვავილის სახელი „ია“!');
          setTimeout(() => {
            setSlots([]);
            setStep('build-ia');
          }, 850);
        } else {
          soundFX.playError();
          setFeedback('სცადე თავიდან: სიტყვა „აი“ შედგება ასოებისგან „ა“ და „ი“.');
          setTimeout(() => setSlots([]), 700);
        }
      } else if (step === 'build-ia') {
        if (word === 'ია') {
          soundFX.playBloom();
          setStep('bloomed');
          setFeedback('შესანიშნავია! მიწიდან ამოიზარდა იის ყვავილი — „აი ია“!');
          onComplete();
        } else {
          soundFX.playError();
          setFeedback('თითქმის გამოვიდა! „ია“ იწყება ასოთი „ი“ და მთავრდება ასოთი „ა“.');
          setTimeout(() => setSlots([]), 700);
        }
      }
    }
  };

  // Living meadow Canvas animation (sprouts & violet bloom + golden particles)
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let rafId = 0;
    let bloomProgress = step === 'bloomed' ? 0.05 : 0;
    const startTime = performance.now();

    const particles = Array.from({ length: 28 }, (_, idx) => ({
      x: 0.25 + Math.random() * 0.5,
      y: 0.8 - Math.random() * 0.5,
      r: 1.5 + (idx % 3),
      speed: 0.0005 + Math.random() * 0.0007,
    }));

    const draw = (now: number) => {
      const t = (now - startTime) / 1000;
      const w = (canvas.width = canvas.offsetWidth);
      const h = (canvas.height = canvas.offsetHeight);

      // Sky gradient
      const sky = ctx.createLinearGradient(0, 0, 0, h);
      sky.addColorStop(0, step === 'bloomed' ? '#EAF4E4' : '#F8F2E4');
      sky.addColorStop(1, '#DCE8C9');
      ctx.fillStyle = sky;
      ctx.fillRect(0, 0, w, h);

      // Sun
      ctx.fillStyle = step === 'bloomed' ? 'rgba(251, 191, 36, 0.85)' : 'rgba(251, 191, 36, 0.45)';
      ctx.beginPath();
      ctx.arc(w * 0.84, h * 0.2, step === 'bloomed' ? 32 : 24, 0, Math.PI * 2);
      ctx.fill();

      // Hills & Soil
      ctx.fillStyle = '#B7CE97';
      ctx.beginPath();
      ctx.moveTo(0, h * 0.72);
      ctx.quadraticCurveTo(w * 0.5, h * 0.58, w, h * 0.72);
      ctx.lineTo(w, h);
      ctx.lineTo(0, h);
      ctx.closePath();
      ctx.fill();

      ctx.fillStyle = '#6B4F35';
      ctx.beginPath();
      ctx.ellipse(w * 0.5, h * 0.8, 70, 14, 0, 0, Math.PI * 2);
      ctx.fill();

      // Sprout / Blooming Violet
      if (step === 'build-ia' || step === 'bloomed') {
        if (step === 'bloomed') {
          bloomProgress = Math.min(1, bloomProgress + 0.015);
        } else {
          bloomProgress = 0.28;
        }
        const stemHeight = 115 * bloomProgress;
        const baseY = h * 0.8;
        const topY = baseY - stemHeight;

        ctx.strokeStyle = '#15803D';
        ctx.lineWidth = 4;
        ctx.lineCap = 'round';
        ctx.beginPath();
        ctx.moveTo(w * 0.5, baseY);
        ctx.quadraticCurveTo(w * 0.5 + Math.sin(t * 2) * 5, baseY - stemHeight * 0.5, w * 0.5, topY);
        ctx.stroke();

        if (bloomProgress > 0.22) {
          ctx.fillStyle = '#22C55E';
          ctx.beginPath();
          ctx.ellipse(w * 0.5 - 16, baseY - stemHeight * 0.4, 14, 7, -0.4, 0, Math.PI * 2);
          ctx.ellipse(w * 0.5 + 16, baseY - stemHeight * 0.5, 14, 7, 0.4, 0, Math.PI * 2);
          ctx.fill();
        }

        if (step === 'bloomed' && bloomProgress > 0.45) {
          const pScale = (bloomProgress - 0.45) / 0.55;
          ctx.save();
          ctx.translate(w * 0.5, topY);
          ctx.scale(pScale, pScale);
          const petals = [
            [0, -14, '#7C3AED'],
            [-14, -4, '#6D28D9'],
            [14, -4, '#6D28D9'],
            [-9, 10, '#5B21B6'],
            [9, 10, '#5B21B6'],
          ] as const;
          petals.forEach(([px, py, col]) => {
            ctx.fillStyle = col;
            ctx.beginPath();
            ctx.arc(px, py, 12, 0, Math.PI * 2);
            ctx.fill();
          });
          ctx.fillStyle = '#FBBF24';
          ctx.beginPath();
          ctx.arc(0, 0, 6, 0, Math.PI * 2);
          ctx.fill();
          ctx.restore();

          // Golden particles
          particles.forEach((p) => {
            p.y -= p.speed;
            if (p.y < 0.1) p.y = 0.8;
            ctx.fillStyle = 'rgba(212, 160, 23, 0.8)';
            ctx.beginPath();
            ctx.arc(p.x * w, p.y * h, p.r, 0, Math.PI * 2);
            ctx.fill();
          });

          // Illuminated „აი ია“ inscription
          ctx.fillStyle = '#231B15';
          ctx.font = '700 32px "Noto Serif Georgian", serif';
          ctx.textAlign = 'center';
          ctx.fillText('აი ია', w * 0.5, h * 0.24);
        }
      }

      rafId = requestAnimationFrame(draw);
    };

    rafId = requestAnimationFrame(draw);
    return () => cancelAnimationFrame(rafId);
  }, [step]);

  const reset = () => {
    setSlots([]);
    setStep('build-ai');
    setFeedback('იპოვე მდელოზე დაფანტული ასოები და ჯერ ააწყვე სიტყვა „აი“!');
  };

  return (
    <div className="grid lg:grid-cols-12 gap-6 items-stretch">
      <div className="lg:col-span-7 vellum-card rounded-2xl overflow-hidden relative">
        <canvas ref={canvasRef} className="w-full h-[320px] sm:h-[380px] block" />
      </div>

      <div className="lg:col-span-5 vellum-card rounded-2xl p-6 flex flex-col justify-between">
        <div>
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-[#5B21B6]">
              ცოცხალი ბუნების თამაში
            </span>
            <button
              onClick={reset}
              className="inline-flex items-center gap-1 text-xs text-[#6B5B4E] hover:text-[#231B15] cursor-pointer"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              თავიდან
            </button>
          </div>

          <h2 className="font-serif text-2xl font-bold text-[#231B15] mt-2">
            {step === 'build-ai'
              ? 'ნაბიჯი 1: ააწყვე სიტყვა „აი“'
              : step === 'build-ia'
              ? 'ნაბიჯი 2: ააწყვე სიტყვა „ია“'
              : 'აი ია — ყვავილი გაიშალა!'}
          </h2>

          <p className="mt-2 text-sm text-[#4A3B31]">{feedback}</p>

          {/* Assembly Slots */}
          <div className="mt-6 flex items-center justify-center gap-3">
            {[0, 1].map((idx) => (
              <div
                key={idx}
                className="w-16 h-16 rounded-xl border-2 border-dashed border-[#B8860B] bg-[#FAF6EE] flex items-center justify-center font-serif text-3xl font-bold text-[#231B15]"
              >
                {step === 'bloomed' ? (idx === 0 ? 'ი' : 'ა') : slots[idx] || ''}
              </div>
            ))}
          </div>

          {/* Scattered letter buttons */}
          {step !== 'bloomed' && (
            <div className="mt-6">
              <div className="text-xs text-[#6B5B4E] mb-2 text-center">
                დააჭირე ასოებს თანმიმდევრობით:
              </div>
              <div className="flex flex-wrap items-center justify-center gap-2.5">
                {scatteredLetters.map((ch, idx) => (
                  <motion.button
                    key={`${ch}-${idx}`}
                    whileTap={{ scale: 0.92 }}
                    onClick={() => handlePickLetter(ch)}
                    className="w-12 h-12 rounded-xl bg-[#FFFDF8] border border-[#D8CBB3] hover:border-[#5B21B6] font-serif text-2xl font-bold text-[#231B15] shadow-sm cursor-pointer"
                  >
                    {ch}
                  </motion.button>
                ))}
              </div>
            </div>
          )}
        </div>

        <AnimatePresence>
          {step === 'bloomed' && (
            <motion.div
              initial={{ opacity: 0, y: 8 }}
              animate={{ opacity: 1, y: 0 }}
              className="mt-6 p-4 rounded-xl bg-[#F0F7EE] border border-[#86EFAC] flex items-start gap-3"
            >
              <CheckCircle2 className="w-5 h-5 text-[#14532D] shrink-0 mt-0.5" />
              <div className="text-xs text-[#14532D] leading-relaxed">
                <strong>გილოცავ!</strong> სწორედ ასე იწყებოდა 1876 წელს იაკობ გოგებაშვილის „დედაენის“ პირველი გაკვეთილი — ორი ხმოვნითა და გაცოცხლებული ბუნებით.
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
}

// Interactive HTML5 Canvas Letter Tracing Pad
function LetterTracingPad({
  selectedLetter,
  onSelectLetter,
  tracedLetters,
  onMarkTraced,
}: {
  selectedLetter: (typeof GEORGIAN_ALPHABET)[number];
  onSelectLetter: (l: (typeof GEORGIAN_ALPHABET)[number]) => void;
  tracedLetters: string[];
  onMarkTraced: (char: string) => void;
}) {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const [drawing, setDrawing] = useState(false);
  const [strokeCount, setStrokeCount] = useState(0);
  const [inkColor, setInkColor] = useState('#7F1D1D');

  const clearCanvas = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    setStrokeCount(0);
  };

  useEffect(() => {
    clearCanvas();
  }, [selectedLetter.char]);

  const getPos = (e: React.PointerEvent<HTMLCanvasElement>) => {
    const rect = e.currentTarget.getBoundingClientRect();
    return {
      x: ((e.clientX - rect.left) / rect.width) * e.currentTarget.width,
      y: ((e.clientY - rect.top) / rect.height) * e.currentTarget.height,
    };
  };

  const handlePointerDown = (e: React.PointerEvent<HTMLCanvasElement>) => {
    e.currentTarget.setPointerCapture(e.pointerId);
    const ctx = e.currentTarget.getContext('2d');
    if (!ctx) return;
    const pos = getPos(e);
    ctx.strokeStyle = inkColor;
    ctx.lineWidth = 14;
    ctx.lineCap = 'round';
    ctx.lineJoin = 'round';
    ctx.beginPath();
    ctx.moveTo(pos.x, pos.y);
    setDrawing(true);
  };

  const handlePointerMove = (e: React.PointerEvent<HTMLCanvasElement>) => {
    if (!drawing) return;
    const ctx = e.currentTarget.getContext('2d');
    if (!ctx) return;
    const pos = getPos(e);
    ctx.lineTo(pos.x, pos.y);
    ctx.stroke();
    setStrokeCount((c) => c + 1);
  };

  const handlePointerUp = () => {
    if (!drawing) return;
    setDrawing(false);
    if (strokeCount > 12) {
      soundFX.playSuccess();
      onMarkTraced(selectedLetter.char);
    }
  };

  return (
    <div className="grid lg:grid-cols-12 gap-6">
      <div className="lg:col-span-5 vellum-card rounded-2xl p-5">
        <h2 className="font-serif text-lg font-bold text-[#231B15] mb-3">
          აირჩიე გამოსაწერი ასო
        </h2>
        <div className="grid grid-cols-6 gap-1.5">
          {GEORGIAN_ALPHABET.map((l) => {
            const done = tracedLetters.includes(l.char);
            return (
              <button
                key={l.char}
                onClick={() => onSelectLetter(l)}
                className={`h-11 rounded-lg font-serif text-lg font-bold border transition-colors cursor-pointer ${
                  selectedLetter.char === l.char
                    ? 'bg-[#7F1D1D] text-white border-[#7F1D1D]'
                    : done
                    ? 'bg-[#F0F7EE] text-[#14532D] border-[#86EFAC]'
                    : 'bg-[#FAF6EE] text-[#231B15] border-[#DDD2BE]'
                }`}
              >
                {l.char}
              </button>
            );
          })}
        </div>
      </div>

      <div className="lg:col-span-7 vellum-card rounded-2xl p-6 flex flex-col justify-between">
        <div className="flex flex-wrap items-center justify-between gap-3 mb-4">
          <div>
            <h3 className="font-serif text-xl font-bold text-[#231B15]">
              გამოწერე ასო „{selectedLetter.char}“ ({selectedLetter.name})
            </h3>
            <p className="text-xs text-[#5C4E42]">
              მიჰყევი მკრთალ კონტურს მაუსით ან თითით
            </p>
          </div>
          <div className="flex items-center gap-2">
            {['#7F1D1D', '#14532D', '#5B21B6', '#231B15'].map((c) => (
              <button
                key={c}
                onClick={() => setInkColor(c)}
                aria-label="მელნის ფერი"
                className={`w-6 h-6 rounded-full border-2 cursor-pointer ${
                  inkColor === c ? 'border-[#B8860B] scale-110' : 'border-white'
                }`}
                style={{ backgroundColor: c }}
              />
            ))}
            <button
              onClick={clearCanvas}
              className="px-3 py-1.5 rounded-lg border border-[#D8CBB3] text-xs font-medium bg-white hover:bg-[#FAF6EE] cursor-pointer"
            >
              გასუფთავება
            </button>
          </div>
        </div>

        {/* Notebook ruled canvas with faint guide letter */}
        <div className="relative h-72 rounded-xl border-2 border-[#D8CBB3] bg-[#FFFDF8] overflow-hidden touch-none">
          {/* Notebook guidelines */}
          <div className="absolute inset-x-0 top-1/4 border-t border-dashed border-[#CBD5E1]" />
          <div className="absolute inset-x-0 top-1/2 border-t border-[#94A3B8]/60" />
          <div className="absolute inset-x-0 top-3/4 border-t border-dashed border-[#CBD5E1]" />
          <div
            className="absolute inset-0 flex items-center justify-center font-serif text-[168px] font-bold text-[#231B15]/10 select-none pointer-events-none"
            aria-hidden="true"
          >
            {selectedLetter.char}
          </div>
          <canvas
            ref={canvasRef}
            width={560}
            height={288}
            onPointerDown={handlePointerDown}
            onPointerMove={handlePointerMove}
            onPointerUp={handlePointerUp}
            className="relative z-10 w-full h-full cursor-crosshair"
          />
        </div>

        <div className="mt-4 flex items-center justify-between text-xs">
          <span className="text-[#5C4E42]">
            {tracedLetters.includes(selectedLetter.char)
              ? '✓ ეს ასო წარმატებით გამოწერილია!'
              : 'შემოავლე კონტურს დასაფიქსირებლად'}
          </span>
          <span className="font-semibold text-[#7F1D1D]">
            სიტყვა: {selectedLetter.sampleWord}
          </span>
        </div>
      </div>
    </div>
  );
}

// Multi-activity Georgian Word & Sentence Workshop
function WordWorkshop() {
  const [mode, setMode] = useState<ExerciseMode>('syllables');
  const [idx, setIdx] = useState(0);
  const [picked, setPicked] = useState<string[]>([]);
  const [status, setStatus] = useState<'idle' | 'ok' | 'err'>('idle');

  const resetExercise = (newMode?: ExerciseMode, newIdx?: number) => {
    if (newMode) setMode(newMode);
    if (typeof newIdx === 'number') setIdx(newIdx);
    setPicked([]);
    setStatus('idle');
  };

  // 1. Syllables
  const sylItem = SYLLABLE_WORDS[idx % SYLLABLE_WORDS.length];
  const sylShuffled = [...sylItem.syllables].sort((a, b) => a.localeCompare(b));

  // 2. Scramble
  const puzzleItem = WORD_PUZZLES[idx % WORD_PUZZLES.length];

  // 3. Sentences
  const sentItem = SENTENCE_BUILDERS[idx % SENTENCE_BUILDERS.length];
  const sentOptions = [...sentItem.words, ...sentItem.distractors].sort();

  // 4. Missing letter
  const missingBank = [
    { shown: 'დ _ დ ა', full: 'დედა', answer: 'ე', choices: ['ე', 'ა', 'ო'] },
    { shown: 'ვ _ ზ ი', full: 'ვაზი', answer: 'ა', choices: ['უ', 'ა', 'ი'] },
    { shown: 'ქ ო თ _ ნ ი', full: 'ქოთანი', answer: 'ა', choices: ['ა', 'ე', 'ო'] },
    { shown: 'წ ი გ ნ _', full: 'წიგნი', answer: 'ი', choices: ['ა', 'ი', 'ე'] },
  ];
  const missItem = missingBank[idx % missingBank.length];

  // 5. First & Last letter
  const flBank = [
    { word: 'სამშობლო', first: 'ს', last: 'ო', choices: ['ს', 'მ', 'ო', 'ა'] },
    { word: 'მეგობარი', first: 'მ', last: 'ი', choices: ['მ', 'გ', 'ი', 'ე'] },
    { word: 'თავმდაბლობა', first: 'თ', last: 'ა', choices: ['თ', 'ვ', 'ბ', 'ა'] },
  ];
  const flItem = flBank[idx % flBank.length];

  // 6. Letter-to-Illustration match
  const matchItem = GEORGIAN_ALPHABET[(idx * 5) % GEORGIAN_ALPHABET.length];
  const matchChoices = [
    matchItem,
    GEORGIAN_ALPHABET[(idx * 5 + 3) % GEORGIAN_ALPHABET.length],
    GEORGIAN_ALPHABET[(idx * 5 + 7) % GEORGIAN_ALPHABET.length],
  ].sort((a, b) => a.char.localeCompare(b.char));

  const checkSequence = (next: string[], target: string[]) => {
    setPicked(next);
    if (next.length === target.length) {
      if (next.join('') === target.join('')) {
        soundFX.playSuccess();
        setStatus('ok');
      } else {
        soundFX.playError();
        setStatus('err');
      }
    }
  };

  return (
    <div className="vellum-card rounded-2xl p-6 space-y-6">
      <div className="flex flex-wrap gap-2 border-b border-[#EAE1D0] pb-4">
        {[
          { id: 'syllables', label: 'მარცვლებით სიტყვა' },
          { id: 'missing', label: 'გამოტოვებული ასო' },
          { id: 'scramble', label: 'არეული ასოები' },
          { id: 'first-last', label: 'პირველი და ბოლო ასო' },
          { id: 'sentences', label: 'წინადადების აწყობა' },
          { id: 'match', label: 'ასო და მნიშვნელობა' },
        ].map((m) => (
          <button
            key={m.id}
            onClick={() => resetExercise(m.id as ExerciseMode, 0)}
            className={`px-3.5 py-2 rounded-lg text-xs font-semibold border cursor-pointer transition-colors ${
              mode === m.id
                ? 'bg-[#7F1D1D] text-white border-[#7F1D1D]'
                : 'bg-[#FAF6EE] text-[#231B15] border-[#DDD2BE]'
            }`}
          >
            {m.label}
          </button>
        ))}
      </div>

      {mode === 'syllables' && (
        <div className="space-y-4">
          <div className="text-xs text-[#6B5B4E]">დააკავშირე მარცვლები: {sylItem.meaning}</div>
          <div className="flex flex-wrap gap-2 min-h-[52px] p-3 rounded-xl bg-[#FAF6EE] border border-dashed border-[#B8860B]">
            {picked.map((s, i) => (
              <span key={i} className="px-4 py-2 rounded-lg bg-[#231B15] text-white font-serif font-bold">
                {s}
              </span>
            ))}
          </div>
          <div className="flex flex-wrap gap-2">
            {sylShuffled.map((s, i) => (
              <button
                key={`${s}-${i}`}
                onClick={() => checkSequence([...picked, s], sylItem.syllables)}
                className="px-4 py-2.5 rounded-xl bg-white border border-[#D8CBB3] hover:border-[#7F1D1D] font-serif text-lg font-bold cursor-pointer"
              >
                {s}
              </button>
            ))}
          </div>
        </div>
      )}

      {mode === 'missing' && (
        <div className="space-y-4">
          <div className="text-xs text-[#6B5B4E]">აღმოაჩინე გამოტოვებული ასო:</div>
          <div className="font-serif text-4xl font-bold text-[#231B15] tracking-widest">
            {status === 'ok' ? missItem.full : missItem.shown}
          </div>
          <div className="flex gap-3">
            {missItem.choices.map((c) => (
              <button
                key={c}
                onClick={() => {
                  if (c === missItem.answer) {
                    soundFX.playSuccess();
                    setStatus('ok');
                  } else {
                    soundFX.playError();
                    setStatus('err');
                  }
                }}
                className="w-14 h-14 rounded-xl bg-[#FAF6EE] border border-[#D8CBB3] hover:border-[#14532D] font-serif text-2xl font-bold cursor-pointer"
              >
                {c}
              </button>
            ))}
          </div>
        </div>
      )}

      {mode === 'scramble' && (
        <div className="space-y-4">
          <div className="text-xs text-[#6B5B4E]">მინიშნება: {puzzleItem.hint}</div>
          <div className="flex flex-wrap gap-2 min-h-[54px] p-3 rounded-xl bg-[#FAF6EE] border border-dashed border-[#B8860B]">
            {picked.map((ch, i) => (
              <span key={i} className="w-11 h-11 rounded-lg bg-[#5B21B6] text-white flex items-center justify-center font-serif text-xl font-bold">
                {ch}
              </span>
            ))}
          </div>
          <div className="flex flex-wrap gap-2">
            {puzzleItem.scrambled.map((ch, i) => (
              <button
                key={`${ch}-${i}`}
                onClick={() => checkSequence([...picked, ch], puzzleItem.target.split(''))}
                className="w-12 h-12 rounded-xl bg-white border border-[#D8CBB3] hover:border-[#5B21B6] font-serif text-xl font-bold cursor-pointer"
              >
                {ch}
              </button>
            ))}
          </div>
        </div>
      )}

      {mode === 'first-last' && (
        <div className="space-y-4">
          <div className="text-xs text-[#6B5B4E]">
            აირჩიე ჯერ პირველი, შემდეგ კი ბოლო ასო სიტყვისთვის:
          </div>
          <div className="font-serif text-3xl font-bold text-[#7F1D1D]">{flItem.word}</div>
          <div className="flex gap-2 text-sm">
            <span>არჩეული: {picked.join(' — ') || '—'}</span>
          </div>
          <div className="flex gap-3">
            {flItem.choices.map((c) => (
              <button
                key={c}
                onClick={() => checkSequence([...picked, c], [flItem.first, flItem.last])}
                className="w-12 h-12 rounded-xl bg-white border border-[#D8CBB3] font-serif text-xl font-bold cursor-pointer"
              >
                {c}
              </button>
            ))}
          </div>
        </div>
      )}

      {mode === 'sentences' && (
        <div className="space-y-4">
          <div className="text-sm font-medium text-[#231B15]">{sentItem.prompt}</div>
          <div className="flex flex-wrap gap-2 min-h-[52px] p-3 rounded-xl bg-[#FAF6EE] border border-dashed border-[#B8860B]">
            {picked.map((w, i) => (
              <span key={i} className="px-3 py-1.5 rounded-lg bg-[#14532D] text-white text-sm font-semibold">
                {w}
              </span>
            ))}
          </div>
          <div className="flex flex-wrap gap-2">
            {sentOptions.map((w, i) => (
              <button
                key={`${w}-${i}`}
                onClick={() => checkSequence([...picked, w], sentItem.words)}
                className="px-3.5 py-2 rounded-xl bg-white border border-[#D8CBB3] hover:border-[#14532D] text-sm font-medium cursor-pointer"
              >
                {w}
              </button>
            ))}
          </div>
        </div>
      )}

      {mode === 'match' && (
        <div className="space-y-4">
          <div className="text-xs text-[#6B5B4E]">რომელი ასოთი იწყება სიტყვა „{matchItem.sampleWord}“ ({matchItem.botanicalSymbol})?</div>
          <div className="flex gap-4">
            {matchChoices.map((c) => (
              <button
                key={c.char}
                onClick={() => {
                  if (c.char === matchItem.char) {
                    soundFX.playSuccess();
                    setStatus('ok');
                  } else {
                    soundFX.playError();
                    setStatus('err');
                  }
                }}
                className="w-16 h-16 rounded-xl bg-white border border-[#D8CBB3] hover:border-[#B8860B] font-serif text-3xl font-bold cursor-pointer"
              >
                {c.char}
              </button>
            ))}
          </div>
        </div>
      )}

      {/* Feedback & Next */}
      <div className="flex flex-wrap items-center justify-between gap-3 pt-4 border-t border-[#EAE1D0]">
        <div>
          {status === 'ok' && (
            <span className="text-sm font-semibold text-[#14532D]">
              ✓ ბრავო! სწორად ააწყვე!
            </span>
          )}
          {status === 'err' && (
            <span className="text-sm font-semibold text-[#7F1D1D]">
              კიდევ სცადე — დააჭირე გასუფთავებას.
            </span>
          )}
        </div>
        <div className="flex gap-2">
          <button
            onClick={() => resetExercise()}
            className="px-3.5 py-2 rounded-lg border border-[#D8CBB3] text-xs font-medium cursor-pointer"
          >
            თავიდან
          </button>
          <button
            onClick={() => resetExercise(mode, idx + 1)}
            className="px-4 py-2 rounded-lg bg-[#231B15] text-white text-xs font-semibold cursor-pointer"
          >
            შემდეგი დავალება →
          </button>
        </div>
      </div>
    </div>
  );
}

// Visual Memory Pairs Game
function AlphabetMemoryGame() {
  const samplePool = [
    { id: 'ა', letter: 'ა', word: 'აი ია' },
    { id: 'დ', letter: 'დ', word: 'დედა' },
    { id: 'ვ', letter: 'ვ', word: 'ვაზი' },
    { id: 'ქ', letter: 'ქ', word: 'ქოთანი' },
    { id: 'ჭ', letter: 'ჭ', word: 'ჭიანჭველა' },
    { id: 'ჯ', letter: 'ჯ', word: 'ჯვარი' },
  ];

  const createDeck = () =>
    samplePool
      .flatMap((item) => [
        { key: `${item.id}-L`, pairId: item.id, display: item.letter, kind: 'ასო' },
        { key: `${item.id}-W`, pairId: item.id, display: item.word, kind: 'სიტყვა' },
      ])
      .sort(() => Math.random() - 0.5);

  const [cards, setCards] = useState(createDeck);
  const [flipped, setFlipped] = useState<string[]>([]);
  const [matched, setMatched] = useState<string[]>([]);

  const handleFlip = (key: string) => {
    if (flipped.includes(key) || flipped.length >= 2) return;
    const card = cards.find((c) => c.key === key);
    if (!card || matched.includes(card.pairId)) return;

    soundFX.playClick();
    const nextFlipped = [...flipped, key];
    setFlipped(nextFlipped);

    if (nextFlipped.length === 2) {
      const c1 = cards.find((c) => c.key === nextFlipped[0]);
      const c2 = cards.find((c) => c.key === nextFlipped[1]);
      if (c1 && c2 && c1.pairId === c2.pairId) {
        soundFX.playSuccess();
        setMatched((m) => [...m, c1.pairId]);
        setFlipped([]);
      } else {
        setTimeout(() => setFlipped([]), 750);
      }
    }
  };

  return (
    <div className="vellum-card rounded-2xl p-6 space-y-5">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="font-serif text-xl font-bold text-[#231B15]">
            ვიზუალური მეხსიერების თამაში (ასო ↔ სიტყვა)
          </h2>
          <p className="text-xs text-[#5C4E42]">
            დააწყვილე თითოეული ასო მის შესაბამის სიტყვასთან ({matched.length} / {samplePool.length})
          </p>
        </div>
        <button
          onClick={() => {
            setCards(createDeck());
            setFlipped([]);
            setMatched([]);
          }}
          className="px-3.5 py-2 rounded-lg border border-[#D8CBB3] text-xs font-medium cursor-pointer"
        >
          ახლიდან არევა
        </button>
      </div>

      <div className="grid grid-cols-3 sm:grid-cols-4 gap-3">
        {cards.map((card) => {
          const isOpen = flipped.includes(card.key) || matched.includes(card.pairId);
          const isSolved = matched.includes(card.pairId);
          return (
            <button
              key={card.key}
              onClick={() => handleFlip(card.key)}
              className={`h-24 rounded-xl border-2 transition-all flex flex-col items-center justify-center cursor-pointer ${
                isSolved
                  ? 'bg-[#F0F7EE] border-[#14532D] text-[#14532D]'
                  : isOpen
                  ? 'bg-[#FFFDF8] border-[#B8860B] text-[#231B15]'
                  : 'bg-[#7F1D1D] border-[#5C1414] text-[#FDE68A]'
              }`}
            >
              {isOpen ? (
                <>
                  <span className="text-[10px] text-[#6B5B4E]">{card.kind}</span>
                  <span className="font-serif text-lg sm:text-xl font-bold mt-0.5">
                    {card.display}
                  </span>
                </>
              ) : (
                <span className="font-serif text-lg font-bold">?</span>
              )}
            </button>
          );
        })}
      </div>
    </div>
  );
}
