import React, { useEffect, useRef, useState } from 'react';
import { motion } from 'motion/react';
import {
  Play,
  RotateCcw,
  Star,
  Volume2,
  VolumeX,
  ArrowLeft,
  ArrowRight,
  ArrowUp,
  ArrowDown,
  Trophy,
} from 'lucide-react';
import { StoryId } from '../../types';
import { soundFX } from '../../utils/sound';

interface StoryGameProps {
  storyId: StoryId;
  gameTitle: string;
  gameDescription: string;
  onFinishGame: (stars: number) => void;
}

type GamePhase = 'INTRO' | 'PLAYING' | 'VICTORY';

export function StoryGameContainer({
  storyId,
  gameTitle,
  gameDescription,
  onFinishGame,
}: StoryGameProps) {
  const [phase, setPhase] = useState<GamePhase>('INTRO');
  const [earnedStars, setEarnedStars] = useState(3);
  const [muted, setMuted] = useState(soundFX.muted);
  const [runKey, setRunKey] = useState(0);

  useEffect(() => {
    setPhase('INTRO');
    setRunKey((k) => k + 1);
  }, [storyId]);

  const toggleMute = () => {
    soundFX.muted = !muted;
    setMuted(soundFX.muted);
  };

  const handleVictory = (stars: number) => {
    soundFX.playBloom();
    setEarnedStars(stars);
    setPhase('VICTORY');
    onFinishGame(stars);
  };

  const handleRestart = () => {
    soundFX.playClick();
    setRunKey((k) => k + 1);
    setPhase('PLAYING');
  };

  return (
    <div className="vellum-card rounded-2xl overflow-hidden">
      {/* Game HUD Top Bar */}
      <div className="flex flex-wrap items-center justify-between gap-3 px-5 py-3.5 bg-[#231B15] text-[#FAF6EE]">
        <div>
          <span className="text-[11px] text-[#FDE68A]/80">ინტერაქტიული ვიდეოთამაში</span>
          <h3 className="font-serif text-lg font-bold">{gameTitle}</h3>
        </div>
        <div className="flex items-center gap-2">
          <button
            onClick={toggleMute}
            aria-label={muted ? 'ხმის ჩართვა' : 'ხმის გამორთვა'}
            className="p-2 rounded-lg bg-white/10 hover:bg-white/20 transition-colors cursor-pointer"
          >
            {muted ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
          </button>
          {phase !== 'INTRO' && (
            <button
              onClick={handleRestart}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-white/10 hover:bg-white/20 text-xs font-medium cursor-pointer"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span>თავიდან</span>
            </button>
          )}
        </div>
      </div>

      {/* Intro Screen */}
      {phase === 'INTRO' && (
        <div className="p-8 sm:p-12 text-center bg-gradient-to-b from-[#FAF6EE] to-[#F2E9D8] space-y-6">
          <div className="max-w-xl mx-auto space-y-3">
            <div className="text-xs font-semibold text-[#7F1D1D]">სიუჟეტური მისია</div>
            <h4 className="font-serif text-2xl sm:text-3xl font-bold text-[#231B15]">
              {gameTitle}
            </h4>
            <p className="text-sm text-[#4A3B31] leading-relaxed">{gameDescription}</p>
            <p className="text-xs text-[#6B5B4E] pt-2">
              მართვა შესაძლებელია მაუსით, სენსორული ეკრანითა და კლავიატურის ისრებით.
            </p>
          </div>
          <button
            onClick={() => {
              soundFX.playClick();
              setPhase('PLAYING');
            }}
            className="inline-flex items-center gap-2 px-7 py-3.5 rounded-xl bg-[#7F1D1D] hover:bg-[#991B1B] text-white font-semibold text-sm shadow-md transition-colors cursor-pointer"
          >
            <Play className="w-4 h-4" />
            <span>თამაშის დაწყება</span>
          </button>
        </div>
      )}

      {/* Active Game */}
      {phase === 'PLAYING' && (
        <div key={runKey} className="p-4 sm:p-6 bg-[#FAF6EE]">
          {storyId === 'pot' && <Game1PotteryTheatre onWin={handleVictory} />}
          {storyId === 'friends' && <Game2KindnessBridge onWin={handleVictory} />}
          {storyId === 'erekle' && <Game3ErekleAdventure onWin={handleVictory} />}
          {storyId === 'ants' && <Game4AntsEngineering onWin={handleVictory} />}
          {storyId === 'nino' && <Game5StNinoLight onWin={handleVictory} />}
        </div>
      )}

      {/* Victory Scene */}
      {phase === 'VICTORY' && (
        <div className="p-8 sm:p-12 text-center bg-gradient-to-b from-[#FFFDF8] to-[#F0F7EE] space-y-5">
          <motion.div
            initial={{ scale: 0.7, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            className="w-16 h-16 mx-auto rounded-2xl bg-[#14532D] text-[#FDE68A] flex items-center justify-center shadow-lg"
          >
            <Trophy className="w-8 h-8" />
          </motion.div>
          <h4 className="font-serif text-2xl sm:text-3xl font-bold text-[#14532D]">
            მისია წარმატებით დასრულდა!
          </h4>
          <div className="flex items-center justify-center gap-2">
            {[1, 2, 3].map((s) => (
              <Star
                key={s}
                className={`w-8 h-8 ${
                  s <= earnedStars ? 'fill-[#D4A017] text-[#B8860B]' : 'text-[#D6CEBE]'
                }`}
              />
            ))}
          </div>
          <p className="text-sm text-[#4A3B31] max-w-md mx-auto">
            შენ მოიპოვე {earnedStars} ვარსკვლავი და გაიაზრე ნაწარმოების მთავარი ღირებულება!
          </p>
          <button
            onClick={handleRestart}
            className="inline-flex items-center gap-2 px-6 py-3 rounded-xl bg-[#231B15] hover:bg-[#3A2D23] text-white text-sm font-semibold cursor-pointer"
          >
            <RotateCcw className="w-4 h-4" />
            <span>ხელახლა თამაში</span>
          </button>
        </div>
      )}
    </div>
  );
}

/* =========================================================================
   GAME 1: ქოთნების თეატრი (სახელოსნო, ციცხვით სიმართლის შემოწმება, დიალოგი)
   ========================================================================= */
function Game1PotteryTheatre({ onWin }: { onWin: (stars: number) => void }) {
  const [stage, setStage] = useState<1 | 2 | 3>(1);
  const [listenedIds, setListenedIds] = useState<string[]>([]);
  const [ladleX, setLadleX] = useState(82); // percentage
  const [inspected, setInspected] = useState<string[]>([]);
  const [feedback, setFeedback] = useState(
    'ეტაპი 1: მოუსმინე სახელოსნოში შეკრებილ თითოეულ ქოთანს (დააჭირე ქოთნებს).'
  );
  const [sequence, setSequence] = useState<string[]>([]);

  const pots = [
    { id: 'small', name: 'პატარა ქოთანი', x: 20, speech: '„მე უბრალო თიხის ქოთანი ვარ და წყალს ვინახავ.“', truth: 'ჩვეულებრივი თიხის ძირი!' },
    { id: 'tall', name: 'მაღალი ქოთანი', x: 50, speech: '„მე თქვენისთანა როდი ვარ, მე ოქროს ძირი მაქვსო!“', truth: 'აჰა! ჩვეულებრივი გამომწვარი თიხის ძირი ჰქონია!' },
    { id: 'wide', name: 'განიერი ქოთანი', x: 75, speech: '„მე სუფთა თიხით ვარ ნაძერწი და ამით ვამაყობ.“', truth: 'სუფთა თიხის ძირი!' },
  ];

  // Keyboard support for Stage 2 ladle movement
  useEffect(() => {
    if (stage !== 2) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'ArrowLeft') {
        e.preventDefault();
        setLadleX((x) => Math.max(12, x - 6));
      } else if (e.key === 'ArrowRight') {
        e.preventDefault();
        setLadleX((x) => Math.min(88, x + 6));
      }
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [stage]);

  const handlePotInspect = (pot: (typeof pots)[number]) => {
    soundFX.playClick();
    if (stage === 1) {
      setFeedback(`${pot.name}: ${pot.speech}`);
      if (!listenedIds.includes(pot.id)) {
        const next = [...listenedIds, pot.id];
        setListenedIds(next);
        if (next.length === 3) {
          soundFX.playSuccess();
          setTimeout(() => {
            setStage(2);
            setFeedback('ეტაპი 2: გამოჩნდა ციცხვი! გადაადგილე ციცხვი ქოთნებთან და შეამოწმე მაღალი ქოთნის ძირი.');
          }, 900);
        }
      }
    } else if (stage === 2) {
      setLadleX(pot.x);
      if (!inspected.includes(pot.id)) {
        const next = [...inspected, pot.id];
        setInspected(next);
        setFeedback(`ციცხვმა შეამოწმა ${pot.name}: ${pot.truth}`);
        if (pot.id === 'tall') {
          soundFX.playSuccess();
          setTimeout(() => {
            setStage(3);
            setFeedback('ეტაპი 3: დაალაგე იგავის სწორი დასასრული თანმიმდევრობით!');
          }, 1100);
        }
      }
    }
  };

  const stage3Cards = [
    { id: 'c1', text: '1. მაღალმა ქოთანმა ოქროს ძირით დაიკვეხნა.' },
    { id: 'c2', text: '2. ციცხვმა სიმართლე გაამჟღავნა.' },
    { id: 'c3', text: '3. მკვეხარა ქოთანს შერცხვა და ხმა გაკმინდა.' },
  ];

  const handlePickSeq = (id: string) => {
    if (sequence.includes(id)) return;
    soundFX.playClick();
    const next = [...sequence, id];
    setSequence(next);
    if (next.length === 3) {
      if (next[0] === 'c1' && next[1] === 'c2' && next[2] === 'c3') {
        onWin(3);
      } else {
        soundFX.playError();
        setFeedback('თანმიმდევრობა არეულია — სცადე თავიდან!');
        setTimeout(() => setSequence([]), 700);
      }
    }
  };

  return (
    <div className="space-y-5">
      <div className="flex flex-wrap items-center justify-between gap-2 text-xs">
        <span className="font-semibold text-[#7F1D1D]">ეტაპი {stage} / 3</span>
        <span className="text-[#4A3B31] font-medium">{feedback}</span>
      </div>

      {stage !== 3 ? (
        <div className="relative h-72 rounded-xl bg-gradient-to-b from-[#EFE4CF] to-[#D8C29D] border border-[#C9B38C] overflow-hidden p-4 select-none">
          {/* Wooden shelf */}
          <div className="absolute bottom-10 inset-x-6 h-4 bg-[#78350F] rounded shadow" />

          {/* Moving Ladle in Stage 2 */}
          {stage === 2 && (
            <motion.div
              animate={{ left: `${ladleX}%` }}
              transition={{ type: 'spring', stiffness: 160, damping: 20 }}
              className="absolute top-12 -translate-x-1/2 z-20 pointer-events-none flex flex-col items-center"
            >
              <div className="w-3 h-20 bg-[#78350F] rounded-t-full" />
              <div className="w-9 h-6 bg-[#B45309] rounded-full border-2 border-[#78350F]" />
              <span className="text-[10px] font-bold bg-[#FFFDF8] px-1.5 rounded mt-1 border border-[#B8860B]">
                ციცხვი
              </span>
            </motion.div>
          )}

          {/* Pots */}
          {pots.map((pot) => {
            const isTall = pot.id === 'tall';
            const checked = listenedIds.includes(pot.id) || inspected.includes(pot.id);
            return (
              <button
                key={pot.id}
                onClick={() => handlePotInspect(pot)}
                style={{ left: `${pot.x}%` }}
                className="absolute bottom-14 -translate-x-1/2 flex flex-col items-center group cursor-pointer"
              >
                <div
                  className={`rounded-t-2xl rounded-b-3xl border-2 transition-transform group-hover:scale-105 flex items-center justify-center ${
                    isTall ? 'w-16 h-28 bg-[#9A3412]' : 'w-14 h-20 bg-[#B45309]'
                  } ${checked ? 'border-[#D4A017] ring-2 ring-[#D4A017]/40' : 'border-[#7C2D12]'}`}
                >
                  <div className="flex gap-2 -mt-4">
                    <span className="w-2 h-2 rounded-full bg-[#231B15]" />
                    <span className="w-2 h-2 rounded-full bg-[#231B15]" />
                  </div>
                </div>
                <span className="mt-2 px-2 py-0.5 rounded bg-[#FFFDF8]/90 text-[11px] font-semibold text-[#231B15] whitespace-nowrap">
                  {pot.name}
                </span>
              </button>
            );
          })}
        </div>
      ) : (
        <div className="space-y-3 p-4 rounded-xl bg-[#FFFDF8] border border-[#DDD2BE]">
          <div className="text-xs text-[#6B5B4E]">დააჭირე სწორი თანმიმდევრობით:</div>
          <div className="grid sm:grid-cols-3 gap-3">
            {[stage3Cards[1], stage3Cards[2], stage3Cards[0]].map((card) => {
              const selectedOrder = sequence.indexOf(card.id);
              return (
                <button
                  key={card.id}
                  onClick={() => handlePickSeq(card.id)}
                  className={`p-4 rounded-xl border text-left text-sm font-medium transition-colors cursor-pointer ${
                    selectedOrder >= 0
                      ? 'bg-[#14532D] text-white border-[#14532D]'
                      : 'bg-[#FAF6EE] text-[#231B15] border-[#D8CBB3] hover:border-[#7F1D1D]'
                  }`}
                >
                  {card.text}
                </button>
              );
            })}
          </div>
        </div>
      )}

      {stage === 2 && (
        <div className="flex items-center justify-center gap-3">
          <button
            onClick={() => setLadleX((x) => Math.max(15, x - 15))}
            className="px-4 py-2 rounded-lg border border-[#D8CBB3] bg-white text-xs font-medium inline-flex items-center gap-1 cursor-pointer"
          >
            <ArrowLeft className="w-4 h-4" /> მარცხნივ
          </button>
          <button
            onClick={() => setLadleX((x) => Math.min(85, x + 15))}
            className="px-4 py-2 rounded-lg border border-[#D8CBB3] bg-white text-xs font-medium inline-flex items-center gap-1 cursor-pointer"
          >
            მარჯვნივ <ArrowRight className="w-4 h-4" />
          </button>
        </div>
      )}
    </div>
  );
}

/* =========================================================================
   GAME 2: გულის ხიდი — სკოლის ეზო (ემპათიისა და ნაბიჯების თავგადასავალი)
   ========================================================================= */
function Game2KindnessBridge({ onWin }: { onWin: (stars: number) => void }) {
  const [step, setStep] = useState(0); // 0..2
  const [ninoX, setNinoX] = useState(14);
  const [warmth, setWarmth] = useState(25);
  const [msg, setMsg] = useState('დაეხმარე ნინოს სკოლის კარამდე მისვლაში და აირჩიე კეთილი ქმედება.');

  const checkpoints = [
    {
      targetX: 35,
      prompt: 'ნინო სკოლის ჭიშკართან ჩერდება და ღელავს, როგორ შეხვდებიან ბავშვები.',
      options: [
        { text: 'გვერდზე გავიხედოთ და გავეცალოთ.', warm: false, reply: 'სიჩუმე შიშს ვერ გაფანტავს. სცადე კეთილი სიტყვა!' },
        { text: 'მივუახლოვდეთ ღიმილით და ვუთხრათ: „კეთილი იყოს შენი დაბრუნება!“', warm: true, reply: 'სითბო მოემატა! ნინოს ნაბიჯი უფრო თამამი გახდა.' },
      ],
    },
    {
      targetX: 60,
      prompt: 'საკლასო ოთახის კართან ნინო გაფითრებული დგას. კატო ამჩნევს მის ღელვას.',
      options: [
        { text: 'კატო უწვდის ხელს და ეუბნება: „ერთად დავსხდეთ მერხთან“.', warm: true, reply: 'შესანიშნავია! კატოს თანაგრძნობამ შიში გააქრო!' },
        { text: 'ძველი წყენა გავიხსენოთ.', warm: false, reply: 'წარსული წყენის გახსენება გულს სტკენს. აირჩიე პატიება.' },
      ],
    },
    {
      targetX: 84,
      prompt: 'კლასელები წრეში იკრიბებიან და ნინოს შვების ცრემლი მოსდის.',
      options: [
        { text: 'გავამხნევოთ მეგობრული სიტყვებით და ერთად გავაგრძელოთ გაკვეთილი.', warm: true, reply: 'გულის ხიდი აშენდა!' },
        { text: 'მარტო დავტოვოთ კუთხეში.', warm: false, reply: 'სიმარტოვე სევდას ტოვებს — მეგობრები ერთად არიან.' },
      ],
    },
  ];

  const current = checkpoints[step];

  const handleWalk = (dir: number) => {
    soundFX.playClick();
    setNinoX((x) => Math.max(10, Math.min(current.targetX, x + dir * 8)));
  };

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'ArrowRight') {
        e.preventDefault();
        handleWalk(1);
      } else if (e.key === 'ArrowLeft') {
        e.preventDefault();
        handleWalk(-1);
      }
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  });

  const handleChoice = (warm: boolean, reply: string) => {
    setMsg(reply);
    if (warm) {
      soundFX.playSuccess();
      setWarmth((w) => Math.min(100, w + 25));
      if (step < checkpoints.length - 1) {
        setStep((s) => s + 1);
      } else {
        setTimeout(() => onWin(3), 700);
      }
    } else {
      soundFX.playError();
    }
  };

  return (
    <div className="space-y-5">
      <div className="flex items-center justify-between text-xs">
        <span className="font-semibold text-[#14532D]">გულისხმიერების სინათლე: {warmth}%</span>
        <div className="w-40 h-2.5 rounded-full bg-[#E2D6C1] overflow-hidden">
          <div className="h-full bg-[#14532D] transition-all" style={{ width: `${warmth}%` }} />
        </div>
      </div>

      {/* Schoolyard Stage */}
      <div
        className="relative h-56 rounded-xl border border-[#CBB896] overflow-hidden transition-colors duration-500"
        style={{
          background: `linear-gradient(180deg, rgba(253,230,138,${warmth / 200}) 0%, #E7EFE0 100%)`,
        }}
      >
        {/* School building on right */}
        <div className="absolute right-6 bottom-8 w-28 h-28 bg-[#FFFDF8] border-2 border-[#CBB896] rounded-t-lg flex items-center justify-center text-xs font-serif font-bold text-[#7F1D1D]">
          სკოლა
        </div>
        <div className="absolute bottom-0 inset-x-0 h-8 bg-[#C7D7AE]" />

        {/* Nino moving */}
        <motion.div
          animate={{ left: `${ninoX}%` }}
          className="absolute bottom-8 -translate-x-1/2 flex flex-col items-center"
        >
          <div className="w-8 h-8 rounded-full bg-[#F3D0B1] border-2 border-[#7F1D1D]" />
          <div className="w-10 h-11 rounded-t-xl bg-[#9D174D]" />
          <span className="text-[10px] font-bold bg-white/90 px-1.5 rounded mt-0.5">ნინო</span>
        </motion.div>

        {/* Kato waiting kindly */}
        <div
          style={{ left: `${current.targetX + 8}%` }}
          className="absolute bottom-8 -translate-x-1/2 flex flex-col items-center"
        >
          <div className="w-8 h-8 rounded-full bg-[#F3D0B1] border-2 border-[#14532D]" />
          <div className="w-10 h-11 rounded-t-xl bg-[#1E6B43]" />
          <span className="text-[10px] font-bold bg-white/90 px-1.5 rounded mt-0.5">კატო</span>
        </div>
      </div>

      {/* Controls & Choice */}
      <div className="p-4 rounded-xl bg-[#FFFDF8] border border-[#DDD2BE] space-y-3">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <p className="text-sm font-medium text-[#231B15]">{current.prompt}</p>
          <button
            onClick={() => handleWalk(1)}
            className="px-3 py-1.5 rounded-lg bg-[#231B15] text-white text-xs font-medium cursor-pointer"
          >
            ნაბიჯი წინ →
          </button>
        </div>
        <p className="text-xs text-[#14532D] font-medium">{msg}</p>
        <div className="grid sm:grid-cols-2 gap-3 pt-1">
          {current.options.map((opt, idx) => (
            <button
              key={idx}
              onClick={() => handleChoice(opt.warm, opt.reply)}
              className="p-3.5 rounded-xl border border-[#D8CBB3] bg-[#FAF6EE] hover:border-[#14532D] text-left text-xs sm:text-sm font-medium cursor-pointer transition-colors"
            >
              {opt.text}
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}

/* =========================================================================
   GAME 3: საინგილოდან კრწანისამდე (3 ეტაპი: ქლიავის ხე, მზითევის ურემი, ფარი)
   ========================================================================= */
function Game3ErekleAdventure({ onWin }: { onWin: (stars: number) => void }) {
  const [stage, setStage] = useState<1 | 2 | 3>(1);
  const [hatRemoved, setHatRemoved] = useState(false);
  const [lane, setLane] = useState(1); // 0, 1, 2
  const [progressDist, setProgressDist] = useState(0);
  const [shieldX, setShieldX] = useState(50);
  const [defended, setDefended] = useState(0);
  const [feedback, setFeedback] = useState('ეტაპი 1: დააკვირდი მხედარს — გაიგე, ვინ შემოდის ორღობეში!');

  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const laneRef = useRef(lane);
  laneRef.current = lane;
  const shieldRef = useRef(shieldX);
  shieldRef.current = shieldX;

  // Stage 2: Dowry Cart Escort on Canvas
  useEffect(() => {
    if (stage !== 2) return;
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let rafId = 0;
    let dist = 0;
    const obstacles = [
      { x: 1.0, lane: 0 },
      { x: 1.45, lane: 2 },
      { x: 1.9, lane: 1 },
      { x: 2.35, lane: 0 },
    ];

    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'ArrowUp') {
        e.preventDefault();
        setLane((l) => Math.max(0, l - 1));
      } else if (e.key === 'ArrowDown') {
        e.preventDefault();
        setLane((l) => Math.min(2, l + 1));
      }
    };
    window.addEventListener('keydown', onKey);

    const loop = () => {
      const w = (canvas.width = canvas.offsetWidth);
      const h = (canvas.height = canvas.offsetHeight);
      ctx.fillStyle = '#EFE3CA';
      ctx.fillRect(0, 0, w, h);

      // 3 lanes
      const laneH = h / 3;
      for (let i = 0; i < 3; i++) {
        ctx.strokeStyle = '#CBB896';
        ctx.strokeRect(0, i * laneH, w, laneH);
      }

      // Draw cart
      const cartY = laneRef.current * laneH + laneH / 2;
      ctx.fillStyle = '#7F1D1D';
      ctx.beginPath();
      ctx.roundRect(50, cartY - 18, 48, 36, 6);
      ctx.fill();
      ctx.fillStyle = '#D4A017';
      ctx.beginPath();
      ctx.arc(60, cartY + 20, 7, 0, Math.PI * 2);
      ctx.arc(88, cartY + 20, 7, 0, Math.PI * 2);
      ctx.fill();

      // Move obstacles
      dist += 0.005;
      obstacles.forEach((o) => {
        o.x -= 0.009;
        if (o.x < -0.1) {
          o.x = 1.2 + Math.random() * 0.5;
          o.lane = Math.floor(Math.random() * 3);
        }
        const ox = o.x * w;
        const oy = o.lane * laneH + laneH / 2;
        ctx.fillStyle = '#5C4E42';
        ctx.beginPath();
        ctx.arc(ox, oy, 14, 0, Math.PI * 2);
        ctx.fill();

        if (Math.abs(ox - 74) < 26 && o.lane === laneRef.current) {
          dist = Math.max(0, dist - 0.15);
          o.x = 1.4;
          soundFX.playError();
        }
      });

      const pct = Math.min(100, Math.round(dist * 100));
      setProgressDist(pct);

      if (pct >= 100) {
        soundFX.playSuccess();
        setStage(3);
        setFeedback('ეტაპი 3: კრწანისის ფარი — დაიცავი მეფე ერეკლე (ისრებით ან ღილაკებით)!');
        return;
      }

      rafId = requestAnimationFrame(loop);
    };

    rafId = requestAnimationFrame(loop);
    return () => {
      cancelAnimationFrame(rafId);
      window.removeEventListener('keydown', onKey);
    };
  }, [stage]);

  // Stage 3: Krtsanisi Shield Defense
  useEffect(() => {
    if (stage !== 3) return;
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let rafId = 0;
    let blocked = 0;
    const projectiles = Array.from({ length: 3 }, (_, i) => ({
      x: 0.2 + i * 0.3,
      y: -i * 0.35,
      speed: 0.008 + i * 0.001,
    }));

    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'ArrowLeft') {
        e.preventDefault();
        setShieldX((x) => Math.max(12, x - 8));
      } else if (e.key === 'ArrowRight') {
        e.preventDefault();
        setShieldX((x) => Math.min(88, x + 8));
      }
    };
    window.addEventListener('keydown', onKey);

    const loop = () => {
      const w = (canvas.width = canvas.offsetWidth);
      const h = (canvas.height = canvas.offsetHeight);
      ctx.fillStyle = '#E5D5BE';
      ctx.fillRect(0, 0, w, h);

      // Shield
      const sx = (shieldRef.current / 100) * w;
      const sy = h - 42;
      ctx.fillStyle = '#B8860B';
      ctx.strokeStyle = '#7F1D1D';
      ctx.lineWidth = 4;
      ctx.beginPath();
      ctx.roundRect(sx - 44, sy - 10, 88, 18, 9);
      ctx.fill();
      ctx.stroke();

      // Incoming arrows
      projectiles.forEach((p) => {
        p.y += p.speed;
        const px = p.x * w;
        const py = p.y * h;
        ctx.fillStyle = '#231B15';
        ctx.beginPath();
        ctx.moveTo(px, py + 10);
        ctx.lineTo(px - 5, py - 8);
        ctx.lineTo(px + 5, py - 8);
        ctx.closePath();
        ctx.fill();

        if (py >= sy - 12 && py <= sy + 16 && Math.abs(px - sx) < 48) {
          blocked += 1;
          setDefended(blocked);
          soundFX.playSuccess();
          p.y = -0.15;
          p.x = 0.15 + Math.random() * 0.7;
        } else if (py > h) {
          p.y = -0.1;
          p.x = 0.15 + Math.random() * 0.7;
        }
      });

      if (blocked >= 6) {
        onWin(3);
        return;
      }

      rafId = requestAnimationFrame(loop);
    };

    rafId = requestAnimationFrame(loop);
    return () => {
      cancelAnimationFrame(rafId);
      window.removeEventListener('keydown', onKey);
    };
  }, [stage, onWin]);

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-center justify-between gap-2 text-xs">
        <span className="font-semibold text-[#7F1D1D]">ეტაპი {stage} / 3</span>
        <span className="text-[#4A3B31] font-medium">{feedback}</span>
      </div>

      {stage === 1 && (
        <div className="p-6 rounded-xl bg-[#EFE4CF] border border-[#CBB896] text-center space-y-5">
          <div className="font-serif text-lg font-bold text-[#231B15]">
            {hatRemoved
              ? 'მეფე ერეკლემ სპარსული ქუდი მოიხადა და გულიანად გაიცინა!'
              : 'მხედარს თავზე სპარსული ქუდი ახურავს. გოგონა ფიქრობს, რომ ეს მტერია!'}
          </div>
          <div className="flex flex-wrap justify-center gap-3">
            {!hatRemoved ? (
              <button
                onClick={() => {
                  soundFX.playClick();
                  setHatRemoved(true);
                  setFeedback('ყოჩაღ! გოგონას თამამმა პასუხმა მეფეს ქართული თავი დაანახვა.');
                }}
                className="px-5 py-3 rounded-xl bg-[#5B21B6] text-white text-sm font-semibold cursor-pointer"
              >
                მუჭა ქლიავის სროლა ხიდან!
              </button>
            ) : (
              <button
                onClick={() => {
                  soundFX.playSuccess();
                  setStage(2);
                  setFeedback('ეტაპი 2: მიაცილე მეფის გამოგზავნილი მზითვის ურემი საინგილომდე (ისრებით ზემოთ/ქვემოთ)!');
                }}
                className="px-5 py-3 rounded-xl bg-[#14532D] text-white text-sm font-semibold cursor-pointer"
              >
                „მეფე ერეკლეს გაუმარჯოს!“ → შემდეგი ეტაპი
              </button>
            )}
          </div>
        </div>
      )}

      {stage === 2 && (
        <div className="space-y-3">
          <div className="text-xs font-semibold text-[#14532D] tabular-nums">
            მზითვის გზა საინგილომდე: {progressDist}%
          </div>
          <canvas ref={canvasRef} className="w-full h-56 rounded-xl border border-[#CBB896]" />
          <div className="flex justify-center gap-3">
            <button
              onClick={() => setLane((l) => Math.max(0, l - 1))}
              className="px-4 py-2 rounded-lg bg-white border border-[#D8CBB3] text-xs font-medium inline-flex items-center gap-1 cursor-pointer"
            >
              <ArrowUp className="w-4 h-4" /> ზედა ზოლი
            </button>
            <button
              onClick={() => setLane((l) => Math.min(2, l + 1))}
              className="px-4 py-2 rounded-lg bg-white border border-[#D8CBB3] text-xs font-medium inline-flex items-center gap-1 cursor-pointer"
            >
              <ArrowDown className="w-4 h-4" /> ქვედა ზოლი
            </button>
          </div>
        </div>
      )}

      {stage === 3 && (
        <div className="space-y-3">
          <div className="text-xs font-semibold text-[#7F1D1D] tabular-nums">
            მოგერიებული საფრთხე: {defended} / 6
          </div>
          <canvas ref={canvasRef} className="w-full h-56 rounded-xl border border-[#CBB896]" />
          <div className="flex justify-center gap-3">
            <button
              onClick={() => setShieldX((x) => Math.max(12, x - 14))}
              className="px-4 py-2 rounded-lg bg-white border border-[#D8CBB3] text-xs font-medium inline-flex items-center gap-1 cursor-pointer"
            >
              <ArrowLeft className="w-4 h-4" /> ფარი მარცხნივ
            </button>
            <button
              onClick={() => setShieldX((x) => Math.min(88, x + 14))}
              className="px-4 py-2 rounded-lg bg-white border border-[#D8CBB3] text-xs font-medium inline-flex items-center gap-1 cursor-pointer"
            >
              ფარი მარჯვნივ <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      )}
    </div>
  );
}

/* =========================================================================
   GAME 4: გონიერი კოლონიის ინჟინერია (ფოთლის პარაშუტი, მიწის ხიდი, ცოცხალი ხიდი)
   ========================================================================= */
function Game4AntsEngineering({ onWin }: { onWin: (stars: number) => void }) {
  const [stage, setStage] = useState<1 | 2 | 3>(1);
  const [rescuedLeafAnts, setRescuedLeafAnts] = useState(0);
  const [mudPellets, setMudPellets] = useState(0);
  const [livingAnts, setLivingAnts] = useState(0);
  const [leafY, setLeafY] = useState(10);

  // Stage 1: Animated falling leaf parachute timing
  useEffect(() => {
    if (stage !== 1) return;
    const id = setInterval(() => {
      setLeafY((y) => (y >= 90 ? 10 : y + 4));
    }, 80);
    return () => clearInterval(id);
  }, [stage]);

  const handleCatchLeaf = () => {
    if (leafY >= 45 && leafY <= 82) {
      soundFX.playSuccess();
      const next = rescuedLeafAnts + 1;
      setRescuedLeafAnts(next);
      if (next >= 3) {
        setTimeout(() => setStage(2), 600);
      }
    } else {
      soundFX.playError();
    }
  };

  return (
    <div className="space-y-4">
      <div className="text-xs font-semibold text-[#3F6212]">
        ეტაპი {stage} / 3 ·{' '}
        {stage === 1
          ? 'დაეშვი გაყვითლებული ფოთლით (დააჭირე „დაშვება“, როცა ფოთოლი მწვანე ზონაშია)'
          : stage === 2
          ? 'მოზიდე სველი მიწის 5 ნამცეცი თამბაქოს სალტეზე ხიდის ასაშენებლად'
          : 'შეკარი 5 გმირი ჭიანჭველათი ცოცხალი ხიდი წყლის თხრილზე!'}
      </div>

      {stage === 1 && (
        <div className="relative h-64 rounded-xl bg-gradient-to-b from-[#EAF4E4] to-[#D2E2B8] border border-[#B8CCA0] overflow-hidden p-4">
          <div className="text-xs font-semibold text-[#14532D] tabular-nums">
            დაშვებული მზვერავები: {rescuedLeafAnts} / 3
          </div>
          {/* Safe green landing zone */}
          <div className="absolute inset-x-0 top-[48%] h-[30%] bg-[#22C55E]/20 border-y border-dashed border-[#15803D]" />

          {/* Falling yellow leaf with ant */}
          <div
            style={{ top: `${leafY}%` }}
            className="absolute left-1/2 -translate-x-1/2 w-16 h-8 rounded-full bg-[#EAB308] border border-[#A16207] flex items-center justify-center shadow"
          >
            <span className="w-3 h-2 rounded-full bg-[#231B15]" />
          </div>

          <button
            onClick={handleCatchLeaf}
            className="absolute bottom-4 left-1/2 -translate-x-1/2 px-6 py-2.5 rounded-xl bg-[#14532D] text-white text-xs font-semibold cursor-pointer"
          >
            დაშვება ფოთლით!
          </button>
        </div>
      )}

      {stage === 2 && (
        <div className="p-6 rounded-xl bg-[#EFE4CF] border border-[#CBB896] text-center space-y-5">
          <div className="text-sm font-medium text-[#231B15]">
            სველი მიწის ნამცეცები სალტეზე: <strong className="tabular-nums">{mudPellets} / 5</strong>
          </div>
          <div className="w-48 h-28 mx-auto rounded-xl bg-[#6B4F35] relative overflow-hidden flex items-center justify-center">
            <div className="absolute inset-x-0 h-6 bg-[#3F2E18]" />
            <div
              className="relative z-10 h-8 bg-[#A16207] rounded transition-all"
              style={{ width: `${(mudPellets / 5) * 140}px` }}
            />
          </div>
          <button
            onClick={() => {
              soundFX.playClick();
              const next = mudPellets + 1;
              setMudPellets(next);
              if (next >= 5) {
                soundFX.playSuccess();
                setTimeout(() => setStage(3), 650);
              }
            }}
            className="px-6 py-3 rounded-xl bg-[#78350F] hover:bg-[#92400E] text-white text-sm font-semibold cursor-pointer"
          >
            მიაგლისე სველი მიწა (+1)
          </button>
        </div>
      )}

      {stage === 3 && (
        <div className="p-6 rounded-xl bg-[#E0F2FE] border border-[#7DD3FC] text-center space-y-5">
          <div className="text-sm font-medium text-[#0C4A6E]">
            წყლით სავსე თხრილზე ცოცხალი ხიდი: <strong className="tabular-nums">{livingAnts} / 5</strong>
          </div>
          <div className="h-20 rounded-xl bg-[#0284C7] flex items-center justify-center gap-2 px-4">
            {Array.from({ length: 5 }).map((_, i) => (
              <div
                key={i}
                className={`w-12 h-7 rounded-full border-2 flex items-center justify-center transition-all ${
                  i < livingAnts
                    ? 'bg-[#231B15] border-[#FDE68A] scale-105'
                    : 'bg-white/20 border-dashed border-white/60'
                }`}
              >
                {i < livingAnts && <span className="w-2 h-2 rounded-full bg-[#FDE68A]" />}
              </div>
            ))}
          </div>
          <button
            onClick={() => {
              soundFX.playClick();
              const next = livingAnts + 1;
              setLivingAnts(next);
              if (next >= 5) {
                onWin(3);
              }
            }}
            className="px-6 py-3 rounded-xl bg-[#14532D] hover:bg-[#166534] text-white text-sm font-semibold cursor-pointer"
          >
            გმირი ჭიანჭველის ჩადგომა ხიდში (+1)
          </button>
        </div>
      )}
    </div>
  );
}

/* =========================================================================
   GAME 5: სინათლისა და რწმენის გზა (ვაზის ჯვარი, მცხეთის გზა, თხოთის მზის სინათლე)
   ========================================================================= */
function Game5StNinoLight({ onWin }: { onWin: (stars: number) => void }) {
  const [stage, setStage] = useState<1 | 2 | 3>(1);
  const [boundNodes, setBoundNodes] = useState<number[]>([]);
  const [journeyPos, setJourneyPos] = useState(0); // 0..3
  const [prisms, setPrisms] = useState([90, 180, 270, 90]); // target all 0 deg

  const stations = ['კაბადოკია', 'იერუსალიმი', 'ჯავახეთი', 'მცხეთა'];

  const handleBindNode = (id: number) => {
    if (boundNodes.includes(id)) return;
    soundFX.playClick();
    const next = [...boundNodes, id];
    setBoundNodes(next);
    if (next.length === 4) {
      soundFX.playSuccess();
      setTimeout(() => setStage(2), 650);
    }
  };

  const rotatePrism = (idx: number) => {
    soundFX.playClick();
    const next = prisms.map((deg, i) => (i === idx ? (deg + 90) % 360 : deg));
    setPrisms(next);
    if (next.every((d) => d === 0)) {
      onWin(3);
    }
  };

  return (
    <div className="space-y-4">
      <div className="text-xs font-semibold text-[#B8860B]">
        ეტაპი {stage} / 3 ·{' '}
        {stage === 1
          ? 'შეკარი ვაზის ჯვრის 4 წერტილი'
          : stage === 2
          ? 'გაიარე გზა მცხეთამდე'
          : 'გაასწორე 4 სხივი თხოთის მთის დაბნელების გასაფანტად (ყველა ↑ მიმართულებით)'}
      </div>

      {stage === 1 && (
        <div className="p-6 rounded-xl bg-[#FAF6EE] border border-[#DDD2BE] text-center space-y-4">
          <div className="relative w-44 h-52 mx-auto flex items-center justify-center">
            <div className="absolute w-2 h-44 bg-[#78350F] rounded" />
            <div className="absolute w-32 h-2 bg-[#78350F] rounded -rotate-6" />
            {[
              { id: 1, top: '8%', left: '50%' },
              { id: 2, top: '86%', left: '50%' },
              { id: 3, top: '48%', left: '12%' },
              { id: 4, top: '44%', left: '88%' },
            ].map((node) => {
              const active = boundNodes.includes(node.id);
              return (
                <button
                  key={node.id}
                  onClick={() => handleBindNode(node.id)}
                  style={{ top: node.top, left: node.left }}
                  className={`absolute -translate-x-1/2 -translate-y-1/2 w-9 h-9 rounded-full border-2 font-bold text-xs cursor-pointer transition-all ${
                    active
                      ? 'bg-[#D4A017] border-[#7F1D1D] text-white scale-110'
                      : 'bg-white border-[#B8860B] text-[#231B15]'
                  }`}
                >
                  {node.id}
                </button>
              );
            })}
          </div>
          <p className="text-xs text-[#5C4E42]">დააჭირე ოთხივე წერტილს ვაზის ჯვრის შესაკრავად.</p>
        </div>
      )}

      {stage === 2 && (
        <div className="p-6 rounded-xl bg-[#EFE4CF] border border-[#CBB896] space-y-5">
          <div className="grid grid-cols-4 gap-2">
            {stations.map((st, idx) => (
              <div
                key={st}
                className={`p-3 rounded-xl border text-center text-xs font-semibold ${
                  idx <= journeyPos
                    ? 'bg-[#14532D] text-white border-[#14532D]'
                    : 'bg-[#FFFDF8] text-[#5C4E42] border-[#DDD2BE]'
                }`}
              >
                {st}
              </div>
            ))}
          </div>
          <div className="text-center">
            <button
              onClick={() => {
                soundFX.playClick();
                if (journeyPos < stations.length - 1) {
                  setJourneyPos((p) => p + 1);
                } else {
                  soundFX.playSuccess();
                  setStage(3);
                }
              }}
              className="px-6 py-3 rounded-xl bg-[#7F1D1D] text-white text-sm font-semibold cursor-pointer"
            >
              {journeyPos < stations.length - 1 ? 'გააგრძელე გზა →' : 'ჩადი მცხეთაში → ეტაპი 3'}
            </button>
          </div>
        </div>
      )}

      {stage === 3 && (
        <div className="p-6 rounded-xl bg-[#1C1917] text-[#FAF6EE] text-center space-y-5">
          <p className="text-xs text-[#FDE68A]">
            დაატრიალე თითოეული სხივი ისე, რომ ოთხივე ზემოთ (↑) ანათებდეს მზის დასაბრუნებლად!
          </p>
          <div className="flex justify-center gap-4">
            {prisms.map((deg, idx) => (
              <button
                key={idx}
                onClick={() => rotatePrism(idx)}
                className={`w-16 h-16 rounded-xl border-2 flex items-center justify-center text-2xl font-bold cursor-pointer transition-transform ${
                  deg === 0
                    ? 'bg-[#D4A017] text-[#1C1917] border-[#FDE68A]'
                    : 'bg-[#292524] text-[#FDE68A] border-[#57534E]'
                }`}
                style={{ transform: `rotate(${deg}deg)` }}
              >
                ↑
              </button>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
