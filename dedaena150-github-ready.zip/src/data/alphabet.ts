export interface GeorgianLetter {
  char: string;
  name: string;
  sampleWord: string;
  syllables: string[];
  hint: string;
  botanicalSymbol: string;
  color: string;
}

export const GEORGIAN_ALPHABET: GeorgianLetter[] = [
  { char: 'ა', name: 'ან', sampleWord: 'აი ია', syllables: ['ა-ი', 'ა-ნა'], hint: 'ხმოვანი, ანბანის პირველი ასო', botanicalSymbol: 'ალუბლის ყვავილი', color: '#7F1D1D' },
  { char: 'ბ', name: 'ბან', sampleWord: 'ბაღი', syllables: ['ბა-ღი', 'ბუ-დე'], hint: 'იწყებს სიტყვებს: ბაღი, ბებია', botanicalSymbol: 'ბროწეული', color: '#9A3412' },
  { char: 'გ', name: 'გან', sampleWord: 'გული', syllables: ['გუ-ლი', 'გო-გო'], hint: 'თბილი თანხმოვანი', botanicalSymbol: 'გვირილა', color: '#B45309' },
  { char: 'დ', name: 'დონ', sampleWord: 'დედა', syllables: ['დე-და', 'დი-ლა'], hint: '„დედაენის“ პირველი თანხმოვანი', botanicalSymbol: 'დაფნა', color: '#14532D' },
  { char: 'ე', name: 'ენ', sampleWord: 'ენა', syllables: ['ე-ნა', 'ე-ზო'], hint: 'ხმოვანი: ენა, ეზო', botanicalSymbol: 'ელენი', color: '#1E6B43' },
  { char: 'ვ', name: 'ვინ', sampleWord: 'ვაზი', syllables: ['ვა-ზი', 'ვაშ-ლი'], hint: 'ქართული ვაზის სიმბოლო', botanicalSymbol: 'ვაზი', color: '#166534' },
  { char: 'ზ', name: 'ზენ', sampleWord: 'ზარი', syllables: ['ზა-რი', 'ზღვა'], hint: 'სკოლის ზარი', botanicalSymbol: 'ზამბახი', color: '#0F766E' },
  { char: 'თ', name: 'თან', sampleWord: 'თოვლი', syllables: ['თოვ-ლი', 'თვა-ლი'], hint: 'იწყებს სიტყვას „თითი“', botanicalSymbol: 'თხილი', color: '#1D4ED8' },
  { char: 'ი', name: 'ინ', sampleWord: 'ია', syllables: ['ი-ა', 'ი-მე-დი'], hint: 'მეორე ასო სიტყვაში „ია“', botanicalSymbol: 'იის ყვავილი', color: '#5B21B6' },
  { char: 'კ', name: 'კან', sampleWord: 'კარი', syllables: ['კა-რი', 'კა-ლა-მი'], hint: '„ბუნების კარი“', botanicalSymbol: 'კაკალი', color: '#7C2D12' },
  { char: 'ლ', name: 'ლას', sampleWord: 'ლამაზი', syllables: ['ლა-მა-ზი', 'ლა-ლი'], hint: 'მჟღერი თანხმოვანი', botanicalSymbol: 'ლავანდა', color: '#6D28D9' },
  { char: 'მ', name: 'მან', sampleWord: 'მზე', syllables: ['მზე', 'მა-მა'], hint: 'იწყებს სიტყვებს: მამა, მთები', botanicalSymbol: 'მზესუმზირა', color: '#B8860B' },
  { char: 'ნ', name: 'ნარ', sampleWord: 'ნინო', syllables: ['ნი-ნო', 'ნა-მი'], hint: 'ნამი და ნერგი', botanicalSymbol: 'ნუში', color: '#9D174D' },
  { char: 'ო', name: 'ონ', sampleWord: 'ოქრო', syllables: ['ოქ-რო', 'ო-ჯა-ხი'], hint: 'ხმოვანი მრგვალი ფორმით', botanicalSymbol: 'ოლეანდრი', color: '#B45309' },
  { char: 'პ', name: 'პარ', sampleWord: 'პური', syllables: ['პუ-რი', 'პა-პა'], hint: 'ქართული სუფრის პური', botanicalSymbol: 'პიტნა', color: '#15803D' },
  { char: 'ჟ', name: 'ჟან', sampleWord: 'ჟამი', syllables: ['ჟა-მი', 'ჟი-რა-ფი'], hint: 'შრიალა თანხმოვანი', botanicalSymbol: 'ჟასმინი', color: '#0369A1' },
  { char: 'რ', name: 'რაე', sampleWord: 'რუკა', syllables: ['რუ-კა', 'რა-შა'], hint: 'მდინარისა და რუკის ასო', botanicalSymbol: 'რცხილა', color: '#166534' },
  { char: 'ს', name: 'სან', sampleWord: 'სახლი', syllables: ['სახ-ლი', 'სკო-ლა'], hint: 'სკოლა და სახლი', botanicalSymbol: 'სუმბული', color: '#4338CA' },
  { char: 'ტ', name: 'ტარ', sampleWord: 'ტყე', syllables: ['ტყე', 'ტო-ტი'], hint: 'ტყე და ტოტი', botanicalSymbol: 'ტულპანი', color: '#BE123C' },
  { char: 'უ', name: 'უნ', sampleWord: 'ურემი', syllables: ['უ-რე-მი', 'უ-ფა-ლი'], hint: 'ხმოვანი „უ“', botanicalSymbol: 'ურთხელი', color: '#14532D' },
  { char: 'ფ', name: 'ფარ', sampleWord: 'ფოთოლი', syllables: ['ფო-თო-ლი', 'ფან-ჯა-რა'], hint: 'ფურცელი და ფოთოლი', botanicalSymbol: 'ფურისულა', color: '#9333EA' },
  { char: 'ქ', name: 'ქან', sampleWord: 'ქოთანი', syllables: ['ქო-თა-ნი', 'ქა-რი'], hint: 'ქართლი და ქოთანი', botanicalSymbol: 'ქრიზანთემა', color: '#B45309' },
  { char: 'ღ', name: 'ღან', sampleWord: 'ღამე', syllables: ['ღა-მე', 'ღო-ბე'], hint: 'უნიკალური ქართული ბგერა', botanicalSymbol: 'ღიღილო', color: '#1D4ED8' },
  { char: 'ყ', name: 'ყარ', sampleWord: 'ყვავილი', syllables: ['ყვა-ვი-ლი', 'ყუ-რი'], hint: 'ყვავილი და ყანა', botanicalSymbol: 'ყაყაჩო', color: '#DC2626' },
  { char: 'შ', name: 'შინ', sampleWord: 'შუქი', syllables: ['შუ-ქი', 'ში-ნი'], hint: 'შინაური და შუქი', botanicalSymbol: 'შროშანი', color: '#0D9488' },
  { char: 'ჩ', name: 'ჩინ', sampleWord: 'ჩიტი', syllables: ['ჩი-ტი', 'ჩრდი-ლი'], hint: 'ჩანთა და ჩურჩხელა', botanicalSymbol: 'ჩაის ბუჩქი', color: '#15803D' },
  { char: 'ც', name: 'ცან', sampleWord: 'ცა', syllables: ['ცა', 'ცი-ცხვი'], hint: 'ცა და ციცხვი', botanicalSymbol: 'ცაცხვი', color: '#0284C7' },
  { char: 'ძ', name: 'ძილ', sampleWord: 'ძალა', syllables: ['ძა-ლა', 'ძმა'], hint: 'ძმობა და ძალა', botanicalSymbol: 'ძახველი', color: '#9A3412' },
  { char: 'წ', name: 'წილ', sampleWord: 'წიგნი', syllables: ['წიგ-ნი', 'წყა-რო'], hint: 'წიგნი და წყარო', botanicalSymbol: 'წიფელი', color: '#166534' },
  { char: 'ჭ', name: 'ჭარ', sampleWord: 'ჭიანჭველა', syllables: ['ჭი-ან-ჭვე-ლა', 'ჭა'], hint: 'შრომისმოყვარე ჭიანჭველა', botanicalSymbol: 'ჭადარი', color: '#3F6212' },
  { char: 'ხ', name: 'ხან', sampleWord: 'ხე', syllables: ['ხე', 'ხი-დი'], hint: 'ხე, ხიდი და ხილი', botanicalSymbol: 'ხეხილი', color: '#65A30D' },
  { char: 'ჯ', name: 'ჯან', sampleWord: 'ჯვარი', syllables: ['ჯვა-რი', 'ჯა-რი'], hint: 'ვაზის ჯვარი', botanicalSymbol: 'ჯონჯოლი', color: '#7F1D1D' },
  { char: 'ჰ', name: 'ჰაე', sampleWord: 'ჰაერი', syllables: ['ჰა-ე-რი', 'ჰამ-გი'], hint: 'ანბანის ოცდამეცამეტე ასო', botanicalSymbol: 'ჰორტენზია', color: '#4F46E5' },
];

export interface SyllableWord {
  word: string;
  syllables: string[];
  meaning: string;
  category: string;
}

export const SYLLABLE_WORDS: SyllableWord[] = [
  { word: 'აი ია', syllables: ['ა', 'ი', 'ი', 'ა'], meaning: 'ქართული ანბანის პირველი წინადადება', category: 'დედაენა' },
  { word: 'დედა', syllables: ['დე', 'და'], meaning: 'მშობელი, სითბოსა და ენის საწყისი', category: 'ოჯახი' },
  { word: 'ენა', syllables: ['ე', 'ნა'], meaning: 'მშობლიური სიტყვა და მეტყველება', category: 'დედაენა' },
  { word: 'წიგნი', syllables: ['წიგ', 'ნი'], meaning: 'ცოდნის წყარო', category: 'სკოლა' },
  { word: 'ქოთანი', syllables: ['ქო', 'თა', 'ნი'], meaning: 'თიხის ჭურჭელი', category: 'ხელობა' },
  { word: 'ვენახი', syllables: ['ვე', 'ნა', 'ხი'], meaning: 'ვაზის ბაღი საქართველოში', category: 'ბუნება' },
  { word: 'მეგობარი', syllables: ['მე', 'გო', 'ბა', 'რი'], meaning: 'ერთგული ამხანაგი', category: 'ღირებულება' },
  { word: 'ჭიანჭველა', syllables: ['ჭი', 'ან', 'ჭვე', 'ლა'], meaning: 'მუყაითი და გუნდური მწერი', category: 'ბუნება' },
];

export const WORD_PUZZLES = [
  { target: 'ია', hint: 'გაზაფხულის იისფერი ყვავილი „დედაენიდან“', scrambled: ['ი', 'ა'] },
  { target: 'დედა', hint: 'ყველაზე ძვირფასი ადამიანი', scrambled: ['დ', 'ა', 'ე', 'დ'] },
  { target: 'ვაზი', hint: 'ქართული მცენარე, რომლისგანაც წმინდა ნინოს ჯვარი შეიკრა', scrambled: ['ზ', 'ვ', 'ი', 'ა'] },
  { target: 'ხიდი', hint: 'ჭიანჭველებმა ეს ააშენეს ბაღში დასაბრუნებლად', scrambled: ['ი', 'ხ', 'დ', 'ი'] },
  { target: 'ქლიავი', hint: 'ხილი, რომელიც ინგილო გოგონამ ხიდან გადმოყარა', scrambled: ['ი', 'ქ', 'ა', 'ლ', 'ვ', 'ი'] },
  { target: 'სიმართლე', hint: 'ის, რასაც ციცხვმა შეახსენა მკვეხარა ქოთანს', scrambled: ['ს', 'მ', 'ი', 'ა', 'რ', 'თ', 'ლ', 'ე'] },
];

export const SENTENCE_BUILDERS = [
  {
    prompt: 'ააწყვე იაკობ გოგებაშვილის უკვდავი პირველი წინადადება:',
    words: ['აი', 'ია'],
    distractors: ['მზე', 'ხე'],
  },
  {
    prompt: 'ააწყვე წინადადება „მკვეხარა ქოთნიდან“:',
    words: ['მკვეხარა', 'ქოთანს', 'შერცხვა', 'და', 'ხმა', 'გაკმინდა'],
    distractors: ['გაფრინდა', 'გატყდა'],
  },
  {
    prompt: 'ააწყვე წინადადება „კეთილი ამხანაგებიდან“:',
    words: ['ამხანაგები', 'ალერსით', 'ანუგეშებდნენ', 'ნინოს'],
    distractors: ['დასცინოდნენ', 'გაიქცნენ'],
  },
  {
    prompt: 'ააწყვე წინადადება „ჭიანჭველებიდან“:',
    words: ['ერთობით', 'ჭიანჭველებმა', 'ხიდი', 'ააშენეს'],
    distractors: ['მარტო', 'დაიძინეს'],
  },
];
