import React, { useEffect, useRef, useState } from 'react';
import {
  Play,
  Pause,
  SkipBack,
  SkipForward,
  RotateCcw,
  Maximize2,
  Minimize2,
  BookOpen,
} from 'lucide-react';
import { CinemaScene, StoryId } from '../types';

interface StoryCinemaCanvasProps {
  storyId: StoryId;
  storyTitle: string;
  scenes: CinemaScene[];
  onCompleteCinema?: () => void;
}

// Helper drawing primitives for richly animated Georgian storybook scenes
function drawPot(
  ctx: CanvasRenderingContext2D,
  x: number,
  y: number,
  w: number,
  h: number,
  color: string,
  rimColor: string,
  blush = false,
  goldGlow = false,
  label = ''
) {
  ctx.save();
  ctx.translate(x, y);
  if (goldGlow) {
    ctx.shadowColor = 'rgba(212, 160, 23, 0.75)';
    ctx.shadowBlur = 18;
  }
  ctx.fillStyle = color;
  ctx.beginPath();
  ctx.ellipse(0, 0, w * 0.5, h * 0.48, 0, 0, Math.PI * 2);
  ctx.fill();

  // Neck & rim
  ctx.fillStyle = rimColor;
  ctx.beginPath();
  ctx.roundRect(-w * 0.34, -h * 0.56, w * 0.68, h * 0.16, 6);
  ctx.fill();

  // Highlight stripe
  ctx.strokeStyle = 'rgba(255,255,255,0.22)';
  ctx.lineWidth = 2;
  ctx.beginPath();
  ctx.arc(-w * 0.12, -h * 0.08, w * 0.24, Math.PI * 0.85, Math.PI * 1.45);
  ctx.stroke();

  if (blush) {
    ctx.fillStyle = 'rgba(220, 38, 38, 0.5)';
    ctx.beginPath();
    ctx.arc(-w * 0.18, -h * 0.04, 6, 0, Math.PI * 2);
    ctx.arc(w * 0.18, -h * 0.04, 6, 0, Math.PI * 2);
    ctx.fill();
  }

  // Expressive eyes (subtle storybook style)
  ctx.fillStyle = '#231B15';
  ctx.beginPath();
  ctx.arc(-w * 0.12, -h * 0.14, 2.6, 0, Math.PI * 2);
  ctx.arc(w * 0.12, -h * 0.14, 2.6, 0, Math.PI * 2);
  ctx.fill();

  if (label) {
    ctx.fillStyle = '#231B15';
    ctx.font = '600 12px "Noto Sans Georgian", sans-serif';
    ctx.textAlign = 'center';
    ctx.fillText(label, 0, h * 0.68);
  }
  ctx.restore();
}

function drawPerson(
  ctx: CanvasRenderingContext2D,
  x: number,
  y: number,
  scale: number,
  robeColor: string,
  hairColor: string,
  expression: 'neutral' | 'happy' | 'worried' | 'proud' | 'kind' = 'neutral',
  label = ''
) {
  ctx.save();
  ctx.translate(x, y);
  ctx.scale(scale, scale);

  // Body / Dress / Chokha
  ctx.fillStyle = robeColor;
  ctx.beginPath();
  ctx.moveTo(-16, 48);
  ctx.quadraticCurveTo(-18, 12, 0, 8);
  ctx.quadraticCurveTo(18, 12, 16, 48);
  ctx.closePath();
  ctx.fill();

  // Head
  ctx.fillStyle = '#F3D0B1';
  ctx.beginPath();
  ctx.arc(0, -6, 13, 0, Math.PI * 2);
  ctx.fill();

  // Hair
  ctx.fillStyle = hairColor;
  ctx.beginPath();
  ctx.arc(0, -10, 13.5, Math.PI, Math.PI * 2);
  ctx.fill();

  // Eyes
  ctx.fillStyle = '#231B15';
  ctx.beginPath();
  ctx.arc(-4.5, -6, 1.8, 0, Math.PI * 2);
  ctx.arc(4.5, -6, 1.8, 0, Math.PI * 2);
  ctx.fill();

  // Mouth
  ctx.strokeStyle = '#7F1D1D';
  ctx.lineWidth = 1.6;
  ctx.beginPath();
  if (expression === 'happy' || expression === 'kind') {
    ctx.arc(0, -2, 4, 0.15, Math.PI - 0.15);
  } else if (expression === 'worried') {
    ctx.arc(0, 2, 4, Math.PI + 0.2, Math.PI * 2 - 0.2);
  } else {
    ctx.moveTo(-3, -1);
    ctx.lineTo(3, -1);
  }
  ctx.stroke();

  if (label) {
    ctx.fillStyle = '#231B15';
    ctx.font = '600 11px "Noto Sans Georgian", sans-serif';
    ctx.textAlign = 'center';
    ctx.fillText(label, 0, 64);
  }
  ctx.restore();
}

function drawAnt(ctx: CanvasRenderingContext2D, x: number, y: number, angle = 0, scale = 1, color = '#291D16') {
  ctx.save();
  ctx.translate(x, y);
  ctx.rotate(angle);
  ctx.scale(scale, scale);
  ctx.fillStyle = color;
  // Abdomen, thorax, head
  ctx.beginPath();
  ctx.ellipse(-8, 0, 5.5, 4, 0, 0, Math.PI * 2);
  ctx.ellipse(0, 0, 3.5, 2.8, 0, 0, Math.PI * 2);
  ctx.ellipse(6.5, -0.5, 3.5, 3, 0, 0, Math.PI * 2);
  ctx.fill();
  // Legs
  ctx.strokeStyle = color;
  ctx.lineWidth = 1.2;
  for (let i = -1; i <= 1; i++) {
    ctx.beginPath();
    ctx.moveTo(i * 3, 0);
    ctx.lineTo(i * 4 - 2, 7);
    ctx.moveTo(i * 3, 0);
    ctx.lineTo(i * 4 - 2, -6);
    ctx.stroke();
  }
  ctx.restore();
}

function drawTree(ctx: CanvasRenderingContext2D, x: number, y: number, h: number, sway = 0, leafColor = '#2F6F3E') {
  ctx.save();
  ctx.translate(x, y);
  // Trunk
  ctx.fillStyle = '#5C3A21';
  ctx.beginPath();
  ctx.moveTo(-12, 0);
  ctx.lineTo(-7, -h * 0.65);
  ctx.lineTo(7, -h * 0.65);
  ctx.lineTo(12, 0);
  ctx.closePath();
  ctx.fill();

  // Canopy
  ctx.translate(sway, -h * 0.72);
  ctx.fillStyle = leafColor;
  ctx.beginPath();
  ctx.arc(0, 0, h * 0.32, 0, Math.PI * 2);
  ctx.arc(-h * 0.22, h * 0.08, h * 0.24, 0, Math.PI * 2);
  ctx.arc(h * 0.22, h * 0.08, h * 0.24, 0, Math.PI * 2);
  ctx.fill();
  ctx.restore();
}

function drawSpeechBubble(ctx: CanvasRenderingContext2D, x: number, y: number, text: string) {
  ctx.save();
  ctx.font = '600 13px "Noto Sans Georgian", sans-serif';
  const metrics = ctx.measureText(text);
  const w = Math.min(340, metrics.width + 28);
  const h = 34;
  ctx.fillStyle = 'rgba(255, 253, 248, 0.94)';
  ctx.strokeStyle = '#B8860B';
  ctx.lineWidth = 1.5;
  ctx.beginPath();
  ctx.roundRect(x - w / 2, y - h / 2, w, h, 10);
  ctx.fill();
  ctx.stroke();
  ctx.fillStyle = '#231B15';
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  ctx.fillText(text, x, y, w - 16);
  ctx.restore();
}

export function StoryCinemaCanvas({
  storyId,
  storyTitle,
  scenes,
  onCompleteCinema,
}: StoryCinemaCanvasProps) {
  const [sceneIdx, setSceneIdx] = useState(0);
  const [isPlaying, setIsPlaying] = useState(true);
  const [autoAdvance, setAutoAdvance] = useState(true);
  const [showParallelText, setShowParallelText] = useState(true);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [progress, setProgress] = useState(0);

  const containerRef = useRef<HTMLDivElement | null>(null);
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const timeRef = useRef(0);
  const lastTickRef = useRef<number | null>(null);

  const currentScene = scenes[sceneIdx] || scenes[0];

  // Reset scene timer when scene changes
  useEffect(() => {
    timeRef.current = 0;
    lastTickRef.current = null;
    setProgress(0);
  }, [sceneIdx, storyId]);

  // Reset to first scene if story changes
  useEffect(() => {
    setSceneIdx(0);
    setIsPlaying(true);
  }, [storyId]);

  // Animation & genuine pause-capable playback loop
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let rafId = 0;

    const renderFrame = (now: number) => {
      if (lastTickRef.current === null) {
        lastTickRef.current = now;
      }
      const dt = now - lastTickRef.current;
      lastTickRef.current = now;

      if (isPlaying) {
        timeRef.current += dt;
        const pct = Math.min(100, (timeRef.current / currentScene.durationMs) * 100);
        setProgress(pct);

        if (autoAdvance && timeRef.current >= currentScene.durationMs) {
          if (sceneIdx < scenes.length - 1) {
            setSceneIdx((prev) => prev + 1);
          } else {
            setIsPlaying(false);
            onCompleteCinema?.();
          }
        }
      }

      const w = (canvas.width = canvas.offsetWidth);
      const h = (canvas.height = canvas.offsetHeight);
      const t = timeRef.current / 1000;

      drawScene(ctx, w, h, t, storyId, currentScene);

      rafId = requestAnimationFrame(renderFrame);
    };

    rafId = requestAnimationFrame(renderFrame);
    return () => cancelAnimationFrame(rafId);
  }, [isPlaying, autoAdvance, sceneIdx, scenes.length, storyId, currentScene, onCompleteCinema]);

  const toggleFullscreen = async () => {
    if (!containerRef.current) return;
    try {
      if (!document.fullscreenElement) {
        await containerRef.current.requestFullscreen();
        setIsFullscreen(true);
      } else {
        await document.exitFullscreen();
        setIsFullscreen(false);
      }
    } catch {
      setIsFullscreen((prev) => !prev);
    }
  };

  useEffect(() => {
    const onFsChange = () => setIsFullscreen(Boolean(document.fullscreenElement));
    document.addEventListener('fullscreenchange', onFsChange);
    return () => document.removeEventListener('fullscreenchange', onFsChange);
  }, []);

  const handleRestart = () => {
    timeRef.current = 0;
    setProgress(0);
    setIsPlaying(true);
  };

  return (
    <div
      ref={containerRef}
      className={`vellum-card rounded-2xl overflow-hidden ${
        isFullscreen ? 'fixed inset-0 z-50 rounded-none bg-[#FAF6EE] flex flex-col justify-between p-4' : ''
      }`}
    >
      {/* Top Cinema Header */}
      <div className="flex flex-wrap items-center justify-between gap-3 px-5 py-3.5 border-b border-[#E2D6C1] bg-[#F5EFE2]">
        <div className="flex items-center gap-3">
          <span className="text-xs font-semibold text-[#7F1D1D] tabular-nums">
            სცენა {sceneIdx + 1} / {scenes.length}
          </span>
          <span className="text-[#CBB896]" aria-hidden="true">·</span>
          <h3 className="font-serif text-base sm:text-lg font-semibold text-[#231B15]">
            {currentScene.title}
          </h3>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => setShowParallelText((p) => !p)}
            className={`inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium rounded-lg border transition-colors cursor-pointer whitespace-nowrap ${
              showParallelText
                ? 'bg-[#7F1D1D] text-white border-[#7F1D1D]'
                : 'bg-white text-[#231B15] border-[#D8CBB3] hover:bg-[#FAF6EE]'
            }`}
          >
            <BookOpen className="w-3.5 h-3.5" />
            <span>პარალელური ტექსტი</span>
          </button>
          <button
            onClick={toggleFullscreen}
            aria-label="მთელ ეკრანზე ჩვენება"
            className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium rounded-lg border border-[#D8CBB3] bg-white hover:bg-[#FAF6EE] text-[#231B15] transition-colors cursor-pointer whitespace-nowrap"
          >
            {isFullscreen ? <Minimize2 className="w-3.5 h-3.5" /> : <Maximize2 className="w-3.5 h-3.5" />}
            <span className="hidden sm:inline">{isFullscreen ? 'დახურვა' : 'მთელი ეკრანი'}</span>
          </button>
        </div>
      </div>

      {/* Main Stage: Canvas + Optional Parallel Text */}
      <div className={`grid ${showParallelText ? 'lg:grid-cols-12' : 'grid-cols-1'} items-stretch`}>
        <div className={`${showParallelText ? 'lg:col-span-8' : 'col-span-1'} relative bg-[#F2E9D8]`}>
          <canvas
            ref={canvasRef}
            className={`w-full ${isFullscreen ? 'h-[62vh]' : 'h-[320px] sm:h-[390px]'} block`}
          />
          {/* Scene progress line */}
          <div className="absolute bottom-0 inset-x-0 h-1 bg-[#231B15]/10">
            <div
              className="h-full bg-[#B8860B] transition-all duration-100"
              style={{ width: `${progress}%` }}
            />
          </div>
          {!isPlaying && (
            <div className="absolute top-3 right-3 px-2.5 py-1 rounded bg-[#231B15]/75 text-[#FAF6EE] text-xs">
              დაპაუზებულია
            </div>
          )}
        </div>

        {showParallelText && (
          <div className="lg:col-span-4 p-5 sm:p-6 bg-[#FFFDF8] border-t lg:border-t-0 lg:border-l border-[#E2D6C1] flex flex-col justify-between">
            <div>
              <div className="text-xs font-medium text-[#6B5B4E] mb-2">
                {storyTitle} · ეპიზოდი {sceneIdx + 1}
              </div>
              <p className="font-serif text-base sm:text-lg leading-relaxed text-[#231B15]">
                „{currentScene.episodeText}“
              </p>
              <p className="mt-4 text-xs sm:text-sm text-[#5C4E42] leading-relaxed pt-4 border-t border-[#EAE1D0]">
                {currentScene.caption}
              </p>
            </div>

            <div className="mt-4 pt-3 border-t border-[#EAE1D0] flex items-center justify-between text-xs text-[#6B5B4E]">
              <span>ავტომატური გადართვა:</span>
              <button
                onClick={() => setAutoAdvance((a) => !a)}
                className={`px-2.5 py-1 rounded font-medium cursor-pointer transition-colors ${
                  autoAdvance
                    ? 'bg-[#14532D] text-white'
                    : 'bg-[#EDE3D2] text-[#231B15]'
                }`}
              >
                {autoAdvance ? 'ჩართულია' : 'გამორთულია'}
              </button>
            </div>
          </div>
        )}
      </div>

      {/* Controls Bar */}
      <div className="flex flex-wrap items-center justify-between gap-3 px-5 py-3 bg-[#FAF6EE] border-t border-[#E2D6C1]">
        <div className="flex items-center gap-2">
          <button
            onClick={() => setSceneIdx((i) => Math.max(0, i - 1))}
            disabled={sceneIdx === 0}
            className="inline-flex items-center gap-1 px-3 py-2 rounded-lg border border-[#D8CBB3] bg-white hover:bg-[#F5EFE2] disabled:opacity-40 text-xs font-medium text-[#231B15] cursor-pointer whitespace-nowrap"
          >
            <SkipBack className="w-4 h-4" />
            <span>წინა</span>
          </button>

          <button
            onClick={() => setIsPlaying((p) => !p)}
            className="inline-flex items-center gap-1.5 px-4 py-2 rounded-lg bg-[#7F1D1D] hover:bg-[#991B1B] text-white text-xs font-semibold cursor-pointer whitespace-nowrap"
          >
            {isPlaying ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4" />}
            <span>{isPlaying ? 'შეჩერება' : 'გაშვება'}</span>
          </button>

          <button
            onClick={() => setSceneIdx((i) => Math.min(scenes.length - 1, i + 1))}
            disabled={sceneIdx === scenes.length - 1}
            className="inline-flex items-center gap-1 px-3 py-2 rounded-lg border border-[#D8CBB3] bg-white hover:bg-[#F5EFE2] disabled:opacity-40 text-xs font-medium text-[#231B15] cursor-pointer whitespace-nowrap"
          >
            <span>შემდეგი</span>
            <SkipForward className="w-4 h-4" />
          </button>

          <button
            onClick={handleRestart}
            className="inline-flex items-center gap-1 px-3 py-2 rounded-lg border border-[#D8CBB3] bg-white hover:bg-[#F5EFE2] text-xs font-medium text-[#231B15] cursor-pointer whitespace-nowrap"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">თავიდან</span>
          </button>
        </div>

        <span className="text-xs text-[#6B5B4E]">
          აირჩიე სცენა ქრონოლოგიურ ზოლზე
        </span>
      </div>

      {/* Visual Filmstrip Bar */}
      <div className="px-5 py-3 bg-[#F2E9D8] border-t border-[#E2D6C1] overflow-x-auto">
        <div className="flex items-center gap-2 min-w-max">
          {scenes.map((scene, idx) => {
            const active = idx === sceneIdx;
            return (
              <button
                key={scene.id}
                onClick={() => {
                  setSceneIdx(idx);
                  setIsPlaying(true);
                }}
                className={`px-3 py-2 rounded-lg text-left transition-all cursor-pointer border min-w-[136px] max-w-[165px] ${
                  active
                    ? 'bg-[#FFFDF8] border-[#B8860B] shadow-sm text-[#231B15]'
                    : 'bg-[#FAF6EE]/70 border-[#DDD2BE] text-[#6B5B4E] hover:bg-[#FFFDF8]'
                }`}
              >
                <div className="text-[11px] font-semibold text-[#7F1D1D] tabular-nums">
                  {idx + 1}. სცენა
                </div>
                <div className="text-xs font-medium truncate mt-0.5">{scene.title}</div>
              </button>
            );
          })}
        </div>
      </div>
    </div>
  );
}

// Scene-by-scene procedural Canvas director faithfully depicting every episode
function drawScene(
  ctx: CanvasRenderingContext2D,
  w: number,
  h: number,
  t: number,
  storyId: StoryId,
  scene: CinemaScene
) {
  ctx.clearRect(0, 0, w, h);

  // Warm parchment storybook sky/backdrop
  const skyGrad = ctx.createLinearGradient(0, 0, 0, h);
  if (scene.visualType === 'nino_eclipse') {
    skyGrad.addColorStop(0, '#1C1917');
    skyGrad.addColorStop(1, '#3F342C');
  } else if (scene.visualType === 'erekle_krtsanisi' || scene.visualType === 'erekle_heroes') {
    skyGrad.addColorStop(0, '#F5E6D3');
    skyGrad.addColorStop(1, '#E2CBB2');
  } else {
    skyGrad.addColorStop(0, '#FBF6EA');
    skyGrad.addColorStop(1, '#EFE3CC');
  }
  ctx.fillStyle = skyGrad;
  ctx.fillRect(0, 0, w, h);

  // Subtle decorative parchment border frame
  ctx.strokeStyle = 'rgba(184, 134, 11, 0.28)';
  ctx.lineWidth = 2;
  ctx.strokeRect(10, 10, w - 20, h - 20);

  const groundY = h * 0.74;

  // STORY 1: POTTERY WORKSHOP (no birds, no breaking pots!)
  if (storyId === 'pot') {
    // Workshop wooden shelf & warm window light
    ctx.fillStyle = '#D8C3A5';
    ctx.fillRect(0, groundY, w, h - groundY);
    ctx.fillStyle = '#8B5A2B';
    ctx.fillRect(w * 0.12, groundY - 8, w * 0.76, 14);

    // Sunbeam
    ctx.fillStyle = 'rgba(253, 230, 138, 0.22)';
    ctx.beginPath();
    ctx.moveTo(w * 0.08, 0);
    ctx.lineTo(w * 0.35, 0);
    ctx.lineTo(w * 0.68, groundY);
    ctx.lineTo(w * 0.25, groundY);
    ctx.closePath();
    ctx.fill();

    const bounce = Math.sin(t * 3) * 3;
    const isBoasting = scene.visualType === 'pot_boast';
    const ladleHere =
      scene.visualType === 'pot_ladle_arrives' ||
      scene.visualType === 'pot_truth' ||
      scene.visualType === 'pot_silence';
    const isShamed = scene.visualType === 'pot_silence';

    // Surrounding modest clay pots
    drawPot(ctx, w * 0.26, groundY - 36, 54, 62, '#B45309', '#92400E');
    drawPot(ctx, w * 0.38, groundY - 32, 48, 54, '#C2410C', '#9A3412');
    drawPot(ctx, w * 0.67, groundY - 34, 52, 58, '#A16207', '#854D0E');

    // Tall boasting pot in the center
    const tallBob = isBoasting ? Math.abs(Math.sin(t * 4)) * -8 : 0;
    const tallShrink = isShamed ? 6 : 0;
    drawPot(
      ctx,
      w * 0.51,
      groundY - 52 + tallBob + tallShrink,
      64,
      96 - tallShrink,
      isShamed ? '#991B1B' : '#9A3412',
      '#7C2D12',
      isShamed,
      isBoasting,
      'მაღალი ქოთანი'
    );

    if (isBoasting) {
      drawSpeechBubble(ctx, w * 0.51, groundY - 135, '„მე ოქროს ძირი მაქვსო!“');
    }

    // Wooden ladle (ციცხვი)
    if (ladleHere) {
      const targetX = scene.visualType === 'pot_ladle_arrives'
        ? w * 0.85 - Math.min(1, t / 1.5) * (w * 0.22)
        : w * 0.62;
      ctx.save();
      ctx.translate(targetX, groundY - 68 + bounce);
      ctx.rotate(-0.35 + Math.sin(t * 2.5) * 0.06);
      ctx.fillStyle = '#78350F';
      ctx.beginPath();
      ctx.roundRect(-6, -42, 12, 84, 5);
      ctx.fill();
      ctx.fillStyle = '#B45309';
      ctx.beginPath();
      ctx.ellipse(0, 44, 18, 12, 0, 0, Math.PI * 2);
      ctx.fill();
      ctx.restore();

      if (scene.visualType === 'pot_truth') {
        drawSpeechBubble(ctx, w * 0.56, groundY - 142, '„მე მაინც ვიცი, რა ოქროს ძირიც გაქვსო!“');
      }
      if (isShamed) {
        drawSpeechBubble(ctx, w * 0.51, groundY - 128, 'ხმა გაკმინდა...');
      }
    }
    return;
  }

  // STORY 2: KIND FRIENDS
  if (storyId === 'friends') {
    const isSchoolyard =
      scene.visualType === 'friends_fear' ||
      scene.visualType === 'friends_unity';
    ctx.fillStyle = isSchoolyard ? '#D9E5C9' : '#E9DEC9';
    ctx.fillRect(0, groundY, w, h - groundY);

    if (!isSchoolyard) {
      // Classroom chalkboard & desks
      ctx.fillStyle = '#1E4631';
      ctx.strokeStyle = '#78350F';
      ctx.lineWidth = 6;
      ctx.fillRect(w * 0.22, h * 0.14, w * 0.56, h * 0.34);
      ctx.strokeRect(w * 0.22, h * 0.14, w * 0.56, h * 0.34);
      ctx.fillStyle = '#FAF6EE';
      ctx.font = '600 18px "Noto Serif Georgian", serif';
      ctx.textAlign = 'center';
      ctx.fillText('აი ია · დედაენა', w * 0.5, h * 0.31);
    } else {
      drawTree(ctx, w * 0.15, groundY, 130, Math.sin(t * 1.5) * 3, '#2D6A4F');
      // School facade
      ctx.fillStyle = '#FFFDF8';
      ctx.strokeStyle = '#CBB896';
      ctx.lineWidth = 2;
      ctx.fillRect(w * 0.58, groundY - 115, 160, 115);
      ctx.strokeRect(w * 0.58, groundY - 115, 160, 115);
      ctx.fillStyle = '#7F1D1D';
      ctx.beginPath();
      ctx.moveTo(w * 0.55, groundY - 115);
      ctx.lineTo(w * 0.69, groundY - 165);
      ctx.lineTo(w * 0.85, groundY - 115);
      ctx.closePath();
      ctx.fill();
    }

    const bob = Math.sin(t * 2.2) * 3;
    if (scene.visualType === 'friends_pride' || scene.visualType === 'friends_mock') {
      drawPerson(ctx, w * 0.42, groundY - 48 + bob, 1.05, '#9D174D', '#3B2314', 'proud', 'ნინო');
      drawPerson(ctx, w * 0.62, groundY - 46, 0.95, '#1E6B43', '#4A3728', 'worried', 'კატო');
      if (scene.visualType === 'friends_mock') {
        drawSpeechBubble(ctx, w * 0.5, h * 0.2, 'ამხანაგებს არ მოსწონდათ დაცინვა');
      }
    } else if (scene.visualType === 'friends_kato_sad') {
      drawPerson(ctx, w * 0.35, groundY - 46, 1, '#1E6B43', '#4A3728', 'worried', 'კატო');
      drawPerson(ctx, w * 0.55, groundY - 46, 1, '#B45309', '#231B15', 'neutral', 'ამხანაგები');
      drawPerson(ctx, w * 0.72, groundY - 46, 1, '#9D174D', '#3B2314', 'proud', 'ნინო');
    } else if (scene.visualType === 'friends_illness') {
      // Compassionate care room
      ctx.fillStyle = '#EFE3CE';
      ctx.fillRect(w * 0.32, groundY - 45, w * 0.36, 45);
      drawPerson(ctx, w * 0.5, groundY - 52, 1, '#9D174D', '#3B2314', 'worried', 'ნინო გამოჯანმრთელების გზაზე');
    } else if (scene.visualType === 'friends_fear') {
      const step = Math.min(1, t * 0.25);
      drawPerson(ctx, w * 0.25 + step * 70, groundY - 48 + bob, 1, '#9D174D', '#3B2314', 'worried', 'ნინო');
      drawSpeechBubble(ctx, w * 0.38, groundY - 125, '„მეშინია, მასხრად არ ამიგდონ...“');
    } else if (
      scene.visualType === 'friends_welcome' ||
      scene.visualType === 'friends_kato_kind' ||
      scene.visualType === 'friends_tears' ||
      scene.visualType === 'friends_unity'
    ) {
      // Warm golden light aura of kindness
      const aura = ctx.createRadialGradient(w * 0.5, groundY - 45, 10, w * 0.5, groundY - 45, 190);
      aura.addColorStop(0, 'rgba(251, 191, 36, 0.36)');
      aura.addColorStop(1, 'rgba(251, 191, 36, 0)');
      ctx.fillStyle = aura;
      ctx.fillRect(0, 0, w, h);

      const moveClose = Math.min(1, t * 0.6);
      drawPerson(ctx, w * 0.38 + moveClose * 24, groundY - 48 + bob, 1.02, '#9D174D', '#3B2314', 'happy', 'ნინო');
      drawPerson(ctx, w * 0.6 - moveClose * 26, groundY - 48 + bob, 1.02, '#1E6B43', '#4A3728', 'kind', 'კატო');
      drawPerson(ctx, w * 0.74, groundY - 46, 0.95, '#1D4ED8', '#231B15', 'kind', 'ამხანაგები');

      if (scene.visualType === 'friends_kato_kind') {
        drawSpeechBubble(ctx, w * 0.5, groundY - 128, 'კატო ალერსით ანუგეშებდა ნინოს');
      } else if (scene.visualType === 'friends_tears') {
        drawSpeechBubble(ctx, w * 0.5, groundY - 128, '„შვების ცრემლი წასკდა სიხარულისგან“');
      } else if (scene.visualType === 'friends_unity') {
        drawSpeechBubble(ctx, w * 0.5, groundY - 128, 'თანაგრძნობა და პატიება');
      }
    }
    return;
  }

  // STORY 3: KING EREKLE & INGILO GIRL
  if (storyId === 'erekle') {
    ctx.fillStyle = '#D7C89E';
    ctx.fillRect(0, groundY, w, h - groundY);

    // Distant Caucasus hills
    ctx.fillStyle = '#B8C4A4';
    ctx.beginPath();
    ctx.moveTo(0, groundY);
    ctx.quadraticCurveTo(w * 0.25, groundY - 110, w * 0.52, groundY - 40);
    ctx.quadraticCurveTo(w * 0.78, groundY - 130, w, groundY - 20);
    ctx.lineTo(w, groundY);
    ctx.closePath();
    ctx.fill();

    if (
      scene.visualType === 'erekle_wedding' ||
      scene.visualType === 'erekle_dowry'
    ) {
      // Georgian Darbazi wedding hall
      ctx.fillStyle = '#EDE0CC';
      ctx.fillRect(w * 0.14, h * 0.18, w * 0.72, groundY - h * 0.18);
      ctx.strokeStyle = '#7F1D1D';
      ctx.lineWidth = 3;
      ctx.strokeRect(w * 0.14, h * 0.18, w * 0.72, groundY - h * 0.18);

      drawPerson(ctx, w * 0.36, groundY - 48, 1.05, '#7F1D1D', '#231B15', 'happy', 'დედოფალი');
      drawPerson(ctx, w * 0.48, groundY - 48, 1.05, '#1E3A8A', '#231B15', 'happy', 'სიძე');

      if (scene.visualType === 'erekle_dowry') {
        drawPerson(ctx, w * 0.67 - Math.min(1, t * 0.5) * 20, groundY - 48, 1, '#B8860B', '#231B15', 'kind', 'მეფის დესპანი');
        // Golden pouch
        ctx.fillStyle = '#D4A017';
        ctx.beginPath();
        ctx.arc(w * 0.58, groundY - 24, 11, 0, Math.PI * 2);
        ctx.fill();
        drawSpeechBubble(ctx, w * 0.5, h * 0.26, '„მეფე ერეკლემ მზითევი გამოგზავნა!“');
      } else {
        drawSpeechBubble(ctx, w * 0.5, h * 0.26, '„ადღეგრძელოს ჩვენი გმირი მეფე ერეკლე!“');
      }
      return;
    }

    if (
      scene.visualType === 'erekle_krtsanisi' ||
      scene.visualType === 'erekle_heroes' ||
      scene.visualType === 'erekle_mother'
    ) {
      if (scene.visualType === 'erekle_mother') {
        drawPerson(ctx, w * 0.48, groundY - 52, 1.15, '#3F2E26', '#231B15', 'kind', 'სამაგალითო დედა');
        drawSpeechBubble(ctx, w * 0.5, groundY - 140, '„ჩვენს საქართველოს დააყენებენ ბედნიერს გზაზე“');
      } else {
        // Krtsanisi battle shield composition (respectful & heroic)
        drawPerson(ctx, w * 0.36, groundY - 50, 1.1, '#7F1D1D', '#D1D5DB', 'proud', 'მეფე ერეკლე (80 წ.)');
        drawPerson(ctx, w * 0.53, groundY - 48, 1.05, '#14532D', '#231B15', 'proud', 'გმირი ძმა I');
        drawPerson(ctx, w * 0.66, groundY - 48, 1.05, '#1E3A8A', '#231B15', 'proud', 'გმირი ძმა II');
        // Shields
        ctx.strokeStyle = '#B8860B';
        ctx.lineWidth = 4;
        ctx.beginPath();
        ctx.arc(w * 0.59, groundY - 45, 20, 0, Math.PI * 2);
        ctx.stroke();
        drawSpeechBubble(ctx, w * 0.5, h * 0.2, 'კრწანისის ველი · თავდადება სამშობლოსთვის');
      }
      return;
    }

    // Saingilo orchard & plum tree scenes
    drawTree(ctx, w * 0.72, groundY, 185, Math.sin(t * 1.4) * 2.5, '#1E6B43');

    // Girl on plum tree branch
    if (scene.visualType !== 'erekle_army' && scene.visualType !== 'erekle_orchard') {
      drawPerson(ctx, w * 0.72, groundY - 142, 0.78, '#7F1D1D', '#231B15', 'proud', 'ინგილო გოგონა');
    }

    // King Erekle on horse
    const riderX =
      scene.visualType === 'erekle_army' || scene.visualType === 'erekle_farewell'
        ? w * 0.2 + ((t * 36) % (w * 0.35))
        : w * 0.35;
    // Horse silhouette
    ctx.save();
    ctx.translate(riderX, groundY - 30);
    ctx.fillStyle = '#5C3A21';
    ctx.beginPath();
    ctx.ellipse(0, 0, 34, 17, 0, 0, Math.PI * 2);
    ctx.fill();
    ctx.fillRect(-26, 8, 7, 22);
    ctx.fillRect(18, 8, 7, 22);
    ctx.beginPath();
    ctx.moveTo(24, -8);
    ctx.lineTo(40, -26);
    ctx.lineTo(48, -16);
    ctx.lineTo(32, 4);
    ctx.fill();
    ctx.restore();

    drawPerson(ctx, riderX - 2, groundY - 72, 0.95, '#7F1D1D', '#4B5563', 'kind', 'მეფე ერეკლე');

    // Persian hat unless removed
    if (
      scene.visualType !== 'erekle_hat' &&
      scene.visualType !== 'erekle_gift' &&
      scene.visualType !== 'erekle_farewell'
    ) {
      ctx.fillStyle = '#1F2937';
      ctx.beginPath();
      ctx.roundRect(riderX - 11, groundY - 94, 18, 12, 3);
      ctx.fill();
    }

    // Falling plums animation
    if (scene.visualType === 'erekle_plums') {
      for (let i = 0; i < 6; i++) {
        const py = groundY - 135 + ((t * 95 + i * 25) % 80);
        const px = w * 0.68 - ((t * 110 + i * 20) % (w * 0.32));
        ctx.fillStyle = '#5B21B6';
        ctx.beginPath();
        ctx.arc(px, py, 5, 0, Math.PI * 2);
        ctx.fill();
      }
      drawSpeechBubble(ctx, w * 0.5, h * 0.2, 'ქლიავების სეტყვა ორღობეში!');
    } else if (scene.visualType === 'erekle_answer') {
      drawSpeechBubble(ctx, w * 0.62, h * 0.2, '„განა მეფე ერეკლე სპარსულ ქუდს დაიხურავდა?“');
    } else if (scene.visualType === 'erekle_hat') {
      drawSpeechBubble(ctx, w * 0.45, h * 0.2, '„ყოჩაღ, ქალო! ჩინებული დარიგება მომეცი!“');
    } else if (scene.visualType === 'erekle_gift') {
      drawSpeechBubble(ctx, w * 0.5, h * 0.2, 'მეფური საჩუქარი სამაგალითო გოგონას');
    } else if (scene.visualType === 'erekle_farewell') {
      drawSpeechBubble(ctx, w * 0.65, h * 0.2, '„მეფე ერეკლეს გაუმარჯოს!“');
    }
    return;
  }

  // STORY 4: THE ANTS
  if (storyId === 'ants') {
    ctx.fillStyle = '#D2E2B8';
    ctx.fillRect(0, groundY, w, h - groundY);

    if (scene.visualType === 'ant_nest') {
      // Anthill mound
      ctx.fillStyle = '#8B6F47';
      ctx.beginPath();
      ctx.moveTo(w * 0.26, groundY);
      ctx.quadraticCurveTo(w * 0.5, groundY - 125, w * 0.74, groundY);
      ctx.closePath();
      ctx.fill();
      for (let i = 0; i < 12; i++) {
        const ax = w * 0.34 + ((i * 37 + t * 40) % (w * 0.32));
        const ay = groundY - 20 - Math.sin(i + t * 2) * 28;
        drawAnt(ctx, ax, ay, Math.sin(t + i) * 0.4, 0.9);
      }
      drawSpeechBubble(ctx, w * 0.5, h * 0.2, 'ათასობით მუყაითი მშენებლის ბუდე');
      return;
    }

    // Orchard tree
    drawTree(ctx, w * 0.42, groundY, 210, Math.sin(t * 1.2) * 2, '#2D6A4F');

    // Tobacco ring on trunk
    if (
      scene.visualType === 'ant_ring' ||
      scene.visualType === 'ant_council' ||
      scene.visualType === 'ant_leaves' ||
      scene.visualType === 'ant_mud_bridge'
    ) {
      ctx.fillStyle = '#4D3B1B';
      ctx.fillRect(w * 0.42 - 11, groundY - 76, 22, 16);
    }

    // Mud bridge over tobacco ring
    if (scene.visualType === 'ant_mud_bridge' || scene.visualType === 'ant_cross1') {
      ctx.fillStyle = '#6B4F35';
      ctx.beginPath();
      ctx.roundRect(w * 0.42 - 13, groundY - 78, 26, 20, 6);
      ctx.fill();
    }

    // Falling yellow leaves with ants
    if (scene.visualType === 'ant_leaves') {
      for (let i = 0; i < 4; i++) {
        const ly = groundY - 150 + ((t * 45 + i * 35) % 130);
        const lx = w * 0.3 + i * 55 + Math.sin(t * 3 + i) * 14;
        ctx.fillStyle = '#EAB308';
        ctx.beginPath();
        ctx.ellipse(lx, ly, 14, 7, Math.sin(t + i) * 0.4, 0, Math.PI * 2);
        ctx.fill();
        drawAnt(ctx, lx, ly - 4, 0, 0.85);
      }
      drawSpeechBubble(ctx, w * 0.65, h * 0.2, 'გულადი ჭიანჭველები ფოთლებით ეშვებიან!');
    }

    // Water moat & Living Bridge
    if (
      scene.visualType === 'ant_moat' ||
      scene.visualType === 'ant_living_bridge' ||
      scene.visualType === 'ant_peace'
    ) {
      ctx.fillStyle = '#0EA5E9';
      ctx.beginPath();
      ctx.ellipse(w * 0.42, groundY + 12, 130, 18, 0, 0, Math.PI * 2);
      ctx.fill();

      if (scene.visualType === 'ant_living_bridge' || scene.visualType === 'ant_peace') {
        // Living bridge of ants across the moat!
        for (let i = 0; i < 9; i++) {
          drawAnt(ctx, w * 0.45 + i * 16, groundY + 6, 0, 0.95, '#1F1610');
        }
        // Marching ants crossing on top
        for (let i = 0; i < 5; i++) {
          const cx = w * 0.44 + ((t * 48 + i * 28) % 145);
          drawAnt(ctx, cx, groundY - 2, 0, 0.85, '#7F1D1D');
        }
        drawSpeechBubble(ctx, w * 0.62, h * 0.22, 'ერთობითა და თავდადებით აგებული ხიდი!');
      } else {
        drawSpeechBubble(ctx, w * 0.62, h * 0.22, 'ხის გარშემო წყლის თხრილია!');
      }
    }

    // Gardener on right
    if (
      scene.visualType === 'ant_gardener' ||
      scene.visualType === 'ant_peace' ||
      scene.visualType === 'ant_garden'
    ) {
      drawPerson(
        ctx,
        w * 0.78,
        groundY - 50,
        1.05,
        '#3F6212',
        '#4B5563',
        scene.visualType === 'ant_peace' ? 'kind' : 'worried',
        'მებაღე'
      );
      if (scene.visualType === 'ant_peace') {
        drawSpeechBubble(ctx, w * 0.55, h * 0.22, 'მებაღე აღტაცებულია ჭიანჭველების სიყვარულით');
      }
    }

    if (scene.visualType === 'ant_march' || scene.visualType === 'ant_council') {
      for (let i = 0; i < 10; i++) {
        const mx = w * 0.12 + ((t * 45 + i * 24) % (w * 0.3));
        drawAnt(ctx, mx, groundY - 4, 0, 0.9);
      }
      if (scene.visualType === 'ant_council') {
        drawSpeechBubble(ctx, w * 0.55, h * 0.2, 'სჯა-ბაასი ხის კენწეროზე');
      }
    }
    return;
  }

  // STORY 5: SAINT NINO & CONVERSION OF KARTLI (dignified, luminous historical art)
  if (storyId === 'nino') {
    const isEclipse = scene.visualType === 'nino_eclipse';
    const isLightReturn = scene.visualType === 'nino_light';

    // Mountains & rivers backdrop
    ctx.fillStyle = isEclipse ? '#292524' : '#C6D4B8';
    ctx.beginPath();
    ctx.moveTo(0, groundY);
    ctx.lineTo(w * 0.22, groundY - 95);
    ctx.lineTo(w * 0.48, groundY - 35);
    ctx.lineTo(w * 0.75, groundY - 110);
    ctx.lineTo(w, groundY - 30);
    ctx.lineTo(w, groundY);
    ctx.closePath();
    ctx.fill();

    ctx.fillStyle = isEclipse ? '#1C1917' : '#DFD5BE';
    ctx.fillRect(0, groundY, w, h - groundY);

    // Sun or Eclipse
    if (isEclipse) {
      ctx.fillStyle = '#0A0A0A';
      ctx.beginPath();
      ctx.arc(w * 0.5, h * 0.24, 34, 0, Math.PI * 2);
      ctx.fill();
      ctx.strokeStyle = '#D97706';
      ctx.lineWidth = 2;
      ctx.stroke();
    } else if (isLightReturn || scene.visualType === 'nino_pentecost' || scene.visualType === 'nino_vision') {
      const sunGlow = ctx.createRadialGradient(w * 0.5, h * 0.25, 8, w * 0.5, h * 0.25, 160);
      sunGlow.addColorStop(0, 'rgba(253, 224, 71, 0.85)');
      sunGlow.addColorStop(0.5, 'rgba(212, 160, 23, 0.25)');
      sunGlow.addColorStop(1, 'rgba(212, 160, 23, 0)');
      ctx.fillStyle = sunGlow;
      ctx.fillRect(0, 0, w, h);
    }

    // Rivers Mtkvari & Aragvi
    if (scene.visualType === 'nino_baptism' || scene.visualType === 'nino_mtskheta') {
      ctx.fillStyle = '#0284C7';
      ctx.beginPath();
      ctx.moveTo(0, groundY + 12);
      ctx.quadraticCurveTo(w * 0.5, groundY - 4 + Math.sin(t * 2) * 3, w, groundY + 26);
      ctx.lineTo(w, h);
      ctx.lineTo(0, h);
      ctx.closePath();
      ctx.fill();
    }

    // Grapevine Cross motif (central dignified emblem)
    if (
      scene.visualType === 'nino_vine_cross' ||
      scene.visualType === 'nino_heritage' ||
      scene.visualType === 'nino_iberia'
    ) {
      ctx.save();
      ctx.translate(w * 0.5, groundY - 82);
      ctx.strokeStyle = '#B8860B';
      ctx.lineWidth = 5;
      ctx.lineCap = 'round';
      ctx.beginPath();
      ctx.moveTo(0, -56);
      ctx.lineTo(0, 56);
      ctx.moveTo(-36, -12);
      ctx.lineTo(36, 4);
      ctx.stroke();
      ctx.restore();
    }

    // Key dignified characters
    if (scene.visualType === 'nino_hunt' || isEclipse || scene.visualType === 'nino_prayer' || isLightReturn) {
      drawPerson(ctx, w * 0.48, groundY - 48, 1.08, '#7F1D1D', '#231B15', isEclipse ? 'worried' : 'kind', 'მეფე მირიანი');
    } else if (scene.visualType === 'nino_nana') {
      drawPerson(ctx, w * 0.4, groundY - 48, 1, '#312E81', '#231B15', 'kind', 'წმინდა ნინო');
      drawPerson(ctx, w * 0.6, groundY - 48, 1, '#7F1D1D', '#231B15', 'happy', 'დედოფალი ნანა');
    } else if (
      scene.visualType !== 'nino_vine_cross' &&
      scene.visualType !== 'nino_heritage' &&
      scene.visualType !== 'nino_pentecost'
    ) {
      const walkX = scene.visualType === 'nino_journey' ? w * 0.25 + ((t * 26) % (w * 0.45)) : w * 0.36;
      drawPerson(ctx, walkX, groundY - 48, 1, '#312E81', '#231B15', 'kind', 'წმინდა ნინო');
    }

    drawSpeechBubble(ctx, w * 0.5, h * 0.14, scene.title);
  }
}
