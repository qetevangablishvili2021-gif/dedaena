// Synthesized Web Audio feedback for games and alphabet interactions (no external files required)
class SoundEngine {
  private ctx: AudioContext | null = null;
  public muted = false;

  private getContext(): AudioContext | null {
    if (this.muted || typeof window === 'undefined') return null;
    if (!this.ctx) {
      const AudioCtx =
        window.AudioContext ||
        (window as unknown as { webkitAudioContext?: typeof AudioContext }).webkitAudioContext;
      if (AudioCtx) {
        this.ctx = new AudioCtx();
      }
    }
    if (this.ctx && this.ctx.state === 'suspended') {
      this.ctx.resume().catch(() => {});
    }
    return this.ctx;
  }

  public playTone(freq: number, duration = 0.14, type: OscillatorType = 'sine', volume = 0.08) {
    const ctx = this.getContext();
    if (!ctx) return;
    try {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = type;
      osc.frequency.setValueAtTime(freq, ctx.currentTime);
      gain.gain.setValueAtTime(volume, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + duration);
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start();
      osc.stop(ctx.currentTime + duration);
    } catch {
      // Ignore audio autoplay blocks
    }
  }

  public playSuccess() {
    this.playTone(523.25, 0.12, 'triangle', 0.09);
    setTimeout(() => this.playTone(659.25, 0.14, 'triangle', 0.09), 80);
    setTimeout(() => this.playTone(783.99, 0.24, 'triangle', 0.09), 170);
  }

  public playError() {
    this.playTone(220, 0.16, 'sawtooth', 0.05);
    setTimeout(() => this.playTone(185, 0.2, 'sawtooth', 0.04), 90);
  }

  public playClick() {
    this.playTone(440, 0.06, 'sine', 0.05);
  }

  public playBloom() {
    const notes = [392, 493.88, 587.33, 783.99, 987.77];
    notes.forEach((n, idx) => {
      setTimeout(() => this.playTone(n, 0.28, 'sine', 0.07), idx * 90);
    });
  }
}

export const soundFX = new SoundEngine();
