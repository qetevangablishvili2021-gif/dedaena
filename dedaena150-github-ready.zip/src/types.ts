export type PortalView =
  | 'home'
  | 'map'
  | 'alphabet'
  | 'story'
  | 'values'
  | 'teacher';

export type StoryId =
  | 'pot'
  | 'friends'
  | 'erekle'
  | 'ants'
  | 'nino';

export type StoryTab =
  | 'read'
  | 'cinema'
  | 'discover'
  | 'game'
  | 'reflect'
  | 'create';

export type GradeLevel = 'I' | 'II' | 'III' | 'IV' | 'V' | 'VI';

export interface GlossaryEntry {
  word: string;
  meaning: string;
  context: string;
}

export interface CinemaScene {
  id: string;
  order: number;
  title: string;
  episodeText: string;
  visualType: string;
  caption: string;
  durationMs: number;
}

export interface DiscoveryFact {
  title: string;
  category: 'ლიტერატურული' | 'ისტორიული წყარო' | 'გადმოცემა და ფაქტი' | 'პერსონაჟი';
  body: string;
}

export interface ReflectionScenario {
  id: string;
  situation: string;
  question: string;
  choices: {
    text: string;
    isWise: boolean;
    feedback: string;
  }[];
}

export interface TeacherPlan {
  objectives: string[];
  outcomes: string[];
  comprehensionQuestions: {
    level: 'გახსენება' | 'ანალიზი' | 'ღირებულებითი მსჯელობა';
    question: string;
  }[];
  discussionPrompts: string[];
  groupActivity: string;
  individualTask: string;
  worksheetTasks: string[];
  rubric: {
    criterion: string;
    emerging: string;
    developing: string;
    exemplary: string;
  }[];
  selfAssessmentStatements: string[];
}

export interface StoryData {
  id: StoryId;
  missionNumber: number;
  title: string;
  subtitle: string;
  recommendedGrade: string;
  gradeTag: GradeLevel;
  locationName: string;
  valueTitle: string;
  valueSymbolName: string;
  accentColor: string;
  shortDescription: string;
  paragraphs: string[];
  glossary: GlossaryEntry[];
  scenes: CinemaScene[];
  discoveries: DiscoveryFact[];
  reflection: {
    coreMessage: string;
    modernBridge: string;
    scenarios: ReflectionScenario[];
    journalPrompt: string;
  };
  gameTitle: string;
  gameDescription: string;
  teacher: TeacherPlan;
}

export interface StudentProgress {
  studentName: string;
  selectedGrade: GradeLevel;
  completedStories: StoryId[];
  storyBookmarks: Record<StoryId, number>;
  completedGames: Record<StoryId, number>; // stars 1-3
  discoveredLetters: string[];
  tracedLetters: string[];
  aiIaCompleted: boolean;
  reflections: Record<string, string>;
  createdArtworks: Record<string, string>;
}
