import React, { useState } from 'react';
import {
  ClipboardList,
  Presentation,
  FileText,
  CheckSquare,
  Printer,
  ChevronLeft,
  ChevronRight,
  X,
  MessageSquare,
} from 'lucide-react';
import { STORIES } from '../data/stories';
import { StoryId } from '../types';
import { OrnamentalDivider } from './OrnamentalDivider';

type TeacherTab = 'plan' | 'questions' | 'projector' | 'worksheet' | 'rubric';

export function TeacherWorkshop() {
  const [selectedStoryId, setSelectedStoryId] = useState<StoryId>('pot');
  const [tab, setTab] = useState<TeacherTab>('plan');
  const [projectorFullscreen, setProjectorFullscreen] = useState(false);
  const [slideIdx, setSlideIdx] = useState(0);

  const story = STORIES.find((s) => s.id === selectedStoryId) || STORIES[0];

  const slides = [
    {
      kicker: `${story.recommendedGrade} · დედაენა 150 (1876–2026)`,
      title: story.title,
      body: story.shortDescription,
      note: `ძირითადი ღირებულება: ${story.valueTitle}`,
    },
    {
      kicker: 'საკვანძო ლექსიკა',
      title: 'ძველი ქართული სიტყვების გაგება',
      body: story.glossary.map((g) => `${g.word} — ${g.meaning}`).join('\n'),
      note: 'გაარჩიეთ მოსწავლეებთან ტექსტის წაკითხვამდე ან კითხვის პროცესში.',
    },
    {
      kicker: 'ნაწარმოების სრული ტექსტი (ფრაგმენტი)',
      title: 'წაკითხვა და ანალიზი',
      body: story.paragraphs[0],
      note: `სრული ტექსტი მოიცავს ${story.paragraphs.length} აბზაცს.`,
    },
    {
      kicker: 'საკლასო დისკუსია',
      title: 'გააზრების კითხვები',
      body: story.teacher.comprehensionQuestions
        .map((q, i) => `${i + 1}. [${q.level}] ${q.question}`)
        .join('\n'),
      note: story.reflection.coreMessage,
    },
    {
      kicker: 'საკლასო აქტივობა',
      title: 'ჯგუფური და ინდივიდუალური მუშაობა',
      body: `ჯგუფური: ${story.teacher.groupActivity}\n\nინდივიდუალური: ${story.teacher.individualTask}`,
      note: story.reflection.modernBridge,
    },
  ];

  return (
    <section className="max-w-7xl mx-auto px-4 sm:px-6 py-8 space-y-6">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-4 no-print">
        <div>
          <div className="text-xs font-medium text-[#14532D]">
            V. მასწავლებლის რეჟიმი · პედაგოგიური სახელოსნო
          </div>
          <h1 className="font-serif text-2xl sm:text-4xl font-bold text-[#231B15] mt-1">
            მასწავლებლის მეთოდური სახელოსნო
          </h1>
          <p className="text-sm text-[#5C4E42] mt-1.5 max-w-2xl">
            მზა გაკვეთილის გეგმები, სხვადასხვა სირთულის კითხვები, პროექტორზე საჩვენებელი პრეზენტაციები, საბეჭდი სამუშაო ფურცლები და შეფასების რუბრიკები.
          </p>
        </div>

        <button
          onClick={() => {
            setSlideIdx(0);
            setProjectorFullscreen(true);
          }}
          className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl bg-[#231B15] hover:bg-[#3A2D23] text-[#FDE68A] text-xs font-semibold cursor-pointer whitespace-nowrap"
        >
          <Presentation className="w-4 h-4" />
          <span>პროექტორზე გაშვება</span>
        </button>
      </div>

      {/* Story Selector */}
      <div className="flex flex-wrap gap-1.5 no-print">
        {STORIES.map((s) => (
          <button
            key={s.id}
            onClick={() => {
              setSelectedStoryId(s.id);
              setSlideIdx(0);
            }}
            className={`px-3.5 py-2 rounded-xl text-xs font-semibold border transition-colors cursor-pointer whitespace-nowrap ${
              s.id === selectedStoryId
                ? 'bg-[#14532D] text-white border-[#14532D]'
                : 'bg-[#FFFDF8] text-[#231B15] border-[#DDD2BE] hover:border-[#B8860B]'
            }`}
          >
            {s.gradeTag} კლასი · {s.title}
          </button>
        ))}
      </div>

      {/* Teacher Mode Sub-Navigation */}
      <div className="flex flex-wrap gap-1.5 p-1.5 bg-[#EFE6D5] rounded-xl border border-[#DDD2BE] no-print">
        {[
          { id: 'plan', label: 'გაკვეთილის გეგმა', icon: ClipboardList },
          { id: 'questions', label: 'კითხვები და დისკუსია', icon: MessageSquare },
          { id: 'projector', label: 'საკლასო პრეზენტაცია', icon: Presentation },
          { id: 'worksheet', label: 'საბეჭდი სამუშაო ფურცელი', icon: FileText },
          { id: 'rubric', label: 'რუბრიკა და თვითშეფასება', icon: CheckSquare },
        ].map((item) => {
          const Icon = item.icon;
          return (
            <button
              key={item.id}
              onClick={() => setTab(item.id as TeacherTab)}
              className={`inline-flex items-center gap-1.5 px-3.5 py-2 rounded-lg text-xs font-semibold cursor-pointer transition-colors whitespace-nowrap ${
                tab === item.id
                  ? 'bg-[#FFFDF8] text-[#231B15] shadow-sm'
                  : 'text-[#5C4E42] hover:text-[#231B15]'
              }`}
            >
              <Icon className="w-3.5 h-3.5" />
              <span>{item.label}</span>
            </button>
          );
        })}
      </div>

      {/* 1. LESSON PLAN */}
      {tab === 'plan' && (
        <div className="grid lg:grid-cols-12 gap-6">
          <div className="lg:col-span-7 vellum-card rounded-2xl p-6 space-y-5">
            <div>
              <div className="text-xs font-semibold text-[#7F1D1D]">{story.recommendedGrade}</div>
              <h2 className="font-serif text-2xl font-bold text-[#231B15] mt-1">
                გაკვეთილის გეგმა: „{story.title}“
              </h2>
              <p className="text-xs text-[#5C4E42] mt-1">
                პორტალის საგანმანათლებლო ორგანიზების რეკომენდაცია · ძირითადი ღირებულება: {story.valueTitle}
              </p>
            </div>

            <OrnamentalDivider />

            <div>
              <h3 className="font-serif text-base font-bold text-[#14532D]">გაკვეთილის მიზნები</h3>
              <ul className="mt-2 space-y-2 text-sm text-[#231B15]">
                {story.teacher.objectives.map((obj, i) => (
                  <li key={i} className="flex gap-2">
                    <span className="text-[#7F1D1D] font-bold">{i + 1}.</span>
                    <span>{obj}</span>
                  </li>
                ))}
              </ul>
            </div>

            <div>
              <h3 className="font-serif text-base font-bold text-[#14532D]">მოსალოდნელი შედეგები</h3>
              <ul className="mt-2 space-y-2 text-sm text-[#231B15]">
                {story.teacher.outcomes.map((out, i) => (
                  <li key={i} className="flex gap-2">
                    <span className="text-[#14532D] font-bold">✓</span>
                    <span>{out}</span>
                  </li>
                ))}
              </ul>
            </div>
          </div>

          <div className="lg:col-span-5 space-y-5">
            <div className="vellum-card rounded-2xl p-6 space-y-3">
              <h3 className="font-serif text-lg font-bold text-[#7F1D1D]">ჯგუფური აქტივობა</h3>
              <p className="text-sm text-[#4A3B31] leading-relaxed">{story.teacher.groupActivity}</p>
            </div>
            <div className="vellum-card rounded-2xl p-6 space-y-3">
              <h3 className="font-serif text-lg font-bold text-[#231B15]">ინდივიდუალური დავალება</h3>
              <p className="text-sm text-[#4A3B31] leading-relaxed">{story.teacher.individualTask}</p>
            </div>
          </div>
        </div>
      )}

      {/* 2. QUESTIONS & DISCUSSION */}
      {tab === 'questions' && (
        <div className="grid lg:grid-cols-12 gap-6">
          <div className="lg:col-span-7 vellum-card rounded-2xl p-6 space-y-4">
            <h2 className="font-serif text-xl font-bold text-[#231B15]">
              ნაწარმოების გააზრების დონეობრივი კითხვები
            </h2>
            <div className="space-y-3">
              {story.teacher.comprehensionQuestions.map((q, idx) => (
                <div key={idx} className="p-4 rounded-xl bg-[#FAF6EE] border border-[#E2D6C1]">
                  <div className="text-xs font-semibold text-[#7F1D1D]">{q.level}</div>
                  <div className="text-sm font-medium text-[#231B15] mt-1">{q.question}</div>
                </div>
              ))}
            </div>
          </div>

          <div className="lg:col-span-5 vellum-card rounded-2xl p-6 space-y-4">
            <h2 className="font-serif text-xl font-bold text-[#14532D]">
              საკლასო დისკუსიის თემები
            </h2>
            <div className="space-y-3">
              {story.teacher.discussionPrompts.map((p, idx) => (
                <div key={idx} className="p-4 rounded-xl bg-[#F0F7EE] border border-[#C6E2C6] text-sm text-[#231B15]">
                  {p}
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* 3. PROJECTOR PRESENTATION PREVIEW */}
      {tab === 'projector' && (
        <div className="vellum-card rounded-2xl p-6 space-y-5">
          <div className="flex flex-wrap items-center justify-between gap-3">
            <div className="text-xs font-semibold text-[#6B5B4E] tabular-nums">
              სლაიდი {slideIdx + 1} / {slides.length}
            </div>
            <button
              onClick={() => setProjectorFullscreen(true)}
              className="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl bg-[#7F1D1D] text-white text-xs font-semibold cursor-pointer"
            >
              <Presentation className="w-4 h-4" />
              სრულეკრანიანი პროექტორის რეჟიმი
            </button>
          </div>

          <div className="rounded-2xl bg-[#1D140E] text-[#FAF6EE] p-8 sm:p-12 min-h-[320px] flex flex-col justify-between border border-[#B8860B]/40">
            <div>
              <div className="text-xs text-[#FDE68A] font-medium">{slides[slideIdx].kicker}</div>
              <h3 className="font-serif text-2xl sm:text-3xl font-bold text-white mt-2">
                {slides[slideIdx].title}
              </h3>
              <p className="mt-5 text-base sm:text-lg text-[#EFE3C8] whitespace-pre-line leading-relaxed">
                {slides[slideIdx].body}
              </p>
            </div>
            <div className="pt-4 mt-6 border-t border-white/15 text-xs text-[#FDE68A]/80">
              {slides[slideIdx].note}
            </div>
          </div>

          <div className="flex items-center justify-between">
            <button
              onClick={() => setSlideIdx((i) => Math.max(0, i - 1))}
              disabled={slideIdx === 0}
              className="inline-flex items-center gap-1 px-4 py-2 rounded-xl border border-[#D8CBB3] disabled:opacity-40 text-xs font-semibold cursor-pointer"
            >
              <ChevronLeft className="w-4 h-4" /> წინა სლაიდი
            </button>
            <button
              onClick={() => setSlideIdx((i) => Math.min(slides.length - 1, i + 1))}
              disabled={slideIdx === slides.length - 1}
              className="inline-flex items-center gap-1 px-4 py-2 rounded-xl bg-[#231B15] text-white disabled:opacity-40 text-xs font-semibold cursor-pointer"
            >
              შემდეგი სლაიდი <ChevronRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      )}

      {/* 4. PRINTABLE WORKSHEET */}
      {tab === 'worksheet' && (
        <div className="space-y-4">
          <div className="flex justify-end no-print">
            <button
              onClick={() => window.print()}
              className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl bg-[#7F1D1D] text-white text-xs font-semibold cursor-pointer"
            >
              <Printer className="w-4 h-4" />
              სამუშაო ფურცლის ამობეჭდვა
            </button>
          </div>

          <div className="print-sheet vellum-card rounded-2xl p-8 sm:p-12 bg-white space-y-6">
            <div className="flex flex-wrap items-center justify-between border-b border-[#D8CBB3] pb-4 gap-3">
              <div>
                <div className="text-xs text-[#6B5B4E]">დედაენა 150 · საბეჭდი სამუშაო ფურცელი</div>
                <h2 className="font-serif text-2xl font-bold text-[#231B15] mt-1">
                  {story.title} ({story.recommendedGrade})
                </h2>
              </div>
              <div className="text-xs text-[#5C4E42]">
                მოსწავლის სახელი: ________________________
              </div>
            </div>

            <div className="space-y-5">
              {story.teacher.worksheetTasks.map((task, idx) => (
                <div key={idx} className="space-y-2">
                  <div className="text-sm font-semibold text-[#231B15]">{task}</div>
                  <div className="h-14 border-b border-dashed border-[#94A3B8]" />
                </div>
              ))}
            </div>

            <div className="pt-4 border-t border-[#EAE1D0] text-xs text-[#5C4E42]">
              ძირითადი ღირებულება: <strong>{story.valueTitle}</strong>
            </div>
          </div>
        </div>
      )}

      {/* 5. RUBRIC & SELF-ASSESSMENT */}
      {tab === 'rubric' && (
        <div className="space-y-6">
          <div className="flex justify-end no-print">
            <button
              onClick={() => window.print()}
              className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl bg-[#231B15] text-white text-xs font-semibold cursor-pointer"
            >
              <Printer className="w-4 h-4" />
              ბეჭდვა
            </button>
          </div>

          <div className="vellum-card rounded-2xl p-6 overflow-x-auto">
            <h2 className="font-serif text-xl font-bold text-[#231B15] mb-4">
              შეფასების რუბრიკა — „{story.title}“
            </h2>
            <table className="w-full text-left border-collapse text-xs sm:text-sm">
              <thead>
                <tr className="border-b-2 border-[#CBB896] text-[#7F1D1D]">
                  <th className="py-3 pr-4">კრიტერიუმი</th>
                  <th className="py-3 px-4">დამწყები დონე</th>
                  <th className="py-3 px-4">საშუალო დონე</th>
                  <th className="py-3 pl-4">მაღალი დონე</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#EAE1D0]">
                {story.teacher.rubric.map((row) => (
                  <tr key={row.criterion}>
                    <td className="py-3.5 pr-4 font-semibold text-[#231B15]">{row.criterion}</td>
                    <td className="py-3.5 px-4 text-[#5C4E42]">{row.emerging}</td>
                    <td className="py-3.5 px-4 text-[#4A3B31]">{row.developing}</td>
                    <td className="py-3.5 pl-4 text-[#14532D] font-medium">{row.exemplary}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          <div className="vellum-card rounded-2xl p-6 space-y-4">
            <h3 className="font-serif text-lg font-bold text-[#14532D]">
              მოსწავლის თვითშეფასების ბარათი
            </h3>
            <div className="grid sm:grid-cols-3 gap-3">
              {story.teacher.selfAssessmentStatements.map((st, idx) => (
                <div key={idx} className="p-4 rounded-xl bg-[#FAF6EE] border border-[#DDD2BE] text-xs sm:text-sm text-[#231B15] flex items-start gap-2.5">
                  <span className="w-5 h-5 rounded border border-[#7F1D1D] shrink-0 mt-0.5" />
                  <span>{st}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* Fullscreen Classroom Projector Overlay */}
      {projectorFullscreen && (
        <div className="fixed inset-0 z-50 bg-[#140E0A] text-[#FAF6EE] flex flex-col justify-between p-6 sm:p-12">
          <div className="flex items-center justify-between">
            <span className="text-sm text-[#FDE68A] font-serif">
              პროექტორის რეჟიმი · {story.title} ({slideIdx + 1}/{slides.length})
            </span>
            <button
              onClick={() => setProjectorFullscreen(false)}
              className="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl bg-white/10 hover:bg-white/20 text-sm cursor-pointer"
            >
              <X className="w-4 h-4" /> დახურვა
            </button>
          </div>

          <div className="max-w-4xl mx-auto w-full space-y-6">
            <div className="text-sm text-[#FDE68A]">{slides[slideIdx].kicker}</div>
            <h2 className="font-serif text-4xl sm:text-5xl font-bold text-white">
              {slides[slideIdx].title}
            </h2>
            <p className="text-xl sm:text-2xl text-[#EFE3C8] whitespace-pre-line leading-relaxed">
              {slides[slideIdx].body}
            </p>
            <div className="pt-6 border-t border-white/15 text-base text-[#FDE68A]/80">
              {slides[slideIdx].note}
            </div>
          </div>

          <div className="flex items-center justify-between max-w-4xl mx-auto w-full">
            <button
              onClick={() => setSlideIdx((i) => Math.max(0, i - 1))}
              disabled={slideIdx === 0}
              className="px-6 py-3 rounded-xl bg-white/10 hover:bg-white/20 disabled:opacity-30 text-sm font-semibold cursor-pointer"
            >
              ← წინა
            </button>
            <button
              onClick={() => setSlideIdx((i) => Math.min(slides.length - 1, i + 1))}
              disabled={slideIdx === slides.length - 1}
              className="px-6 py-3 rounded-xl bg-[#B8860B] text-[#140E0A] disabled:opacity-30 text-sm font-bold cursor-pointer"
            >
              შემდეგი →
            </button>
          </div>
        </div>
      )}
    </section>
  );
}
