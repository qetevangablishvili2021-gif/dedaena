import React, { useState } from 'react';
import { motion } from 'motion/react';
import { Compass, Star, CheckCircle2, ArrowRight } from 'lucide-react';
import { STORIES } from '../data/stories';
import { StoryId, StudentProgress } from '../types';
import { OrnamentalDivider } from './OrnamentalDivider';

interface AdventureMapProps {
  progress: StudentProgress;
  onStartMission: (storyId: StoryId) => void;
}

const NODE_COORDS: Record<StoryId, { x: number; y: number }> = {
  pot: { x: 155, y: 390 },
  friends: { x: 345, y: 265 },
  erekle: { x: 545, y: 375 },
  ants: { x: 745, y: 245 },
  nino: { x: 945, y: 155 },
};

export function AdventureMap({ progress, onStartMission }: AdventureMapProps) {
  const [activeId, setActiveId] = useState<StoryId>('pot');
  const activeStory = STORIES.find((s) => s.id === activeId) || STORIES[0];
  const isCompleted = progress.completedStories.includes(activeStory.id);
  const gameStars = progress.completedGames[activeStory.id] || 0;

  return (
    <section className="max-w-7xl mx-auto px-4 sm:px-6 py-8">
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-4 mb-6">
        <div>
          <div className="text-xs font-medium text-[#7F1D1D] flex items-center gap-1.5">
            <Compass className="w-4 h-4" />
            <span>მოგზაურობის ინტერაქტიული რუკა · ხუთი თავისუფალი მისია</span>
          </div>
          <h1 className="font-serif text-2xl sm:text-4xl font-bold text-[#231B15] mt-1">
            სათავგადასავლო გზა „დედაენის“ სამყაროში
          </h1>
          <p className="text-sm text-[#5C4E42] mt-1.5 max-w-2xl">
            აირჩიე სასურველი ლოკაცია ნებისმიერი თანმიმდევრობით — დააკვირდი გაცოცხლებულ პერსონაჟებს, წაიკითხე, ითამაშე და მოიპოვე ღირებულების სიმბოლო.
          </p>
        </div>

        <div className="text-xs text-[#5C4E42] tabular-nums">
          დასრულებული მისიები: <strong className="text-[#231B15]">{progress.completedStories.length} / 5</strong>
        </div>
      </div>

      {/* Main Illustrated Map Stage */}
      <div className="grid lg:grid-cols-12 gap-6 items-stretch">
        <div className="lg:col-span-8 vellum-card rounded-2xl overflow-hidden relative bg-[#F3E9D4]">
          <svg
            viewBox="0 0 1100 540"
            className="w-full h-auto block select-none"
            role="img"
            aria-label="სათავგადასავლო რუკა ხუთი საგანმანათლებლო ლოკაციით"
          >
            <defs>
              <linearGradient id="mapSky" x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stopColor="#FBF6EA" />
                <stop offset="100%" stopColor="#EFE3C8" />
              </linearGradient>
              <linearGradient id="riverGrad" x1="0" y1="0" x2="1" y2="0">
                <stop offset="0%" stopColor="#38BDF8" stopOpacity="0.7" />
                <stop offset="50%" stopColor="#0284C7" stopOpacity="0.85" />
                <stop offset="100%" stopColor="#0369A1" stopOpacity="0.8" />
              </linearGradient>
              <filter id="goldGlow" x="-40%" y="-40%" width="180%" height="180%">
                <feGaussianBlur stdDeviation="5" result="blur" />
                <feComposite in="SourceGraphic" in2="blur" operator="over" />
              </filter>
            </defs>

            {/* Parchment Base */}
            <rect width="1100" height="540" fill="url(#mapSky)" />
            <rect x="14" y="14" width="1072" height="512" rx="14" fill="none" stroke="#CBB896" strokeWidth="2" />

            {/* Caucasus Mountains */}
            <g fill="#D5C8B0" opacity="0.85">
              <path d="M40 175 L150 65 L255 175 Z" />
              <path d="M180 175 L310 45 L445 175 Z" fill="#C9B99D" />
              <path d="M520 155 L660 40 L800 155 Z" />
              <path d="M740 165 L915 35 L1065 165 Z" fill="#C9B99D" />
            </g>
            {/* Snow caps */}
            <g fill="#FFFDF8" opacity="0.9">
              <path d="M280 74 L310 45 L340 74 L322 68 L310 78 L298 68 Z" />
              <path d="M882 67 L915 35 L948 67 L930 61 L915 72 L900 61 Z" />
            </g>

            {/* Animated Drifting Clouds */}
            <motion.g
              animate={{ x: [0, 35, 0] }}
              transition={{ duration: 14, repeat: Infinity, ease: 'easeInOut' }}
              fill="#FFFDF8"
              opacity="0.75"
            >
              <ellipse cx="140" cy="68" rx="38" ry="13" />
              <ellipse cx="165" cy="62" rx="26" ry="11" />
              <ellipse cx="520" cy="56" rx="44" ry="14" />
              <ellipse cx="550" cy="50" rx="28" ry="12" />
            </motion.g>

            {/* Animated Flying Birds */}
            <motion.g
              animate={{ x: [0, 28, 0], y: [0, -8, 0] }}
              transition={{ duration: 7, repeat: Infinity, ease: 'easeInOut' }}
              stroke="#5C4E42"
              strokeWidth="1.6"
              fill="none"
            >
              <path d="M410 92 Q417 85 424 92 Q431 85 438 92" />
              <path d="M446 105 Q451 100 456 105 Q461 100 466 105" />
            </motion.g>

            {/* Rolling Hills & Vineyards */}
            <path d="M0 320 Q280 260 560 325 T1100 295 L1100 540 L0 540 Z" fill="#DFD8B8" opacity="0.75" />
            <path d="M0 410 Q320 355 680 415 T1100 390 L1100 540 L0 540 Z" fill="#CFE0B4" opacity="0.65" />

            {/* Flowing River & Stone Bridge */}
            <path
              d="M120 540 C260 470, 380 455, 510 475 C640 495, 760 430, 865 365 C945 315, 1020 315, 1100 330"
              fill="none"
              stroke="url(#riverGrad)"
              strokeWidth="26"
              strokeLinecap="round"
            />
            <motion.path
              d="M140 530 C270 465, 390 455, 510 475 C635 495, 755 430, 865 365"
              fill="none"
              stroke="#E0F2FE"
              strokeWidth="2.5"
              strokeDasharray="12 18"
              animate={{ strokeDashoffset: [0, -60] }}
              transition={{ duration: 3, repeat: Infinity, ease: 'linear' }}
            />

            {/* Stone Bridge over river */}
            <g transform="translate(475, 446)">
              <path d="M0 24 Q34 -4 68 24" fill="#9A8873" stroke="#5C4E42" strokeWidth="2" />
              <rect x="6" y="18" width="56" height="8" rx="3" fill="#B6A58F" />
            </g>

            {/* Swaying Forests & Vineyards */}
            {[
              { x: 92, y: 315 },
              { x: 245, y: 215 },
              { x: 455, y: 205 },
              { x: 640, y: 300 },
              { x: 840, y: 195 },
            ].map((tree, idx) => (
              <motion.g
                key={idx}
                transform={`translate(${tree.x}, ${tree.y})`}
                animate={{ rotate: [-1.5, 1.5, -1.5] }}
                transition={{ duration: 4 + idx * 0.5, repeat: Infinity, ease: 'easeInOut' }}
              >
                <rect x="-3" y="0" width="6" height="22" fill="#6B4F35" />
                <circle cx="0" cy="-6" r="16" fill="#2D6A4F" />
                <circle cx="-10" cy="2" r="11" fill="#40916C" />
                <circle cx="10" cy="2" r="11" fill="#1B4332" />
              </motion.g>
            ))}

            {/* Winding Adventure Trail */}
            <path
              d="M155 390 C235 350, 260 285, 345 265 C430 245, 465 360, 545 375 C635 390, 660 275, 745 245 C835 215, 865 180, 945 155"
              fill="none"
              stroke="#B8860B"
              strokeWidth="4.5"
              strokeDasharray="10 8"
              opacity="0.7"
            />

            {/* Value Symbols along completed segments */}
            {STORIES.map((story) => {
              const coord = NODE_COORDS[story.id];
              const done = progress.completedStories.includes(story.id);
              const isSelected = activeId === story.id;
              return (
                <g
                  key={story.id}
                  transform={`translate(${coord.x}, ${coord.y})`}
                  onClick={() => setActiveId(story.id)}
                  onMouseEnter={() => setActiveId(story.id)}
                  className="cursor-pointer"
                  role="button"
                  tabIndex={0}
                  aria-label={`მისია ${story.missionNumber}: ${story.locationName}`}
                  onKeyDown={(e) => {
                    if (e.key === 'Enter' || e.key === ' ') {
                      e.preventDefault();
                      setActiveId(story.id);
                    }
                  }}
                >
                  {/* Golden illumination ring for active or completed */}
                  {(isSelected || done) && (
                    <motion.circle
                      r={isSelected ? 38 : 33}
                      fill={done ? 'rgba(212, 160, 23, 0.25)' : 'rgba(127, 29, 29, 0.16)'}
                      stroke={done ? '#D4A017' : '#7F1D1D'}
                      strokeWidth="2"
                      animate={{ scale: [1, 1.07, 1] }}
                      transition={{ duration: 2.2, repeat: Infinity }}
                    />
                  )}

                  {/* Location emblem medallion */}
                  <circle
                    r="26"
                    fill={done ? '#FFF9E6' : '#FFFDF8'}
                    stroke={done ? '#B8860B' : isSelected ? '#7F1D1D' : '#8C7A65'}
                    strokeWidth="2.8"
                    filter={done ? 'url(#goldGlow)' : undefined}
                  />

                  {/* Custom mini-icon per location */}
                  {story.id === 'pot' && (
                    <g transform="translate(-8,-9)">
                      <ellipse cx="8" cy="11" rx="7" ry="8" fill="#9A3412" />
                      <rect x="4" y="1" width="8" height="3" rx="1" fill="#7C2D12" />
                    </g>
                  )}
                  {story.id === 'friends' && (
                    <g transform="translate(-10,-9)">
                      <rect x="1" y="5" width="18" height="12" rx="1" fill="#1E6B43" />
                      <polygon points="0,6 10,0 20,6" fill="#7F1D1D" />
                    </g>
                  )}
                  {story.id === 'erekle' && (
                    <g transform="translate(-9,-9)">
                      <circle cx="9" cy="10" r="8" fill="#5B21B6" />
                      <path d="M9 2 Q13 -2 15 2" stroke="#14532D" strokeWidth="2" fill="none" />
                    </g>
                  )}
                  {story.id === 'ants' && (
                    <g transform="translate(-9,-4)">
                      <circle cx="3" cy="4" r="3" fill="#231B15" />
                      <circle cx="9" cy="4" r="2.5" fill="#231B15" />
                      <circle cx="15" cy="4" r="3" fill="#231B15" />
                    </g>
                  )}
                  {story.id === 'nino' && (
                    <g transform="translate(-8,-11)">
                      <path d="M8 1 V20 M2 8 L14 10" stroke="#B8860B" strokeWidth="2.8" strokeLinecap="round" />
                    </g>
                  )}

                  {/* Mission number badge */}
                  <circle cx="19" cy="-19" r="10" fill={done ? '#14532D' : '#7F1D1D'} />
                  <text
                    x="19"
                    y="-15"
                    textAnchor="middle"
                    fill="#FFFFFF"
                    fontSize="11"
                    fontWeight="700"
                  >
                    {done ? '✓' : story.missionNumber}
                  </text>

                  {/* Location Label */}
                  <rect x="-78" y="32" width="156" height="24" rx="6" fill="rgba(255, 253, 248, 0.92)" stroke="#DDD2BE" />
                  <text
                    x="0"
                    y="48"
                    textAnchor="middle"
                    fill="#231B15"
                    fontSize="11.5"
                    fontWeight="600"
                    fontFamily="Noto Sans Georgian, sans-serif"
                  >
                    {story.locationName}
                  </text>
                </g>
              );
            })}

            {/* Animated Traveler Emblem near selected node */}
            <motion.g
              animate={{
                x: NODE_COORDS[activeId].x - 38,
                y: NODE_COORDS[activeId].y - 26,
              }}
              transition={{ type: 'spring', stiffness: 120, damping: 18 }}
            >
              <circle r="8" fill="#7F1D1D" stroke="#FFFDF8" strokeWidth="2" />
              <circle cx="0" cy="-11" r="4.5" fill="#F3D0B1" stroke="#231B15" strokeWidth="1" />
            </motion.g>

            {/* Compass Rose in bottom-right */}
            <g transform="translate(1025, 470)" opacity="0.75">
              <circle r="28" fill="#FFFDF8" stroke="#B8860B" strokeWidth="1.5" />
              <path d="M0 -22 L5 -5 L22 0 L5 5 L0 22 L-5 5 L-22 0 L-5 -5 Z" fill="#B8860B" />
              <circle r="4" fill="#7F1D1D" />
            </g>
          </svg>
        </div>

        {/* Right Interactive Mission Card */}
        <div className="lg:col-span-4 vellum-card rounded-2xl p-6 flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between text-xs text-[#6B5B4E]">
              <span>მისია {activeStory.missionNumber} · {activeStory.recommendedGrade}</span>
              {isCompleted && (
                <span className="inline-flex items-center gap-1 text-[#14532D] font-semibold">
                  <CheckCircle2 className="w-3.5 h-3.5" />
                  შესრულებულია
                </span>
              )}
            </div>

            <h2 className="font-serif text-2xl font-bold text-[#231B15] mt-2">
              {activeStory.title}
            </h2>
            <p className="text-xs font-medium text-[#7F1D1D] mt-1">
              ლოკაცია: {activeStory.locationName}
            </p>

            <OrnamentalDivider className="my-2" />

            <p className="text-sm text-[#4A3B31] leading-relaxed">
              {activeStory.shortDescription}
            </p>

            <div className="mt-5 space-y-2.5 text-xs border-t border-[#EAE1D0] pt-4">
              <div className="flex items-center justify-between">
                <span className="text-[#6B5B4E]">მთავარი ღირებულება:</span>
                <span className="font-semibold text-[#14532D]">{activeStory.valueTitle}</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-[#6B5B4E]">მოპოვებული სიმბოლო:</span>
                <span className="font-medium text-[#231B15]">{activeStory.valueSymbolName}</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-[#6B5B4E]">თამაშის ვარსკვლავები:</span>
                <span className="inline-flex items-center gap-0.5 text-[#B8860B] tabular-nums">
                  {[1, 2, 3].map((s) => (
                    <Star
                      key={s}
                      className={`w-4 h-4 ${s <= gameStars ? 'fill-[#D4A017] text-[#B8860B]' : 'text-[#D6CEBE]'}`}
                    />
                  ))}
                </span>
              </div>
            </div>
          </div>

          <div className="mt-6 space-y-3">
            <button
              onClick={() => onStartMission(activeStory.id)}
              className="w-full inline-flex items-center justify-center gap-2 px-5 py-3 rounded-xl bg-[#7F1D1D] hover:bg-[#991B1B] text-white font-semibold text-sm transition-colors cursor-pointer"
            >
              <span>მისიის დაწყება</span>
              <ArrowRight className="w-4 h-4" />
            </button>

            <div className="grid grid-cols-5 gap-1.5 pt-2">
              {STORIES.map((s) => (
                <button
                  key={s.id}
                  onClick={() => setActiveId(s.id)}
                  className={`py-2 rounded-lg text-xs font-semibold border transition-colors cursor-pointer ${
                    s.id === activeId
                      ? 'bg-[#231B15] text-white border-[#231B15]'
                      : 'bg-[#FAF6EE] text-[#4A3B31] border-[#DDD2BE] hover:bg-[#F2E9D8]'
                  }`}
                >
                  {s.missionNumber}
                </button>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
