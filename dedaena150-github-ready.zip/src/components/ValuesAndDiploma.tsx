import React from 'react';
import { Award, Star, Printer, CheckCircle2, ArrowRight } from 'lucide-react';
import { STORIES } from '../data/stories';
import { HISTORICAL_ASSETS } from '../data/biography';
import { StoryId, StudentProgress } from '../types';
import { JubileeSeal, OrnamentalDivider } from './OrnamentalDivider';

interface ValuesAndDiplomaProps {
  progress: StudentProgress;
  onUpdateStudentName: (name: string) => void;
  onOpenStory: (id: StoryId) => void;
}

export function ValuesAndDiploma({
  progress,
  onUpdateStudentName,
  onOpenStory,
}: ValuesAndDiplomaProps) {
  const totalStars = Object.values(progress.completedGames).reduce((a, b) => a + b, 0);

  return (
    <section className="max-w-7xl mx-auto px-4 sm:px-6 py-8 space-y-10">
      <div className="no-print">
        <div className="text-xs font-medium text-[#B8860B]">
          IV. საგანმანათლებლო სამყარო · ზნეობრივი მემკვიდრეობა
        </div>
        <h1 className="font-serif text-2xl sm:text-4xl font-bold text-[#231B15] mt-1">
          ღირებულებების სამყარო, საგანძური და პერსონალური დიპლომი
        </h1>
        <p className="text-sm text-[#5C4E42] mt-1.5 max-w-2xl">
          იაკობ გოგებაშვილის ნაწარმოებებიდან მიღებული მთავარი სათქმელი დღევანდელ ცხოვრებაში, შენი მოპოვებული მედლები და საიუბილეო დიპლომი.
        </p>
      </div>

      {/* Five Core Values Connecting 1876 to 2026 */}
      <div className="grid md:grid-cols-5 gap-4 no-print">
        {STORIES.map((story) => {
          const done = progress.completedStories.includes(story.id);
          const stars = progress.completedGames[story.id] || 0;
          return (
            <div
              key={story.id}
              className={`vellum-card rounded-2xl p-5 flex flex-col justify-between ${
                done ? 'border-[#B8860B] bg-[#FFFDF4]' : ''
              }`}
            >
              <div>
                <div className="flex items-center justify-between text-xs">
                  <span className="font-semibold text-[#7F1D1D]">მისია {story.missionNumber}</span>
                  {done && <CheckCircle2 className="w-4 h-4 text-[#14532D]" />}
                </div>
                <h2 className="font-serif text-base font-bold text-[#231B15] mt-2">
                  {story.valueTitle}
                </h2>
                <p className="text-xs text-[#5C4E42] mt-1.5 leading-relaxed">
                  {story.reflection.coreMessage}
                </p>
              </div>

              <div className="mt-4 pt-3 border-t border-[#EAE1D0] space-y-2.5">
                <div className="flex items-center justify-between text-xs">
                  <span className="text-[#6B5B4E]">სიმბოლო:</span>
                  <span className="font-semibold text-[#14532D]">{story.valueSymbolName}</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="inline-flex gap-0.5">
                    {[1, 2, 3].map((s) => (
                      <Star
                        key={s}
                        className={`w-3.5 h-3.5 ${
                          s <= stars ? 'fill-[#D4A017] text-[#B8860B]' : 'text-[#D6CEBE]'
                        }`}
                      />
                    ))}
                  </span>
                  <button
                    onClick={() => onOpenStory(story.id)}
                    className="text-xs font-semibold text-[#7F1D1D] inline-flex items-center gap-1 cursor-pointer hover:underline"
                  >
                    გახსნა <ArrowRight className="w-3 h-3" />
                  </button>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Student Achievement Treasury */}
      <div className="vellum-card rounded-2xl p-6 grid sm:grid-cols-4 gap-4 text-center no-print">
        <div className="p-4 rounded-xl bg-[#FAF6EE]">
          <div className="text-2xl font-bold text-[#7F1D1D] tabular-nums">
            {progress.completedStories.length} / 5
          </div>
          <div className="text-xs text-[#5C4E42] mt-1">შესრულებული ნაწარმოები</div>
        </div>
        <div className="p-4 rounded-xl bg-[#FAF6EE]">
          <div className="text-2xl font-bold text-[#B8860B] tabular-nums">{totalStars} / 15</div>
          <div className="text-xs text-[#5C4E42] mt-1">თამაშების ვარსკვლავი</div>
        </div>
        <div className="p-4 rounded-xl bg-[#FAF6EE]">
          <div className="text-2xl font-bold text-[#14532D] tabular-nums">
            {progress.discoveredLetters.length} / 33
          </div>
          <div className="text-xs text-[#5C4E42] mt-1">ანბანის ბაღის ასო</div>
        </div>
        <div className="p-4 rounded-xl bg-[#FAF6EE]">
          <div className="text-2xl font-bold text-[#5B21B6] tabular-nums">
            {progress.aiIaCompleted ? 'გაშლილია' : 'მოლოდინში'}
          </div>
          <div className="text-xs text-[#5C4E42] mt-1">„აი ია“ ყვავილი</div>
        </div>
      </div>

      {/* Personal Jubilee Diploma */}
      <div className="space-y-4">
        <div className="flex flex-wrap items-center justify-between gap-3 no-print">
          <div className="flex items-center gap-3">
            <label htmlFor="student-name-input" className="text-xs font-semibold text-[#231B15]">
              მოსწავლის სახელი და გვარი დიპლომისთვის:
            </label>
            <input
              id="student-name-input"
              type="text"
              value={progress.studentName}
              onChange={(e) => onUpdateStudentName(e.target.value)}
              placeholder="მაგ: ნინო ბერიძე"
              className="px-4 py-2 rounded-xl border border-[#D8CBB3] bg-white text-sm"
            />
          </div>
          <button
            onClick={() => window.print()}
            className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl bg-[#7F1D1D] hover:bg-[#991B1B] text-white text-xs font-semibold cursor-pointer"
          >
            <Printer className="w-4 h-4" />
            <span>დიპლომის ამობეჭდვა</span>
          </button>
        </div>

        {/* Printable Ornate Diploma Sheet */}
        <div className="print-sheet rounded-2xl border-4 border-double border-[#B8860B] bg-[#FFFDF8] p-8 sm:p-12 shadow-lg relative">
          <div className="border border-[#DDD2BE] rounded-xl p-6 sm:p-10 text-center space-y-5">
            <div className="flex items-center justify-center gap-4">
              <JubileeSeal size={80} />
            </div>

            <div className="text-xs tracking-widest text-[#7F1D1D] font-semibold">
              „დედაენის“ 150 წლის საიუბილეო პორტალი · 1876–2026
            </div>

            <h2 className="font-serif text-3xl sm:text-4xl font-bold text-[#231B15]">
              საპატიო დიპლომი
            </h2>

            <p className="text-sm text-[#5C4E42]">გადაეცემა {progress.selectedGrade} კლასის მოსწავლეს</p>

            <div className="font-serif text-2xl sm:text-3xl font-bold text-[#7F1D1D] py-2 border-b border-[#D8CBB3] max-w-md mx-auto">
              {progress.studentName.trim() || 'ახალგაზრდა მკვლევარი'}
            </div>

            <p className="text-sm sm:text-base text-[#4A3B31] max-w-2xl mx-auto leading-relaxed">
              იაკობ გოგებაშვილის „დედაენის“ სამყაროში წარმატებული მოგზაურობისთვის, ქართული სიტყვისა და ზნეობრივი ღირებულებების გააზრებისთვის.
            </p>

            <OrnamentalDivider />

            <div className="grid sm:grid-cols-3 gap-4 text-xs text-[#231B15] max-w-2xl mx-auto">
              <div className="p-3 rounded-lg bg-[#FAF6EE] border border-[#E2D6C1]">
                <Award className="w-5 h-5 text-[#B8860B] mx-auto mb-1" />
                <div>მისიები: {progress.completedStories.length} / 5</div>
              </div>
              <div className="p-3 rounded-lg bg-[#FAF6EE] border border-[#E2D6C1]">
                <Star className="w-5 h-5 text-[#D4A017] mx-auto mb-1" />
                <div>ვარსკვლავები: {totalStars} / 15</div>
              </div>
              <div className="p-3 rounded-lg bg-[#FAF6EE] border border-[#E2D6C1]">
                <CheckCircle2 className="w-5 h-5 text-[#14532D] mx-auto mb-1" />
                <div>ასოების ბაღი: {progress.discoveredLetters.length} / 33</div>
              </div>
            </div>

            <div className="pt-6 flex flex-wrap items-end justify-between gap-6 max-w-xl mx-auto">
              <div className="text-left">
                <div className="text-xs text-[#6B5B4E]">თარიღი</div>
                <div className="text-sm font-semibold text-[#231B15] mt-1">2026 წელი</div>
              </div>
              <div className="text-right">
                <img
                  src={HISTORICAL_ASSETS.signature}
                  alt="იაკობ გოგებაშვილის ხელმოწერა"
                  className="h-9 ml-auto object-contain opacity-80"
                />
                <div className="text-[11px] text-[#6B5B4E] mt-1">
                  იაკობ გოგებაშვილის მემკვიდრეობის საფუძველზე
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
