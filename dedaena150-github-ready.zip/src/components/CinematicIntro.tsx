import React, { useEffect, useRef, useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { ArrowRight, SkipForward, RotateCcw } from 'lucide-react';
import { HISTORICAL_ASSETS } from '../data/biography';

interface CinematicIntroProps {
  onComplete: () => void;
}

const FLOATING_LETTERS = [
  { char: 'ა', x: 26, y: 36, delay: 1.8 },
  { char: 'ი', x: 34, y: 24, delay: 2.0 },
  { char: 'დ', x: 64, y: 26, delay: 2.15 },
  { char: 'ე', x: 72, y: 38, delay: 2.3 },
  { char: 'ნ', x: 42, y: 18, delay: 2.45 },
  { char: 'მ', x: 56, y: 17, delay: 2.6 },
  { char: 'ვ', x: 20, y: 50, delay: 2.75 },
  { char: 'ზ', x: 78, y: 48, delay: 2.9 },
];

export function CinematicIntro({ onComplete }: CinematicIntroProps) {
  const [stage, setStage] = useState<'closed' | 'opening' | 'blooming' | 'ready'>('closed');
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  useEffect(() => {
    const t1 = setTimeout(() => setStage('opening'), 650);
    const t2 = setTimeout(() => setStage('blooming'), 1750);
    const t3 = setTimeout(() => setStage('ready'), 3100);
    return () => {
      clearTimeout(t1);
      clearTimeout(t2);
      clearTimeout(t3);
    };
  }, []);

  // Golden sunbeams & floating light particles canvas
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animId = 0;
    const particles = Array.from({ length: 48 }, () => ({
      x: Math.random(),
      y: Math.random(),
      r: 1 + Math.random() * 2.5,
      vx: (Math.random() - 0.5) * 0.0003,
      vy: -0.0004 - Math.random() * 0.0005,
      alpha: 0.25 + Math.random() * 0.65,
    }));

    const render = () => {
      const w = (canvas.width = canvas.offsetWidth);
      const h = (canvas.height = canvas.offsetHeight);
      ctx.clearRect(0, 0, w, h);

      // Warm diagonal window sunbeams
      const beamGrad = ctx.createLinearGradient(0, 0, w * 0.72, h);
      beamGrad.addColorStop(0, 'rgba(253, 230, 138, 0.24)');
      beamGrad.addColorStop(0.55, 'rgba(212, 160, 23, 0.12)');
      beamGrad.addColorStop(1, 'rgba(212, 160, 23, 0)');
      ctx.fillStyle = beamGrad;
      ctx.beginPath();
      ctx.moveTo(w * 0.05, 0);
      ctx.lineTo(w * 0.42, 0);
      ctx.lineTo(w * 0.85, h);
      ctx.lineTo(w * 0.3, h);
      ctx.closePath();
      ctx.fill();

      // Golden dust motes
      particles.forEach((p) => {
        p.x += p.vx;
        p.y += p.vy;
        if (p.y < 0) {
          p.y = 1;
          p.x = 0.15 + Math.random() * 0.7;
        }
        ctx.beginPath();
        ctx.arc(p.x * w, p.y * h, p.r, 0, Math.PI * 2);
        ctx.fillStyle = `rgba(245, 198, 74, ${p.alpha})`;
        ctx.fill();
      });

      animId = requestAnimationFrame(render);
    };
    animId = requestAnimationFrame(render);
    return () => cancelAnimationFrame(animId);
  }, []);

  const replayIntro = () => {
    setStage('closed');
    setTimeout(() => setStage('opening'), 500);
    setTimeout(() => setStage('blooming'), 1500);
    setTimeout(() => setStage('ready'), 2800);
  };

  const bookIsOpen = stage !== 'closed';

  return (
    <div className="fixed inset-0 z-50 overflow-hidden bg-[#1D140E] text-[#FAF6EE] flex flex-col justify-between select-none">
      {/* Warm wooden desk surface */}
      <div
        className="absolute inset-0 pointer-events-none"
        style={{
          background:
            'radial-gradient(circle at 50% 42%, rgba(92, 58, 33, 0.65) 0%, rgba(29, 20, 14, 0.98) 76%)',
        }}
      />
      {/* Wood grain lines */}
      <div
        className="absolute bottom-0 inset-x-0 h-[34%] pointer-events-none border-t border-[#5A3E28]/50"
        style={{
          background:
            'linear-gradient(180deg, #3A2517 0%, #271910 60%, #1B110B 100%)',
        }}
      />

      <canvas ref={canvasRef} className="absolute inset-0 w-full h-full pointer-events-none" />

      {/* Top Skip / Replay bar */}
      <div className="relative z-20 flex items-center justify-between px-6 py-4">
        <div className="text-xs tracking-wider text-[#E6D5B8]/80 font-serif">
          1876–2026 · საიუბილეო გამოცემა
        </div>
        <div className="flex items-center gap-3">
          {stage === 'ready' && (
            <button
              onClick={replayIntro}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs text-[#E6D5B8] hover:text-white border border-[#E6D5B8]/25 rounded-lg transition-colors whitespace-nowrap cursor-pointer"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              თავიდან
            </button>
          )}
          <button
            onClick={onComplete}
            className="inline-flex items-center gap-1.5 px-4 py-1.5 text-xs font-medium bg-[#FAF6EE]/10 hover:bg-[#FAF6EE]/20 text-[#FAF6EE] border border-[#FAF6EE]/20 rounded-lg transition-colors whitespace-nowrap cursor-pointer"
          >
            <span>გამოტოვება</span>
            <SkipForward className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* Central Spatial 3D Book Stage */}
      <div className="relative z-10 flex-1 flex flex-col items-center justify-center px-4">
        <div className="relative w-full max-w-2xl h-[360px] sm:h-[400px] flex items-center justify-center" style={{ perspective: '1400px' }}>
          {/* Golden upward light aura from open pages */}
          <motion.div
            initial={{ opacity: 0, scale: 0.7 }}
            animate={{
              opacity: bookIsOpen ? 0.95 : 0,
              scale: bookIsOpen ? 1.05 : 0.7,
            }}
            transition={{ duration: 1.2, ease: 'easeOut' }}
            className="absolute -top-12 w-80 h-72 rounded-full pointer-events-none"
            style={{
              background:
                'radial-gradient(circle, rgba(251, 211, 102, 0.45) 0%, rgba(212, 160, 23, 0.14) 55%, transparent 75%)',
            }}
          />

          {/* Floating Georgian Letters */}
          <AnimatePresence>
            {(stage === 'blooming' || stage === 'ready') &&
              FLOATING_LETTERS.map((item) => (
                <motion.span
                  key={item.char}
                  initial={{ opacity: 0, y: 60, scale: 0.5 }}
                  animate={{ opacity: [0, 1, 0.9], y: [60, -10, -24], scale: 1 }}
                  transition={{ duration: 2.2, delay: item.delay - 1.7, ease: 'easeOut' }}
                  style={{ left: `${item.x}%`, top: `${item.y}%` }}
                  className="absolute font-serif text-2xl sm:text-3xl font-bold text-[#F6D365] drop-shadow-[0_2px_10px_rgba(212,160,23,0.7)] pointer-events-none"
                >
                  {item.char}
                </motion.span>
              ))}
          </AnimatePresence>

          {/* Blooming Violet Flower (იის ყვავილი) + Story World Silhouettes rising from book */}
          <AnimatePresence>
            {(stage === 'blooming' || stage === 'ready') && (
              <motion.div
                initial={{ opacity: 0, y: 36, scale: 0.5 }}
                animate={{ opacity: 1, y: -38, scale: 1 }}
                transition={{ duration: 1.3, ease: [0.16, 1, 0.3, 1] }}
                className="absolute z-20 flex flex-col items-center pointer-events-none"
              >
                <svg width="160" height="125" viewBox="0 0 160 125" fill="none">
                  {/* Blooming Violet */}
                  <path d="M80 112 C80 90, 79 75, 80 56" stroke="#4ADE80" strokeWidth="3" strokeLinecap="round" />
                  <path d="M80 94 C68 90, 62 80, 66 74 C73 74, 78 82, 80 94Z" fill="#22C55E" opacity="0.9" />
                  <path d="M80 90 C92 86, 98 76, 94 70 C87 70, 82 78, 80 90Z" fill="#16A34A" opacity="0.9" />
                  {/* 5 Violet Petals */}
                  <circle cx="80" cy="40" r="11" fill="#7C3AED" />
                  <circle cx="67" cy="48" r="10" fill="#6D28D9" />
                  <circle cx="93" cy="48" r="10" fill="#6D28D9" />
                  <circle cx="72" cy="59" r="9.5" fill="#5B21B6" />
                  <circle cx="88" cy="59" r="9.5" fill="#5B21B6" />
                  <circle cx="80" cy="50" r="5" fill="#FBBF24" />
                  {/* Story world silhouettes flanking the violet */}
                  {/* Left: Clay Pot + Ant */}
                  <g opacity="0.88" transform="translate(10, 66)">
                    <ellipse cx="14" cy="24" rx="10" ry="12" fill="#D97706" />
                    <rect x="8" y="8" width="12" height="5" rx="2" fill="#B45309" />
                  </g>
                  {/* Right: Grapevine Cross */}
                  <g opacity="0.9" transform="translate(124, 58)">
                    <path d="M12 4 V36 M3 15 L21 18" stroke="#FCD34D" strokeWidth="2.8" strokeLinecap="round" />
                    <circle cx="12" cy="16" r="2" fill="#FDE68A" />
                  </g>
                </svg>
                <span className="mt-1 font-serif text-lg font-bold tracking-wide text-[#FDE68A]">
                  აი ია
                </span>
              </motion.div>
            )}
          </AnimatePresence>

          {/* 3D Antique Book Container */}
          <div
            className="relative flex items-center justify-center transition-transform duration-1000"
            style={{
              transform: bookIsOpen ? 'rotateX(16deg) scale(1.03)' : 'rotateX(22deg) scale(0.95)',
              transformStyle: 'preserve-3d',
            }}
          >
            {/* Left Page (opens out) */}
            <motion.div
              initial={{ rotateY: 165, opacity: 0.4 }}
              animate={{
                rotateY: bookIsOpen ? 10 : 165,
                opacity: bookIsOpen ? 1 : 0.4,
              }}
              transition={{ duration: 1.15, ease: [0.22, 1, 0.36, 1] }}
              style={{ transformOrigin: 'right center' }}
              className="w-40 sm:w-56 h-56 sm:h-68 rounded-l-lg bg-gradient-to-r from-[#E6D7BA] to-[#FAF3E3] border border-[#C9B38C] shadow-2xl p-4 sm:p-6 flex flex-col justify-between text-[#231B15]"
            >
              <div className="border border-[#B8860B]/40 rounded h-full p-3 flex flex-col justify-between">
                <div className="text-[10px] tracking-widest text-[#7F1D1D] font-serif text-center">
                  1876
                </div>
                <div className="text-center font-serif">
                  <div className="text-2xl sm:text-3xl font-bold text-[#7F1D1D]">ა ი</div>
                  <div className="text-xl sm:text-2xl font-semibold text-[#5B21B6] mt-1">ი ა</div>
                </div>
                <div className="text-[10px] text-[#6B5B4E] text-center">
                  იაკობ გოგებაშვილი
                </div>
              </div>
            </motion.div>

            {/* Book Spine */}
            <div className="w-3 sm:w-4 h-56 sm:h-68 bg-gradient-to-b from-[#5A2D1A] via-[#7A3E24] to-[#4A2213] border-y border-[#B8860B]/60 shadow-inner z-10" />

            {/* Right Page / Front Leather Cover when closed */}
            <div className="relative w-40 sm:w-56 h-56 sm:h-68 rounded-r-lg bg-gradient-to-l from-[#E6D7BA] to-[#FAF3E3] border border-[#C9B38C] shadow-2xl p-4 sm:p-6 flex flex-col justify-between text-[#231B15]">
              {!bookIsOpen ? (
                <div className="absolute inset-0 rounded-r-lg bg-gradient-to-br from-[#6B2118] via-[#4E1711] to-[#320D09] border-2 border-[#D4A017]/60 p-5 flex flex-col items-center justify-center text-center shadow-2xl">
                  <div className="border border-[#D4A017]/50 w-full h-full flex flex-col items-center justify-center p-3">
                    <span className="text-[10px] text-[#FDE68A]/80 tracking-widest">1876</span>
                    <span className="font-serif text-xl sm:text-2xl font-bold text-[#FDE68A] mt-2">
                      დედაენა
                    </span>
                    <span className="text-[11px] text-[#E6D5B8]/80 mt-2">იაკობ გოგებაშვილი</span>
                  </div>
                </div>
              ) : (
                <div className="border border-[#B8860B]/40 rounded h-full p-3 flex flex-col justify-between">
                  <div className="text-[10px] tracking-widest text-[#14532D] font-serif text-center">
                    2026
                  </div>
                  <div className="space-y-1.5 text-[10px] sm:text-xs text-[#4A3B31] font-serif text-center">
                    <p>ხუთი უკვდავი მოთხრობა</p>
                    <p className="text-[#7F1D1D] font-semibold">ასოებიდან ღირებულებებამდე</p>
                  </div>
                  <img
                    src={HISTORICAL_ASSETS.signature}
                    alt="იაკობ გოგებაშვილის ხელმოწერა"
                    className="h-7 mx-auto object-contain opacity-80"
                  />
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Jubilee Title & Primary CTA */}
        <motion.div
          initial={{ opacity: 0, y: 18 }}
          animate={{ opacity: stage === 'ready' ? 1 : 0, y: stage === 'ready' ? 0 : 18 }}
          transition={{ duration: 0.7 }}
          className="text-center max-w-2xl mt-2"
        >
          <h1 className="font-serif text-3xl sm:text-5xl font-bold text-[#FDE68A] tracking-tight">
            დედაენა 150 — 1876–2026
          </h1>
          <p className="mt-3 text-sm sm:text-base text-[#E6D5B8]">
            ასოებიდან ღირებულებებამდე · წაიკითხე, აღმოაჩინე, ითამაშე, გაიაზრე!
          </p>
          <div className="mt-6">
            <button
              onClick={onComplete}
              className="inline-flex items-center gap-2.5 px-7 py-3.5 rounded-xl bg-[#B8860B] hover:bg-[#D4A017] text-[#1D140E] font-semibold text-base shadow-lg transition-all cursor-pointer"
            >
              <span>დაიწყე მოგზაურობა</span>
              <ArrowRight className="w-5 h-5" />
            </button>
          </div>
        </motion.div>
      </div>

      <div className="relative z-10 text-center pb-5 text-xs text-[#E6D5B8]/60">
        იაკობ გოგებაშვილის მემკვიდრეობა · I–VI კლასების ინტერაქტიული საგანმანათლებლო სამყარო
      </div>
    </div>
  );
}
