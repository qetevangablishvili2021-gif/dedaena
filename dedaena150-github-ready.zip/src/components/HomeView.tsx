import React, { useState } from 'react';
import {
  BookOpen,
  Compass,
  Gamepad2,
  Award,
  GraduationCap,
  PlayCircle,
  Sparkles,
  ArrowRight,
  Landmark,
} from 'lucide-react';
import { GradeLevel, PortalView, StoryId, StudentProgress } from '../types';
import {
  HISTORICAL_ASSETS,
  INTERESTING_FACTS,
  TIMELINE_MILESTONES,
} from '../data/biography';
import { STORIES } from '../data/stories';
import { ArchivalImage, JubileeSeal, OrnamentalDivider } from './OrnamentalDivider';

interface HomeViewProps {
  progress: StudentProgress;
  onNavigate: (view: PortalView, storyId?: StoryId) => void;
  onReplayIntro: () => void;
  onSelectGrade: (grade: GradeLevel) => void;
}

const GRADES: GradeLevel[] = ['I', 'II', 'III', 'IV', 'V', 'VI'];

export function HomeView({
  progress,
  onNavigate,
  onReplayIntro,
  onSelectGrade,
}: HomeViewProps) {
  const [selectedTimelineIdx, setSelectedTimelineIdx] = useState(3); // 1876 Dedaena default
  const activeMilestone = TIMELINE_MILESTONES[selectedTimelineIdx];

  const totalStars = Object.values(progress.completedGames).reduce((a, b) => a + b, 0);

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 py-8 space-y-14">
      {/* Hero Section */}
      <section className="grid lg:grid-cols-12 gap-8 items-stretch">
        <div className="lg:col-span-7 vellum-card rounded-2xl p-6 sm:p-10 flex flex-col justify-between">
          <div>
            <div className="flex flex-wrap items-center justify-between gap-4">
              <div className="text-xs font-medium text-[#7F1D1D]">
                1876–2026 · საიუბილეო საგანმანათლებლო პორტალი · I–VI კლასები
              </div>
              <JubileeSeal size={66} />
            </div>

            <h1 className="font-serif text-3xl sm:text-5xl font-bold text-[#231B15] leading-tight mt-4">
              დედაენა 150 — ასოებიდან ღირებულებებამდე
            </h1>

            <p className="mt-4 text-base sm:text-lg text-[#4A3B31] leading-relaxed max-w-2xl">
              წაიკითხე, აღმოაჩინე, ითამაშე, გაიაზრე! იაკობ გოგებაშვილის უკვდავი მემკვიდრეობა გაცოცხლებულია ერთიან ინტერაქტიულ სამყაროში.
            </p>

            {/* Grade organizational filter */}
            <div className="mt-6 pt-5 border-t border-[#EAE1D0]">
              <div className="text-xs font-medium text-[#6B5B4E] mb-2.5">
                აირჩიე შენი კლასი (სასწავლო ორიენტირი):
              </div>
              <div className="flex flex-wrap items-center gap-1.5">
                {GRADES.map((g) => (
                  <button
                    key={g}
                    onClick={() => onSelectGrade(g)}
                    className={`px-3.5 py-1.5 rounded-lg text-xs font-semibold border transition-colors cursor-pointer whitespace-nowrap ${
                      progress.selectedGrade === g
                        ? 'bg-[#7F1D1D] text-white border-[#7F1D1D]'
                        : 'bg-[#FAF6EE] text-[#231B15] border-[#DDD2BE] hover:bg-[#F2E9D8]'
                    }`}
                  >
                    {g} კლასი
                  </button>
                ))}
              </div>
            </div>
          </div>

          <div className="mt-8 flex flex-wrap items-center gap-3">
            <button
              onClick={() => onNavigate('map')}
              className="inline-flex items-center gap-2 px-6 py-3 rounded-xl bg-[#7F1D1D] hover:bg-[#991B1B] text-white font-semibold text-sm transition-colors cursor-pointer whitespace-nowrap"
            >
              <Compass className="w-4 h-4" />
              <span>გახსენი მოგზაურობის რუკა</span>
            </button>
            <button
              onClick={() => onNavigate('alphabet')}
              className="inline-flex items-center gap-2 px-5 py-3 rounded-xl bg-[#14532D] hover:bg-[#166534] text-white font-semibold text-sm transition-colors cursor-pointer whitespace-nowrap"
            >
              <span>ასოების სამყარო „აი ია“</span>
            </button>
            <button
              onClick={onReplayIntro}
              className="inline-flex items-center gap-1.5 px-4 py-3 rounded-xl border border-[#D8CBB3] bg-[#FFFDF8] hover:bg-[#F5EFE2] text-[#231B15] text-sm font-medium transition-colors cursor-pointer whitespace-nowrap"
            >
              <PlayCircle className="w-4 h-4 text-[#B8860B]" />
              <span>წიგნის გახსნა</span>
            </button>
          </div>
        </div>

        {/* Authentic Historical Portrait & Signature Card */}
        <div className="lg:col-span-5 vellum-card rounded-2xl p-6 flex flex-col justify-between bg-[#FFFDF8]">
          <div className="grid sm:grid-cols-2 lg:grid-cols-1 gap-5 items-center">
            <div className="flex flex-col sm:flex-row lg:flex-row items-center gap-5">
              <ArchivalImage
                src={HISTORICAL_ASSETS.portraitPrimary}
                alt="იაკობ გოგებაშვილის ისტორიული პორტრეტი"
                className="w-36 h-44 object-cover rounded-xl border border-[#D8CBB3] shadow-sm shrink-0"
              />
              <div>
                <div className="text-xs font-medium text-[#7F1D1D]">
                  1840 – 1912
                </div>
                <h2 className="font-serif text-xl font-bold text-[#231B15] mt-1">
                  იაკობ გოგებაშვილი
                </h2>
                <p className="text-xs text-[#5C4E42] leading-relaxed mt-2">
                  ქართული მეცნიერული პედაგოგიკის ფუძემდებელი, საბავშვო მწერალი და „დედაენის“ ავტორი.
                </p>
                <div className="mt-3 pt-3 border-t border-[#EAE1D0] flex items-center gap-3">
                  <ArchivalImage
                    src={HISTORICAL_ASSETS.signature}
                    alt="იაკობ გოგებაშვილის ავთენტური ხელმოწერა"
                    className="h-9 object-contain opacity-85"
                  />
                </div>
              </div>
            </div>
          </div>

          {/* Student Progress Summary Strip */}
          <div className="mt-6 pt-5 border-t border-[#EAE1D0] grid grid-cols-3 gap-3 text-center">
            <div className="p-3 rounded-xl bg-[#FAF6EE] border border-[#E6DAC5]">
              <div className="text-xl font-bold text-[#7F1D1D] tabular-nums">
                {progress.completedStories.length}/5
              </div>
              <div className="text-[11px] text-[#5C4E42] mt-0.5">ნაწარმოები</div>
            </div>
            <div className="p-3 rounded-xl bg-[#FAF6EE] border border-[#E6DAC5]">
              <div className="text-xl font-bold text-[#B8860B] tabular-nums">
                {totalStars}/15
              </div>
              <div className="text-[11px] text-[#5C4E42] mt-0.5">ვარსკვლავი</div>
            </div>
            <div className="p-3 rounded-xl bg-[#FAF6EE] border border-[#E6DAC5]">
              <div className="text-xl font-bold text-[#14532D] tabular-nums">
                {progress.discoveredLetters.length}/33
              </div>
              <div className="text-[11px] text-[#5C4E42] mt-0.5">ანბანის ბაღი</div>
            </div>
          </div>
        </div>
      </section>

      <OrnamentalDivider />

      {/* Section: Five Educational Worlds */}
      <section>
        <div className="mb-6">
          <div className="text-xs font-medium text-[#7F1D1D]">პორტალის არქიტექტურა</div>
          <h2 className="font-serif text-2xl sm:text-3xl font-bold text-[#231B15] mt-1">
            ხუთი საგანმანათლებლო სამყარო
          </h2>
        </div>

        <div className="grid sm:grid-cols-2 lg:grid-cols-5 gap-4">
          {[
            {
              num: 'I',
              title: 'ასოების სამყარო',
              desc: '33 ქართული ასო, გამოწერის დაფა, „აი ია“ ბაღი და სიტყვების თავსატეხები.',
              icon: Sparkles,
              color: 'text-[#5B21B6]',
              action: () => onNavigate('alphabet'),
            },
            {
              num: 'II',
              title: 'გაცოცხლებული ნაწარმოებები',
              desc: 'სრული ტექსტები, ძველი სიტყვების ლექსიკონი და ანიმაციური კინოთეატრი.',
              icon: BookOpen,
              color: 'text-[#7F1D1D]',
              action: () => onNavigate('story', 'pot'),
            },
            {
              num: 'III',
              title: 'თამაშების სამყარო',
              desc: 'ხუთი განსხვავებული სიუჟეტური ვიდეოთამაში და სათავგადასავლო რუკა.',
              icon: Gamepad2,
              color: 'text-[#14532D]',
              action: () => onNavigate('map'),
            },
            {
              num: 'IV',
              title: 'ღირებულებების სამყარო',
              desc: 'მორალური გაკვეთილების კავშირი დღევანდელობასთან და პერსონალური დიპლომი.',
              icon: Award,
              color: 'text-[#B8860B]',
              action: () => onNavigate('values'),
            },
            {
              num: 'V',
              title: 'მასწავლებლის სახელოსნო',
              desc: 'გაკვეთილის გეგმები, პროექტორის რეჟიმი, სამუშაო ფურცლები და რუბრიკები.',
              icon: GraduationCap,
              color: 'text-[#231B15]',
              action: () => onNavigate('teacher'),
            },
          ].map((world) => {
            const Icon = world.icon;
            return (
              <button
                key={world.num}
                onClick={world.action}
                className="vellum-card rounded-2xl p-5 text-left hover:border-[#B8860B] transition-all flex flex-col justify-between group cursor-pointer"
              >
                <div>
                  <div className="flex items-center justify-between">
                    <span className="font-serif text-sm font-bold text-[#6B5B4E]">
                      {world.num}. სამყარო
                    </span>
                    <Icon className={`w-5 h-5 ${world.color}`} />
                  </div>
                  <h3 className="font-serif text-lg font-bold text-[#231B15] mt-3 group-hover:text-[#7F1D1D] transition-colors">
                    {world.title}
                  </h3>
                  <p className="text-xs text-[#5C4E42] leading-relaxed mt-2">
                    {world.desc}
                  </p>
                </div>
                <div className="mt-4 pt-3 border-t border-[#EAE1D0] flex items-center justify-between text-xs font-semibold text-[#7F1D1D]">
                  <span>შესვლა</span>
                  <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
                </div>
              </button>
            );
          })}
        </div>
      </section>

      {/* Quick Stories Shelf */}
      <section>
        <div className="flex flex-wrap items-end justify-between gap-4 mb-6">
          <div>
            <div className="text-xs font-medium text-[#7F1D1D]">I–VI კლასების საგანძური</div>
            <h2 className="font-serif text-2xl sm:text-3xl font-bold text-[#231B15] mt-1">
              ხუთი ნაწარმოები — ხუთი ღირებულება
            </h2>
          </div>
          <button
            onClick={() => onNavigate('map')}
            className="text-xs font-semibold text-[#7F1D1D] hover:underline cursor-pointer"
          >
            ყველას ნახვა რუკაზე →
          </button>
        </div>

        <div className="grid md:grid-cols-5 gap-4">
          {STORIES.map((story) => {
            const done = progress.completedStories.includes(story.id);
            return (
              <button
                key={story.id}
                onClick={() => onNavigate('story', story.id)}
                className="vellum-card rounded-2xl p-5 text-left hover:border-[#B8860B] transition-all flex flex-col justify-between cursor-pointer"
              >
                <div>
                  <div className="text-[11px] font-medium text-[#6B5B4E]">
                    {story.recommendedGrade}
                  </div>
                  <h3 className="font-serif text-base font-bold text-[#231B15] mt-1.5 leading-snug">
                    {story.title}
                  </h3>
                  <div className="text-xs font-medium text-[#14532D] mt-2">
                    {story.valueTitle}
                  </div>
                </div>
                <div className="mt-4 pt-3 border-t border-[#EAE1D0] flex items-center justify-between text-xs">
                  <span className={done ? 'text-[#14532D] font-semibold' : 'text-[#6B5B4E]'}>
                    {done ? '✓ შესრულებულია' : 'მისია ' + story.missionNumber}
                  </span>
                  <span className="text-[#7F1D1D] font-semibold">გახსნა →</span>
                </div>
              </button>
            );
          })}
        </div>
      </section>

      <OrnamentalDivider />

      {/* Interactive Biography Timeline & Archival Gallery */}
      <section className="space-y-8">
        <div>
          <div className="text-xs font-medium text-[#7F1D1D] flex items-center gap-1.5">
            <Landmark className="w-4 h-4" />
            <span>ინტერაქტიული ბიოგრაფია და ისტორიული დროის ხაზი</span>
          </div>
          <h2 className="font-serif text-2xl sm:text-3xl font-bold text-[#231B15] mt-1">
            იაკობ გოგებაშვილის ცხოვრება და „დედაენის“ შექმნა
          </h2>
        </div>

        {/* Interactive Timeline Controls */}
        <div className="flex flex-wrap gap-2">
          {TIMELINE_MILESTONES.map((m, idx) => (
            <button
              key={m.year}
              onClick={() => setSelectedTimelineIdx(idx)}
              className={`px-4 py-2 rounded-xl text-xs font-semibold border transition-colors cursor-pointer tabular-nums whitespace-nowrap ${
                selectedTimelineIdx === idx
                  ? 'bg-[#231B15] text-[#FDE68A] border-[#231B15]'
                  : 'bg-[#FFFDF8] text-[#4A3B31] border-[#DDD2BE] hover:bg-[#F2E9D8]'
              }`}
            >
              {m.year}
            </button>
          ))}
        </div>

        <div className="grid lg:grid-cols-12 gap-6 items-stretch">
          <div className="lg:col-span-7 vellum-card rounded-2xl p-6 sm:p-8 flex flex-col justify-between">
            <div>
              <div className="text-sm font-bold text-[#B8860B] tabular-nums">
                {activeMilestone.year} წელი
              </div>
              <h3 className="font-serif text-2xl font-bold text-[#231B15] mt-1">
                {activeMilestone.title}
              </h3>
              <p className="mt-3 text-sm font-medium text-[#7F1D1D] leading-relaxed">
                {activeMilestone.summary}
              </p>
              <p className="mt-4 text-sm text-[#4A3B31] leading-relaxed">
                {activeMilestone.detail}
              </p>
            </div>

            <div className="mt-6 pt-4 border-t border-[#EAE1D0] flex items-center justify-between text-xs text-[#6B5B4E]">
              <span>პირადი არქივი დაცულია საქართველოს ხელნაწერთა ეროვნულ ცენტრში.</span>
              <div className="flex gap-2">
                <button
                  onClick={() => setSelectedTimelineIdx((i) => Math.max(0, i - 1))}
                  disabled={selectedTimelineIdx === 0}
                  className="px-3 py-1 rounded border border-[#D8CBB3] disabled:opacity-40 cursor-pointer"
                >
                  წინა
                </button>
                <button
                  onClick={() =>
                    setSelectedTimelineIdx((i) => Math.min(TIMELINE_MILESTONES.length - 1, i + 1))
                  }
                  disabled={selectedTimelineIdx === TIMELINE_MILESTONES.length - 1}
                  className="px-3 py-1 rounded border border-[#D8CBB3] disabled:opacity-40 cursor-pointer"
                >
                  შემდეგი
                </button>
              </div>
            </div>
          </div>

          <div className="lg:col-span-5 vellum-card rounded-2xl p-5 flex flex-col justify-between">
            {activeMilestone.image ? (
              <ArchivalImage
                src={activeMilestone.image}
                alt={activeMilestone.imageCaption || activeMilestone.title}
                caption={activeMilestone.imageCaption}
                className="w-full h-64 object-cover rounded-xl border border-[#DDD2BE]"
              />
            ) : (
              <div className="grid grid-cols-2 gap-3 h-full">
                <ArchivalImage
                  src={HISTORICAL_ASSETS.varianiMuseum}
                  alt="იაკობ გოგებაშვილის სახლ-მუზეუმი ვარიანში"
                  caption="სახლ-მუზეუმი სოფელ ვარიანში"
                  className="w-full h-44 object-cover rounded-xl border border-[#DDD2BE]"
                />
                <ArchivalImage
                  src={HISTORICAL_ASSETS.mtatsmindaBust}
                  alt="იაკობ გოგებაშვილის ძეგლი მთაწმინდის პანთეონში"
                  caption="ძეგლი მთაწმინდის პანთეონში"
                  className="w-full h-44 object-cover rounded-xl border border-[#DDD2BE]"
                />
              </div>
            )}
            <div className="mt-4 pt-3 border-t border-[#EAE1D0] flex items-center justify-between text-xs text-[#6B5B4E]">
              <span>სახალხო განათლების ფუძემდებელი</span>
              <img
                src={HISTORICAL_ASSETS.emblem}
                alt="საქართველოს ისტორიული ემბლემა"
                className="w-7 h-7 object-contain"
              />
            </div>
          </div>
        </div>

        {/* Interesting Facts */}
        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {INTERESTING_FACTS.map((fact) => (
            <div key={fact.title} className="vellum-card rounded-2xl p-5">
              <h4 className="font-serif text-base font-bold text-[#7F1D1D]">{fact.title}</h4>
              <p className="mt-2 text-xs text-[#4A3B31] leading-relaxed">{fact.text}</p>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
}
