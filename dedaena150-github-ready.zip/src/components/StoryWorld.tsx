import React, { useEffect, useRef, useState } from 'react';
import {
  BookOpen,
  Film,
  Compass,
  Gamepad2,
  HeartHandshake,
  Palette,
  Maximize2,
  Minimize2,
  ChevronLeft,
  ChevronRight,
  CheckCircle2,
  Bookmark,
  Printer,
} from 'lucide-react';
import { STORIES } from '../data/stories';
import { StoryId, StoryTab, StudentProgress } from '../types';
import { StoryCinemaCanvas } from './StoryCinemaCanvas';
import { StoryGameContainer } from './games/StoryGames';
import { OrnamentalDivider } from './OrnamentalDivider';
import { soundFX } from '../utils/sound';

interface StoryWorldProps {
  storyId: StoryId;
  progress: StudentProgress;
  onSelectStory: (id: StoryId) => void;
  onSaveBookmark: (storyId: StoryId, page: number) => void;
  onCompleteStory: (storyId: StoryId) => void;
  onFinishGame: (storyId: StoryId, stars: number) => void;
  onSaveReflection: (storyId: StoryId, text: string) => void;
  onSaveArtwork: (storyId: StoryId, dataUrl: string) => void;
}

const TABS: { id: StoryTab; label: string; icon: React.ElementType }[] = [
  { id: 'read', label: '1. წავიკითხოთ', icon: BookOpen },
  { id: 'cinema', label: '2. ვუყუროთ', icon: Film },
  { id: 'discover', label: '3. აღმოვაჩინოთ', icon: Compass },
  { id: 'game', label: '4. ვითამაშოთ', icon: Gamepad2 },
  { id: 'reflect', label: '5. დავფიქრდეთ', icon: HeartHandshake },
  { id: 'create', label: '6. შევქმნათ', icon: Palette },
];

export function StoryWorld({
  storyId,
  progress,
  onSelectStory,
  onSaveBookmark,
  onCompleteStory,
  onFinishGame,
  onSaveReflection,
  onSaveArtwork,
}: StoryWorldProps) {
  const story = STORIES.find((s) => s.id === storyId) || STORIES[0];
  const [activeTab, setActiveTab] = useState<StoryTab>('read');

  // E-Book reader state
  const savedPage = progress.storyBookmarks[story.id] || 0;
  const [pageIdx, setPageIdx] = useState(savedPage);
  const [fontSize, setFontSize] = useState<'sm' | 'md' | 'lg'>('md');
  const [showGlossary, setShowGlossary] = useState(true);
  const [showParallelPreview, setShowParallelPreview] = useState(false);
  const [readerFullscreen, setReaderFullscreen] = useState(false);

  // Reflection state
  const [reflectionAnswers, setReflectionAnswers] = useState<Record<string, number>>({});
  const [journalDraft, setJournalDraft] = useState(progress.reflections[story.id] || '');
  const [journalSaved, setJournalSaved] = useState(false);

  useEffect(() => {
    setPageIdx(progress.storyBookmarks[story.id] || 0);
    setJournalDraft(progress.reflections[story.id] || '');
    setJournalSaved(false);
    setReflectionAnswers({});
  }, [story.id, progress.storyBookmarks, progress.reflections]);

  const paragraphsPerPage = 2;
  const totalPages = Math.max(1, Math.ceil(story.paragraphs.length / paragraphsPerPage));
  const safePageIdx = Math.min(pageIdx, totalPages - 1);
  const visibleParagraphs = story.paragraphs.slice(
    safePageIdx * paragraphsPerPage,
    safePageIdx * paragraphsPerPage + paragraphsPerPage
  );

  const changePage = (nextPage: number) => {
    const clamped = Math.max(0, Math.min(totalPages - 1, nextPage));
    setPageIdx(clamped);
    onSaveBookmark(story.id, clamped);
    if (clamped === totalPages - 1) {
      onCompleteStory(story.id);
    }
  };

  const fontClass =
    fontSize === 'sm'
      ? 'text-base leading-relaxed'
      : fontSize === 'lg'
      ? 'text-xl sm:text-2xl leading-loose'
      : 'text-lg leading-relaxed';

  return (
    <section className="max-w-7xl mx-auto px-4 sm:px-6 py-8 space-y-6">
      {/* Story Selector Strip (No locked order) */}
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div className="flex flex-wrap gap-1.5">
          {STORIES.map((s) => (
            <button
              key={s.id}
              onClick={() => {
                soundFX.playClick();
                onSelectStory(s.id);
              }}
              className={`px-3.5 py-2 rounded-xl text-xs font-semibold border transition-colors cursor-pointer whitespace-nowrap ${
                s.id === story.id
                  ? 'bg-[#7F1D1D] text-white border-[#7F1D1D]'
                  : 'bg-[#FFFDF8] text-[#4A3B31] border-[#DDD2BE] hover:border-[#B8860B]'
              }`}
            >
              {s.missionNumber}. {s.title}
            </button>
          ))}
        </div>
      </div>

      {/* Story Title Banner */}
      <div className="vellum-card rounded-2xl p-6 sm:p-8">
        <div className="flex flex-wrap items-start justify-between gap-4">
          <div>
            <div className="text-xs font-medium text-[#6B5B4E]">
              {story.recommendedGrade} · {story.locationName} · ღირებულება: {story.valueTitle}
            </div>
            <h1 className="font-serif text-2xl sm:text-4xl font-bold text-[#231B15] mt-1.5">
              {story.title}
            </h1>
            <p className="text-sm text-[#5C4E42] mt-1.5">{story.subtitle}</p>
          </div>
          {progress.completedStories.includes(story.id) && (
            <span className="inline-flex items-center gap-1.5 text-xs font-semibold text-[#14532D]">
              <CheckCircle2 className="w-4 h-4" />
              წაკითხული და შესრულებული
            </span>
          )}
        </div>

        {/* 6 Section Tabs */}
        <div className="mt-6 pt-5 border-t border-[#EAE1D0] flex flex-wrap gap-1.5">
          {TABS.map((t) => {
            const Icon = t.icon;
            const active = activeTab === t.id;
            return (
              <button
                key={t.id}
                onClick={() => {
                  soundFX.playClick();
                  setActiveTab(t.id);
                }}
                className={`inline-flex items-center gap-1.5 px-4 py-2.5 rounded-xl text-xs font-semibold border transition-colors cursor-pointer whitespace-nowrap ${
                  active
                    ? 'bg-[#231B15] text-[#FDE68A] border-[#231B15]'
                    : 'bg-[#FAF6EE] text-[#231B15] border-[#DDD2BE] hover:bg-[#F2E9D8]'
                }`}
              >
                <Icon className="w-3.5 h-3.5" />
                <span>{t.label}</span>
              </button>
            );
          })}
        </div>
      </div>

      {/* 1. READ TAB (E-BOOK READER) */}
      {activeTab === 'read' && (
        <div
          className={`${
            readerFullscreen ? 'fixed inset-0 z-50 bg-[#FAF6EE] p-4 sm:p-8 overflow-y-auto' : ''
          }`}
        >
          {/* Reader Toolbar */}
          <div className="vellum-card rounded-2xl p-4 mb-5 flex flex-wrap items-center justify-between gap-3">
            <div className="flex flex-wrap items-center gap-2">
              <span className="text-xs text-[#6B5B4E] inline-flex items-center gap-1">
                <Bookmark className="w-3.5 h-3.5 text-[#7F1D1D]" />
                გვერდი {safePageIdx + 1} / {totalPages}
              </span>
              <span className="text-[#D8CBB3]" aria-hidden="true">·</span>
              <div className="flex items-center gap-1 bg-[#FAF6EE] p-1 rounded-lg border border-[#DDD2BE]">
                {(
                  [
                    ['sm', 'ა-'],
                    ['md', 'ა'],
                    ['lg', 'ა+'],
                  ] as const
                ).map(([sz, lbl]) => (
                  <button
                    key={sz}
                    onClick={() => setFontSize(sz)}
                    className={`px-2.5 py-1 rounded text-xs font-bold cursor-pointer ${
                      fontSize === sz ? 'bg-[#7F1D1D] text-white' : 'text-[#231B15]'
                    }`}
                  >
                    {lbl}
                  </button>
                ))}
              </div>
            </div>

            <div className="flex flex-wrap items-center gap-2">
              <button
                onClick={() => setShowGlossary((g) => !g)}
                className={`px-3 py-1.5 rounded-lg text-xs font-medium border cursor-pointer ${
                  showGlossary
                    ? 'bg-[#14532D] text-white border-[#14532D]'
                    : 'bg-white text-[#231B15] border-[#D8CBB3]'
                }`}
              >
                ძველი სიტყვების განმარტება
              </button>
              <button
                onClick={() => setShowParallelPreview((p) => !p)}
                className={`px-3 py-1.5 rounded-lg text-xs font-medium border cursor-pointer ${
                  showParallelPreview
                    ? 'bg-[#7F1D1D] text-white border-[#7F1D1D]'
                    : 'bg-white text-[#231B15] border-[#D8CBB3]'
                }`}
              >
                პარალელური ანიმაცია
              </button>
              <button
                onClick={() => setReaderFullscreen((f) => !f)}
                className="inline-flex items-center gap-1 px-3 py-1.5 rounded-lg border border-[#D8CBB3] bg-white text-xs font-medium cursor-pointer"
              >
                {readerFullscreen ? <Minimize2 className="w-3.5 h-3.5" /> : <Maximize2 className="w-3.5 h-3.5" />}
                <span>{readerFullscreen ? 'დახურვა' : 'მთელი ეკრანი'}</span>
              </button>
            </div>
          </div>

          <div className="grid lg:grid-cols-12 gap-6 items-start">
            {/* Book Page */}
            <div
              className={`${
                showGlossary ? 'lg:col-span-8' : 'lg:col-span-12'
              } vellum-card rounded-2xl p-6 sm:p-10 bg-[#FFFDF8]`}
            >
              <div className="max-w-prose mx-auto space-y-6">
                {safePageIdx === 0 && (
                  <div className="text-center pb-4 border-b border-[#EAE1D0]">
                    <div className="text-xs text-[#7F1D1D] font-serif">იაკობ გოგებაშვილი</div>
                    <h2 className="font-serif text-2xl sm:text-3xl font-bold text-[#231B15] mt-1">
                      {story.title}
                    </h2>
                  </div>
                )}

                {visibleParagraphs.map((para, i) => (
                  <p
                    key={i}
                    className={`font-serif text-[#231B15] ${fontClass} ${
                      safePageIdx === 0 && i === 0 ? 'drop-cap' : ''
                    }`}
                  >
                    {para}
                  </p>
                ))}

                {/* Page Turn Controls */}
                <div className="pt-6 border-t border-[#EAE1D0] flex items-center justify-between">
                  <button
                    onClick={() => changePage(safePageIdx - 1)}
                    disabled={safePageIdx === 0}
                    className="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl border border-[#D8CBB3] bg-[#FAF6EE] disabled:opacity-40 text-xs font-semibold cursor-pointer"
                  >
                    <ChevronLeft className="w-4 h-4" />
                    <span>წინა ფურცელი</span>
                  </button>

                  {safePageIdx === totalPages - 1 ? (
                    <button
                      onClick={() => {
                        onCompleteStory(story.id);
                        setActiveTab('cinema');
                      }}
                      className="inline-flex items-center gap-1.5 px-5 py-2.5 rounded-xl bg-[#14532D] text-white text-xs font-semibold cursor-pointer"
                    >
                      <span>წაკითხულია! ნახე ანიმაციური კინოთეატრი →</span>
                    </button>
                  ) : (
                    <button
                      onClick={() => changePage(safePageIdx + 1)}
                      className="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl bg-[#7F1D1D] text-white text-xs font-semibold cursor-pointer"
                    >
                      <span>შემდეგი ფურცელი</span>
                      <ChevronRight className="w-4 h-4" />
                    </button>
                  )}
                </div>
              </div>

              {showParallelPreview && (
                <div className="mt-8 pt-6 border-t border-[#EAE1D0]">
                  <StoryCinemaCanvas
                    storyId={story.id}
                    storyTitle={story.title}
                    scenes={story.scenes}
                  />
                </div>
              )}
            </div>

            {/* Separate Archival Glossary Panel */}
            {showGlossary && (
              <aside className="lg:col-span-4 vellum-card rounded-2xl p-5 space-y-4">
                <div>
                  <h3 className="font-serif text-lg font-bold text-[#7F1D1D]">
                    ძველი ქართული სიტყვების განმარტება
                  </h3>
                  <p className="text-xs text-[#6B5B4E] mt-0.5">
                    ცალკე ლექსიკონი ავტორის ორიგინალური ტექსტის უკეთ გასაგებად.
                  </p>
                </div>
                <div className="divide-y divide-[#EAE1D0]">
                  {story.glossary.map((item) => (
                    <div key={item.word} className="py-3 first:pt-0 last:pb-0">
                      <div className="font-serif text-sm font-bold text-[#231B15]">
                        {item.word}
                      </div>
                      <p className="text-xs text-[#4A3B31] mt-1 leading-relaxed">
                        {item.meaning}
                      </p>
                      <p className="text-[11px] text-[#6B5B4E] italic mt-1">
                        {item.context}
                      </p>
                    </div>
                  ))}
                </div>
              </aside>
            )}
          </div>
        </div>
      )}

      {/* 2. CINEMA TAB */}
      {activeTab === 'cinema' && (
        <StoryCinemaCanvas
          storyId={story.id}
          storyTitle={story.title}
          scenes={story.scenes}
          onCompleteCinema={() => onCompleteStory(story.id)}
        />
      )}

      {/* 3. DISCOVER TAB */}
      {activeTab === 'discover' && (
        <div className="space-y-6">
          <div className="grid md:grid-cols-3 gap-5">
            {story.discoveries.map((fact) => (
              <div key={fact.title} className="vellum-card rounded-2xl p-6 flex flex-col justify-between">
                <div>
                  <div className="text-xs font-semibold text-[#7F1D1D]">{fact.category}</div>
                  <h3 className="font-serif text-lg font-bold text-[#231B15] mt-1.5">
                    {fact.title}
                  </h3>
                  <p className="text-sm text-[#4A3B31] leading-relaxed mt-3">{fact.body}</p>
                </div>
              </div>
            ))}
          </div>

          <div className="vellum-card rounded-2xl p-6">
            <h3 className="font-serif text-xl font-bold text-[#231B15] mb-3">
              სიტყვების საგანძური ამ ნაწარმოებიდან
            </h3>
            <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-3">
              {story.glossary.map((g) => (
                <div key={g.word} className="p-4 rounded-xl bg-[#FAF6EE] border border-[#E2D6C1]">
                  <div className="font-serif font-bold text-[#7F1D1D]">{g.word}</div>
                  <div className="text-xs text-[#4A3B31] mt-1 leading-relaxed">{g.meaning}</div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* 4. GAME TAB */}
      {activeTab === 'game' && (
        <StoryGameContainer
          storyId={story.id}
          gameTitle={story.gameTitle}
          gameDescription={story.gameDescription}
          onFinishGame={(stars) => {
            onFinishGame(story.id, stars);
            onCompleteStory(story.id);
          }}
        />
      )}

      {/* 5. REFLECT TAB */}
      {activeTab === 'reflect' && (
        <div className="grid lg:grid-cols-12 gap-6">
          <div className="lg:col-span-7 space-y-5">
            <div className="vellum-card rounded-2xl p-6 sm:p-8">
              <div className="text-xs font-semibold text-[#14532D]">
                მთავარი ღირებულება · {story.valueTitle}
              </div>
              <h2 className="font-serif text-2xl font-bold text-[#231B15] mt-1.5">
                {story.reflection.coreMessage}
              </h2>
              <OrnamentalDivider />
              <p className="text-sm text-[#4A3B31] leading-relaxed">
                <strong>კავშირი თანამედროვე ცხოვრებასთან:</strong> {story.reflection.modernBridge}
              </p>
            </div>

            {story.reflection.scenarios.map((sc) => {
              const pickedIdx = reflectionAnswers[sc.id];
              return (
                <div key={sc.id} className="vellum-card rounded-2xl p-6 space-y-4">
                  <div className="text-xs font-semibold text-[#7F1D1D]">ცხოვრებისეული სიტუაცია</div>
                  <p className="text-sm text-[#231B15] font-medium leading-relaxed">{sc.situation}</p>
                  <p className="text-xs text-[#5C4E42]">{sc.question}</p>
                  <div className="space-y-2.5">
                    {sc.choices.map((ch, idx) => (
                      <button
                        key={idx}
                        onClick={() => {
                          setReflectionAnswers((prev) => ({ ...prev, [sc.id]: idx }));
                          if (ch.isWise) soundFX.playSuccess();
                          else soundFX.playError();
                        }}
                        className={`w-full p-4 rounded-xl border text-left text-sm transition-colors cursor-pointer ${
                          pickedIdx === idx
                            ? ch.isWise
                              ? 'bg-[#F0F7EE] border-[#14532D] text-[#14532D]'
                              : 'bg-[#FEF2F2] border-[#991B1B] text-[#7F1D1D]'
                            : 'bg-[#FAF6EE] border-[#DDD2BE] hover:border-[#B8860B]'
                        }`}
                      >
                        {ch.text}
                      </button>
                    ))}
                  </div>
                  {typeof pickedIdx === 'number' && (
                    <div className="p-3.5 rounded-xl bg-[#FFFDF8] border border-[#E2D6C1] text-xs text-[#231B15]">
                      {sc.choices[pickedIdx].feedback}
                    </div>
                  )}
                </div>
              );
            })}
          </div>

          {/* Personal Reflection Journal */}
          <div className="lg:col-span-5 vellum-card rounded-2xl p-6 flex flex-col justify-between">
            <div>
              <h3 className="font-serif text-xl font-bold text-[#231B15]">
                მოსწავლის ფიქრების დღიური
              </h3>
              <p className="text-xs text-[#5C4E42] mt-1.5 leading-relaxed">
                {story.reflection.journalPrompt}
              </p>
              <textarea
                value={journalDraft}
                onChange={(e) => {
                  setJournalDraft(e.target.value);
                  setJournalSaved(false);
                }}
                rows={7}
                placeholder="დაწერე შენი აზრი აქ..."
                className="mt-4 w-full rounded-xl border border-[#D8CBB3] bg-[#FAF6EE] p-4 text-sm text-[#231B15] focus:outline-none focus:border-[#7F1D1D]"
              />
            </div>

            <div className="mt-4 flex items-center justify-between">
              <span className="text-xs text-[#14532D] font-medium">
                {journalSaved ? '✓ შენახულია შენს პორტფოლიოში' : ''}
              </span>
              <button
                onClick={() => {
                  soundFX.playSuccess();
                  onSaveReflection(story.id, journalDraft);
                  onCompleteStory(story.id);
                  setJournalSaved(true);
                }}
                className="px-5 py-2.5 rounded-xl bg-[#7F1D1D] text-white text-xs font-semibold cursor-pointer"
              >
                ჩანაწერის შენახვა
              </button>
            </div>
          </div>
        </div>
      )}

      {/* 6. CREATE TAB (INTERACTIVE CREATIVE STUDIO) */}
      {activeTab === 'create' && (
        <CreativeStudio
          storyId={story.id}
          storyTitle={story.title}
          savedArt={progress.createdArtworks[story.id]}
          onSaveArt={(url) => onSaveArtwork(story.id, url)}
        />
      )}
    </section>
  );
}

// Interactive Creative Drawing & Manuscript Studio
function CreativeStudio({
  storyId,
  storyTitle,
  savedArt,
  onSaveArt,
}: {
  storyId: StoryId;
  storyTitle: string;
  savedArt?: string;
  onSaveArt: (dataUrl: string) => void;
}) {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const [drawing, setDrawing] = useState(false);
  const [color, setColor] = useState('#7F1D1D');
  const [brushSize, setBrushSize] = useState(5);
  const [caption, setCaption] = useState('');
  const [savedNotice, setSavedNotice] = useState(false);

  const prompts: Record<StoryId, string> = {
    pot: 'დახატე შენი ორიგინალური ქართული თიხის ქოთანი და მისი ნამდვილი ორნამენტი:',
    friends: 'დახატე სიკეთისა და მეგობრობის ბარათი კატოსა და ნინოსთვის:',
    erekle: 'დახატე საინგილოს ქლიავის ხე ან მეფე ერეკლეს დროშა:',
    ants: 'დახატე ჭიანჭველების ერთობის ხიდის გეგმა ბაღში:',
    nino: 'შექმენი ქართული საზედაო ასო ან ვაზის ჯვრის ორნამენტი:',
  };

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    ctx.fillStyle = '#FFFDF8';
    ctx.fillRect(0, 0, canvas.width, canvas.height);
    ctx.strokeStyle = '#D8CBB3';
    ctx.lineWidth = 4;
    ctx.strokeRect(10, 10, canvas.width - 20, canvas.height - 20);
  }, [storyId]);

  const getPos = (e: React.PointerEvent<HTMLCanvasElement>) => {
    const rect = e.currentTarget.getBoundingClientRect();
    return {
      x: ((e.clientX - rect.left) / rect.width) * e.currentTarget.width,
      y: ((e.clientY - rect.top) / rect.height) * e.currentTarget.height,
    };
  };

  const handleSave = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    soundFX.playSuccess();
    onSaveArt(canvas.toDataURL('image/png'));
    setSavedNotice(true);
  };

  const handleClear = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    ctx.fillStyle = '#FFFDF8';
    ctx.fillRect(0, 0, canvas.width, canvas.height);
    ctx.strokeStyle = '#D8CBB3';
    ctx.lineWidth = 4;
    ctx.strokeRect(10, 10, canvas.width - 20, canvas.height - 20);
    setSavedNotice(false);
  };

  return (
    <div className="vellum-card rounded-2xl p-6 space-y-5">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h2 className="font-serif text-xl font-bold text-[#231B15]">
            შემოქმედებითი სახელოსნო · {storyTitle}
          </h2>
          <p className="text-xs text-[#5C4E42] mt-0.5">{prompts[storyId]}</p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          {['#7F1D1D', '#14532D', '#B8860B', '#5B21B6', '#231B15', '#0284C7'].map((c) => (
            <button
              key={c}
              onClick={() => setColor(c)}
              aria-label="ფერის არჩევა"
              className={`w-6 h-6 rounded-full border-2 cursor-pointer ${
                color === c ? 'border-[#231B15] scale-110' : 'border-white'
              }`}
              style={{ backgroundColor: c }}
            />
          ))}
          <select
            value={brushSize}
            onChange={(e) => setBrushSize(Number(e.target.value))}
            aria-label="ფუნჯის ზომა"
            className="text-xs border border-[#D8CBB3] rounded-lg px-2 py-1 bg-white"
          >
            <option value={3}>წვრილი ფუნჯი</option>
            <option value={6}>საშუალო ფუნჯი</option>
            <option value={12}>მსხვილი ფუნჯი</option>
          </select>
        </div>
      </div>

      <canvas
        ref={canvasRef}
        width={820}
        height={340}
        onPointerDown={(e) => {
          e.currentTarget.setPointerCapture(e.pointerId);
          const ctx = e.currentTarget.getContext('2d');
          if (!ctx) return;
          const p = getPos(e);
          ctx.strokeStyle = color;
          ctx.lineWidth = brushSize;
          ctx.lineCap = 'round';
          ctx.beginPath();
          ctx.moveTo(p.x, p.y);
          setDrawing(true);
        }}
        onPointerMove={(e) => {
          if (!drawing) return;
          const ctx = e.currentTarget.getContext('2d');
          if (!ctx) return;
          const p = getPos(e);
          ctx.lineTo(p.x, p.y);
          ctx.stroke();
        }}
        onPointerUp={() => setDrawing(false)}
        className="w-full h-72 sm:h-80 rounded-xl border border-[#D8CBB3] bg-[#FFFDF8] cursor-crosshair touch-none"
      />

      <div className="flex flex-wrap items-center justify-between gap-3">
        <input
          type="text"
          value={caption}
          onChange={(e) => setCaption(e.target.value)}
          placeholder="დააწერე შენს ნახატს სათაური ან დევიზი..."
          className="flex-1 min-w-[220px] px-4 py-2 rounded-xl border border-[#D8CBB3] bg-[#FAF6EE] text-sm"
        />
        <div className="flex items-center gap-2">
          <button
            onClick={handleClear}
            className="px-4 py-2 rounded-xl border border-[#D8CBB3] text-xs font-medium cursor-pointer"
          >
            გასუფთავება
          </button>
          <button
            onClick={() => window.print()}
            className="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl border border-[#D8CBB3] bg-white text-xs font-medium cursor-pointer"
          >
            <Printer className="w-3.5 h-3.5" />
            ბეჭდვა
          </button>
          <button
            onClick={handleSave}
            className="px-5 py-2 rounded-xl bg-[#14532D] text-white text-xs font-semibold cursor-pointer"
          >
            ნამუშევრის შენახვა
          </button>
        </div>
      </div>

      {(savedNotice || savedArt) && (
        <div className="text-xs text-[#14532D] font-medium">
          ✓ შენი შემოქმედებითი ნამუშევარი შენახულია.
        </div>
      )}
    </div>
  );
}
