import React, { useState } from 'react';
import { BookOpen } from 'lucide-react';

export function OrnamentalDivider({ className = '' }: { className?: string }) {
  return (
    <div className={`flex items-center justify-center gap-4 py-4 ${className}`} aria-hidden="true">
      <div className="h-px flex-1 bg-gradient-to-r from-transparent via-[#CBB896] to-[#B8860B]/60" />
      <svg width="76" height="20" viewBox="0 0 76 20" fill="none" className="shrink-0 text-[#B8860B]">
        <path
          d="M2 10C10 10 14 3 22 3C28 3 32 10 38 10C44 10 48 3 54 3C62 3 66 10 74 10"
          stroke="currentColor"
          strokeWidth="1.4"
          strokeLinecap="round"
        />
        <path
          d="M2 10C10 10 14 17 22 17C28 17 32 10 38 10C44 10 48 17 54 17C62 17 66 10 74 10"
          stroke="currentColor"
          strokeWidth="1.4"
          strokeLinecap="round"
          opacity="0.55"
        />
        <circle cx="38" cy="10" r="3" fill="#7F1D1D" stroke="currentColor" strokeWidth="1.2" />
        <circle cx="22" cy="10" r="1.5" fill="currentColor" />
        <circle cx="54" cy="10" r="1.5" fill="currentColor" />
      </svg>
      <div className="h-px flex-1 bg-gradient-to-l from-transparent via-[#CBB896] to-[#B8860B]/60" />
    </div>
  );
}

export function JubileeSeal({ size = 84 }: { size?: number }) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 120 120"
      fill="none"
      aria-label="დედაენა 150 საიუბილეო სიმბოლო 1876–2026"
      className="shrink-0"
    >
      <circle cx="60" cy="60" r="56" fill="#FFFDF8" stroke="#B8860B" strokeWidth="2" />
      <circle cx="60" cy="60" r="49" stroke="#7F1D1D" strokeWidth="1" strokeDasharray="3 3" />
      {/* Vine & Violet Motifs */}
      <path d="M22 60C22 39 39 22 60 22" stroke="#14532D" strokeWidth="1.5" strokeLinecap="round" />
      <path d="M98 60C98 81 81 98 60 98" stroke="#14532D" strokeWidth="1.5" strokeLinecap="round" />
      <circle cx="60" cy="20" r="4" fill="#5B21B6" />
      <circle cx="55" cy="23" r="3" fill="#7C3AED" />
      <circle cx="65" cy="23" r="3" fill="#7C3AED" />
      <text
        x="60"
        y="53"
        textAnchor="middle"
        fill="#7F1D1D"
        fontSize="24"
        fontWeight="700"
        fontFamily="Noto Serif Georgian, Georgia, serif"
      >
        150
      </text>
      <text
        x="60"
        y="71"
        textAnchor="middle"
        fill="#231B15"
        fontSize="10"
        fontWeight="600"
        fontFamily="Noto Sans Georgian, sans-serif"
      >
        დედაენა
      </text>
      <text
        x="60"
        y="86"
        textAnchor="middle"
        fill="#6B5B4E"
        fontSize="9"
        fontWeight="500"
        fontFamily="Noto Sans Georgian, sans-serif"
      >
        1876–2026
      </text>
    </svg>
  );
}

interface ArchivalImageProps {
  src: string;
  alt: string;
  className?: string;
  caption?: string;
}

export function ArchivalImage({ src, alt, className = '', caption }: ArchivalImageProps) {
  const [failed, setFailed] = useState(false);

  return (
    <figure className="overflow-hidden">
      {failed ? (
        <div
          className={`flex flex-col items-center justify-center bg-[#F2E9D8] border border-[#DDD2BE] text-[#6B5B4E] p-6 text-center ${className}`}
        >
          <BookOpen className="w-8 h-8 mb-2 text-[#B8860B]" />
          <span className="text-xs font-medium">{alt}</span>
        </div>
      ) : (
        <img
          src={src}
          alt={alt}
          referrerPolicy="no-referrer"
          onError={() => setFailed(true)}
          className={className}
        />
      )}
      {caption && (
        <figcaption className="mt-2 text-xs text-[#6B5B4E] font-serif italic leading-relaxed">
          {caption}
        </figcaption>
      )}
    </figure>
  );
}
