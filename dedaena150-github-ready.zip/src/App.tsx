/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useEffect, useState } from 'react';
import { Menu, X } from 'lucide-react';
import { GradeLevel, PortalView, StoryId, StudentProgress } from './types';
import { CinematicIntro } from './components/CinematicIntro';
import { HomeView } from './components/HomeView';
import { AdventureMap } from './components/AdventureMap';
import { AlphabetWorld } from './components/AlphabetWorld';
import { StoryWorld } from './components/StoryWorld';
import { ValuesAndDiploma } from './components/ValuesAndDiploma';
import { TeacherWorkshop } from './components/TeacherWorkshop';

const STORAGE_KEY = 'dedaena_150_progress_v1';

const DEFAULT_PROGRESS: StudentProgress = {
  studentName: '',
  selectedGrade: 'I',
  completedStories: [],
  storyBookmarks: {
    pot: 0,
    friends: 0,
    erekle: 0,
    ants: 0,
    nino: 0,
  },
  completedGames: {
    pot: 0,
    friends: 0,
    erekle: 0,
    ants: 0,
    nino: 0,
  },
  discoveredLetters: ['ა', 'ი'],
  tracedLetters: [],
  aiIaCompleted: false,
  reflections: {},
  createdArtworks: {},
};

export default function App() {
  const [showIntro, setShowIntro] = useState(true);
  const [view, setView] = useState<PortalView>('home');
  const [activeStoryId, setActiveStoryId] = useState<StoryId>('pot');
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const [progress, setProgress] = useState<StudentProgress>(() => {
    try {
      const raw = localStorage.getItem(STORAGE_KEY);
      if (raw) {
        return { ...DEFAULT_PROGRESS, ...JSON.parse(raw) };
      }
    } catch {
      // Ignore storage read issues
    }
    return DEFAULT_PROGRESS;
  });

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(progress));
    } catch {
      // Ignore storage quota issues
    }
  }, [progress]);

  const navigate = (nextView: PortalView, storyId?: StoryId) => {
    if (storyId) setActiveStoryId(storyId);
    setView(nextView);
    setMobileMenuOpen(false);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const isTeacherMode = view === 'teacher';

  const navItems: { id: PortalView; label: string }[] = [
    { id: 'home', label: 'მთავარი' },
    { id: 'map', label: 'რუკა' },
    { id: 'alphabet', label: 'ასოები' },
    { id: 'story', label: 'ნაწარმოებები' },
    { id: 'values', label: 'ღირებულებები' },
  ];

  return (
    <div className="min-h-screen flex flex-col parchment-surface text-[#231B15]">
      {showIntro && <CinematicIntro onComplete={() => setShowIntro(false)} />}

      {/* Strict 3-Zone Top Navigation Bar */}
      <header className="sticky top-0 z-40 bg-[#FAF6EE]/95 backdrop-blur border-b border-[#DDD2BE] no-print">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 h-16 flex items-center justify-between gap-8">
          {/* Zone 1: Brand Wordmark */}
          <button
            onClick={() => navigate('home')}
            className="font-serif text-xl font-bold tracking-tight text-[#7F1D1D] whitespace-nowrap shrink-0 cursor-pointer"
          >
            დედაენა 150
          </button>

          {/* Zone 2: 5 Concise Nav Links */}
          <nav className="hidden md:flex items-center gap-6 text-sm font-medium text-[#4A3B31]">
            {navItems.map((item) => {
              const active = view === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => navigate(item.id)}
                  className={`py-1 whitespace-nowrap shrink-0 border-b-2 transition-colors cursor-pointer ${
                    active
                      ? 'border-[#7F1D1D] text-[#231B15] font-semibold'
                      : 'border-transparent hover:text-[#7F1D1D]'
                  }`}
                >
                  {item.label}
                </button>
              );
            })}
          </nav>

          {/* Zone 3: 1 Primary Action (Student / Teacher Mode Switch) */}
          <div className="flex items-center gap-3 shrink-0">
            <button
              onClick={() => navigate(isTeacherMode ? 'home' : 'teacher')}
              className={`px-4 py-2 text-xs font-semibold rounded-lg transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                isTeacherMode
                  ? 'bg-[#7F1D1D] hover:bg-[#991B1B] text-white'
                  : 'bg-[#14532D] hover:bg-[#166534] text-white'
              }`}
            >
              {isTeacherMode ? 'მოსწავლის რეჟიმი' : 'მასწავლებლის რეჟიმი'}
            </button>

            <button
              onClick={() => setMobileMenuOpen((o) => !o)}
              aria-label="მენიუს გახსნა"
              className="md:hidden p-2 rounded-lg border border-[#D8CBB3] text-[#231B15] cursor-pointer"
            >
              {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </button>
          </div>
        </div>

        {/* Mobile Drawer */}
        {mobileMenuOpen && (
          <div className="md:hidden border-t border-[#DDD2BE] bg-[#FAF6EE] px-4 py-3 space-y-1">
            {navItems.map((item) => (
              <button
                key={item.id}
                onClick={() => navigate(item.id)}
                className={`block w-full text-left px-3 py-2.5 rounded-lg text-sm font-medium ${
                  view === item.id ? 'bg-[#7F1D1D] text-white' : 'text-[#231B15]'
                }`}
              >
                {item.label}
              </button>
            ))}
          </div>
        )}
      </header>

      {/* Main Content */}
      <main className="flex-1">
        {view === 'home' && (
          <HomeView
            progress={progress}
            onNavigate={navigate}
            onReplayIntro={() => setShowIntro(true)}
            onSelectGrade={(grade: GradeLevel) =>
              setProgress((p) => ({ ...p, selectedGrade: grade }))
            }
          />
        )}

        {view === 'map' && (
          <AdventureMap
            progress={progress}
            onStartMission={(id) => navigate('story', id)}
          />
        )}

        {view === 'alphabet' && (
          <AlphabetWorld
            progress={progress}
            onDiscoverLetter={(ch) =>
              setProgress((p) => ({
                ...p,
                discoveredLetters: p.discoveredLetters.includes(ch)
                  ? p.discoveredLetters
                  : [...p.discoveredLetters, ch],
              }))
            }
            onTraceLetter={(ch) =>
              setProgress((p) => ({
                ...p,
                tracedLetters: p.tracedLetters.includes(ch)
                  ? p.tracedLetters
                  : [...p.tracedLetters, ch],
              }))
            }
            onCompleteAiIa={() =>
              setProgress((p) => ({ ...p, aiIaCompleted: true }))
            }
          />
        )}

        {view === 'story' && (
          <StoryWorld
            storyId={activeStoryId}
            progress={progress}
            onSelectStory={(id) => setActiveStoryId(id)}
            onSaveBookmark={(id, page) =>
              setProgress((p) => ({
                ...p,
                storyBookmarks: { ...p.storyBookmarks, [id]: page },
              }))
            }
            onCompleteStory={(id) =>
              setProgress((p) => ({
                ...p,
                completedStories: p.completedStories.includes(id)
                  ? p.completedStories
                  : [...p.completedStories, id],
              }))
            }
            onFinishGame={(id, stars) =>
              setProgress((p) => ({
                ...p,
                completedGames: {
                  ...p.completedGames,
                  [id]: Math.max(p.completedGames[id] || 0, stars),
                },
              }))
            }
            onSaveReflection={(id, text) =>
              setProgress((p) => ({
                ...p,
                reflections: { ...p.reflections, [id]: text },
              }))
            }
            onSaveArtwork={(id, url) =>
              setProgress((p) => ({
                ...p,
                createdArtworks: { ...p.createdArtworks, [id]: url },
              }))
            }
          />
        )}

        {view === 'values' && (
          <ValuesAndDiploma
            progress={progress}
            onUpdateStudentName={(name) =>
              setProgress((p) => ({ ...p, studentName: name }))
            }
            onOpenStory={(id) => navigate('story', id)}
          />
        )}

        {view === 'teacher' && <TeacherWorkshop />}
      </main>

      {/* Clean Archival Footer */}
      <footer className="border-t border-[#DDD2BE] bg-[#F2E9D8] py-8 px-4 sm:px-6 mt-12 no-print">
        <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-[#5C4E42]">
          <div>
            <span className="font-serif font-bold text-[#231B15]">
              დედაენა 150 — ასოებიდან ღირებულებებამდე
            </span>
            <span className="mx-2" aria-hidden="true">·</span>
            <span>იაკობ გოგებაშვილის საიუბილეო საგანმანათლებლო პორტალი (1876–2026)</span>
          </div>
          <div className="flex items-center gap-4">
            <button onClick={() => navigate('map')} className="hover:text-[#7F1D1D] cursor-pointer">
              რუკა
            </button>
            <button onClick={() => navigate('alphabet')} className="hover:text-[#7F1D1D] cursor-pointer">
              ასოების სამყარო
            </button>
            <button onClick={() => navigate('teacher')} className="hover:text-[#7F1D1D] cursor-pointer">
              მასწავლებლის სახელოსნო
            </button>
          </div>
        </div>
      </footer>
    </div>
  );
}
